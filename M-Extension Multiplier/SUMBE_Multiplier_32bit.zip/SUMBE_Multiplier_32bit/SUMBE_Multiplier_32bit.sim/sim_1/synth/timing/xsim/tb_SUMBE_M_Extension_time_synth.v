// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Tue Apr 14 00:38:49 2026
// Host        : anupam running 64-bit Ubuntu 24.04.4 LTS
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               /home/anupam/SUMBE_Multiplier_32bit/SUMBE_Multiplier_32bit.sim/sim_1/synth/timing/xsim/tb_SUMBE_M_Extension_time_synth.v
// Design      : SUMBE_Multiplier_32_v2
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

(* NotValidForBitStream *)
module SUMBE_Multiplier_32_v2
   (A,
    B,
    s_u_a,
    s_u_b,
    clk,
    PRODUCT,
    COUT);
  input [31:0]A;
  input [31:0]B;
  input s_u_a;
  input s_u_b;
  input clk;
  output [63:0]PRODUCT;
  output COUT;

  wire [31:0]A;
  wire [31:0]A_IBUF;
  wire [31:0]B;
  wire [31:0]B_IBUF;
  wire COUT;
  wire COUT_OBUF;
  wire COUT_OBUF_inst_i_10_n_0;
  wire COUT_OBUF_inst_i_11_n_0;
  wire COUT_OBUF_inst_i_2_n_0;
  wire COUT_OBUF_inst_i_3_n_0;
  wire COUT_OBUF_inst_i_4_n_0;
  wire COUT_OBUF_inst_i_5_n_0;
  wire COUT_OBUF_inst_i_6_n_0;
  wire COUT_OBUF_inst_i_7_n_0;
  wire COUT_OBUF_inst_i_8_n_0;
  wire COUT_OBUF_inst_i_9_n_0;
  wire [62:2]CSA_CARRY_wire;
  wire [61:2]CSA_SUM_wire;
  wire [63:0]PRODUCT;
  wire [63:0]PRODUCT_OBUF;
  wire \PRODUCT_OBUF[11]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[11]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[13]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[15]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[17]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[19]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[21]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[23]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[25]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[27]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[29]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[2]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[30]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[30]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[30]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[30]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_100_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_101_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_102_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_103_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_104_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_105_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_106_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_107_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_108_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_109_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_110_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_111_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_112_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_113_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_114_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_115_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_116_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_117_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_118_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_119_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_120_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_121_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_122_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_123_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_124_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_125_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_126_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_127_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_128_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_129_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_130_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_131_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_132_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_133_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_134_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_135_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_136_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_137_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_138_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_73_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_74_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_75_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_76_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_77_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_78_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_79_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_80_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_81_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_82_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_83_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_84_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_85_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_86_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_87_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_88_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_89_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_90_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_91_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_92_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_93_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_94_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_95_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_96_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_97_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_98_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_99_n_0 ;
  wire \PRODUCT_OBUF[31]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[33]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_100_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_101_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_102_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_103_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_104_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_105_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_106_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_107_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_108_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_109_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_110_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_111_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_112_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_73_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_74_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_75_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_76_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_77_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_78_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_79_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_80_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_81_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_82_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_83_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_84_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_85_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_86_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_87_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_88_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_89_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_90_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_91_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_92_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_93_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_94_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_95_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_96_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_97_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_98_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_99_n_0 ;
  wire \PRODUCT_OBUF[35]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[37]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_73_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_74_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_75_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_76_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_77_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[39]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[3]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[3]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[41]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[42]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_100_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_101_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_102_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_103_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_104_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_105_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_106_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_107_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_108_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_109_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_110_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_111_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_112_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_113_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_114_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_115_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_116_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_117_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_118_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_119_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_120_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_121_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_122_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_123_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_124_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_125_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_126_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_127_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_128_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_129_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_130_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_131_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_132_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_133_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_73_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_74_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_75_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_76_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_77_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_78_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_79_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_80_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_81_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_82_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_83_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_84_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_85_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_86_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_87_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_88_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_89_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_90_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_91_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_92_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_93_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_94_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_95_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_96_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_97_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_98_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_99_n_0 ;
  wire \PRODUCT_OBUF[43]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[45]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_73_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_74_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_75_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_76_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_77_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_78_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_79_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_80_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[47]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_57_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_58_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_59_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_60_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_61_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_62_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_63_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_64_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_65_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_66_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_67_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_68_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_69_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_70_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_71_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_72_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[49]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[50]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[51]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[53]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_27_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_28_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_29_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_30_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_31_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_32_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_33_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_34_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_35_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_36_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_37_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_38_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_39_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_40_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_41_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_42_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_43_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_44_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_45_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_46_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_47_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_48_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_49_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_50_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_51_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_52_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_53_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_54_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_55_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_56_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[55]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[57]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[59]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[5]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[5]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[5]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[60]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[60]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[60]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[60]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[60]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_19_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_20_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_21_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_22_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_23_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_24_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_25_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_26_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[61]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_2_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[63]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_3_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_5_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_6_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[7]_inst_i_9_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_10_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_11_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_12_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_13_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_14_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_15_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_16_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_17_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_18_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_4_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_7_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_8_n_0 ;
  wire \PRODUCT_OBUF[9]_inst_i_9_n_0 ;
  wire s_u_a;
  wire s_u_a_IBUF;
  wire s_u_b;
  wire s_u_b_IBUF;

initial begin
 $sdf_annotate("tb_SUMBE_M_Extension_time_synth.sdf",,,,"tool_control");
end
  IBUF \A_IBUF[0]_inst 
       (.I(A[0]),
        .O(A_IBUF[0]));
  IBUF \A_IBUF[10]_inst 
       (.I(A[10]),
        .O(A_IBUF[10]));
  IBUF \A_IBUF[11]_inst 
       (.I(A[11]),
        .O(A_IBUF[11]));
  IBUF \A_IBUF[12]_inst 
       (.I(A[12]),
        .O(A_IBUF[12]));
  IBUF \A_IBUF[13]_inst 
       (.I(A[13]),
        .O(A_IBUF[13]));
  IBUF \A_IBUF[14]_inst 
       (.I(A[14]),
        .O(A_IBUF[14]));
  IBUF \A_IBUF[15]_inst 
       (.I(A[15]),
        .O(A_IBUF[15]));
  IBUF \A_IBUF[16]_inst 
       (.I(A[16]),
        .O(A_IBUF[16]));
  IBUF \A_IBUF[17]_inst 
       (.I(A[17]),
        .O(A_IBUF[17]));
  IBUF \A_IBUF[18]_inst 
       (.I(A[18]),
        .O(A_IBUF[18]));
  IBUF \A_IBUF[19]_inst 
       (.I(A[19]),
        .O(A_IBUF[19]));
  IBUF \A_IBUF[1]_inst 
       (.I(A[1]),
        .O(A_IBUF[1]));
  IBUF \A_IBUF[20]_inst 
       (.I(A[20]),
        .O(A_IBUF[20]));
  IBUF \A_IBUF[21]_inst 
       (.I(A[21]),
        .O(A_IBUF[21]));
  IBUF \A_IBUF[22]_inst 
       (.I(A[22]),
        .O(A_IBUF[22]));
  IBUF \A_IBUF[23]_inst 
       (.I(A[23]),
        .O(A_IBUF[23]));
  IBUF \A_IBUF[24]_inst 
       (.I(A[24]),
        .O(A_IBUF[24]));
  IBUF \A_IBUF[25]_inst 
       (.I(A[25]),
        .O(A_IBUF[25]));
  IBUF \A_IBUF[26]_inst 
       (.I(A[26]),
        .O(A_IBUF[26]));
  IBUF \A_IBUF[27]_inst 
       (.I(A[27]),
        .O(A_IBUF[27]));
  IBUF \A_IBUF[28]_inst 
       (.I(A[28]),
        .O(A_IBUF[28]));
  IBUF \A_IBUF[29]_inst 
       (.I(A[29]),
        .O(A_IBUF[29]));
  IBUF \A_IBUF[2]_inst 
       (.I(A[2]),
        .O(A_IBUF[2]));
  IBUF \A_IBUF[30]_inst 
       (.I(A[30]),
        .O(A_IBUF[30]));
  IBUF \A_IBUF[31]_inst 
       (.I(A[31]),
        .O(A_IBUF[31]));
  IBUF \A_IBUF[3]_inst 
       (.I(A[3]),
        .O(A_IBUF[3]));
  IBUF \A_IBUF[4]_inst 
       (.I(A[4]),
        .O(A_IBUF[4]));
  IBUF \A_IBUF[5]_inst 
       (.I(A[5]),
        .O(A_IBUF[5]));
  IBUF \A_IBUF[6]_inst 
       (.I(A[6]),
        .O(A_IBUF[6]));
  IBUF \A_IBUF[7]_inst 
       (.I(A[7]),
        .O(A_IBUF[7]));
  IBUF \A_IBUF[8]_inst 
       (.I(A[8]),
        .O(A_IBUF[8]));
  IBUF \A_IBUF[9]_inst 
       (.I(A[9]),
        .O(A_IBUF[9]));
  IBUF \B_IBUF[0]_inst 
       (.I(B[0]),
        .O(B_IBUF[0]));
  IBUF \B_IBUF[10]_inst 
       (.I(B[10]),
        .O(B_IBUF[10]));
  IBUF \B_IBUF[11]_inst 
       (.I(B[11]),
        .O(B_IBUF[11]));
  IBUF \B_IBUF[12]_inst 
       (.I(B[12]),
        .O(B_IBUF[12]));
  IBUF \B_IBUF[13]_inst 
       (.I(B[13]),
        .O(B_IBUF[13]));
  IBUF \B_IBUF[14]_inst 
       (.I(B[14]),
        .O(B_IBUF[14]));
  IBUF \B_IBUF[15]_inst 
       (.I(B[15]),
        .O(B_IBUF[15]));
  IBUF \B_IBUF[16]_inst 
       (.I(B[16]),
        .O(B_IBUF[16]));
  IBUF \B_IBUF[17]_inst 
       (.I(B[17]),
        .O(B_IBUF[17]));
  IBUF \B_IBUF[18]_inst 
       (.I(B[18]),
        .O(B_IBUF[18]));
  IBUF \B_IBUF[19]_inst 
       (.I(B[19]),
        .O(B_IBUF[19]));
  IBUF \B_IBUF[1]_inst 
       (.I(B[1]),
        .O(B_IBUF[1]));
  IBUF \B_IBUF[20]_inst 
       (.I(B[20]),
        .O(B_IBUF[20]));
  IBUF \B_IBUF[21]_inst 
       (.I(B[21]),
        .O(B_IBUF[21]));
  IBUF \B_IBUF[22]_inst 
       (.I(B[22]),
        .O(B_IBUF[22]));
  IBUF \B_IBUF[23]_inst 
       (.I(B[23]),
        .O(B_IBUF[23]));
  IBUF \B_IBUF[24]_inst 
       (.I(B[24]),
        .O(B_IBUF[24]));
  IBUF \B_IBUF[25]_inst 
       (.I(B[25]),
        .O(B_IBUF[25]));
  IBUF \B_IBUF[26]_inst 
       (.I(B[26]),
        .O(B_IBUF[26]));
  IBUF \B_IBUF[27]_inst 
       (.I(B[27]),
        .O(B_IBUF[27]));
  IBUF \B_IBUF[28]_inst 
       (.I(B[28]),
        .O(B_IBUF[28]));
  IBUF \B_IBUF[29]_inst 
       (.I(B[29]),
        .O(B_IBUF[29]));
  IBUF \B_IBUF[2]_inst 
       (.I(B[2]),
        .O(B_IBUF[2]));
  IBUF \B_IBUF[30]_inst 
       (.I(B[30]),
        .O(B_IBUF[30]));
  IBUF \B_IBUF[31]_inst 
       (.I(B[31]),
        .O(B_IBUF[31]));
  IBUF \B_IBUF[3]_inst 
       (.I(B[3]),
        .O(B_IBUF[3]));
  IBUF \B_IBUF[4]_inst 
       (.I(B[4]),
        .O(B_IBUF[4]));
  IBUF \B_IBUF[5]_inst 
       (.I(B[5]),
        .O(B_IBUF[5]));
  IBUF \B_IBUF[6]_inst 
       (.I(B[6]),
        .O(B_IBUF[6]));
  IBUF \B_IBUF[7]_inst 
       (.I(B[7]),
        .O(B_IBUF[7]));
  IBUF \B_IBUF[8]_inst 
       (.I(B[8]),
        .O(B_IBUF[8]));
  IBUF \B_IBUF[9]_inst 
       (.I(B[9]),
        .O(B_IBUF[9]));
  OBUF COUT_OBUF_inst
       (.I(COUT_OBUF),
        .O(COUT));
  LUT6 #(
    .INIT(64'hFFFFFFFFFCFCFFFE)) 
    COUT_OBUF_inst_i_1
       (.I0(COUT_OBUF_inst_i_2_n_0),
        .I1(COUT_OBUF_inst_i_3_n_0),
        .I2(COUT_OBUF_inst_i_4_n_0),
        .I3(COUT_OBUF_inst_i_5_n_0),
        .I4(COUT_OBUF_inst_i_6_n_0),
        .I5(COUT_OBUF_inst_i_7_n_0),
        .O(COUT_OBUF));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT5 #(
    .INIT(32'h8EEE8E8E)) 
    COUT_OBUF_inst_i_10
       (.I0(CSA_SUM_wire[55]),
        .I1(CSA_CARRY_wire[55]),
        .I2(\PRODUCT_OBUF[55]_inst_i_3_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_2_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_6_n_0 ),
        .O(COUT_OBUF_inst_i_10_n_0));
  LUT6 #(
    .INIT(64'h00000000BF000040)) 
    COUT_OBUF_inst_i_11
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_14_n_0 ),
        .I5(\PRODUCT_OBUF[63]_inst_i_9_n_0 ),
        .O(COUT_OBUF_inst_i_11_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFF45440000)) 
    COUT_OBUF_inst_i_2
       (.I0(COUT_OBUF_inst_i_8_n_0),
        .I1(COUT_OBUF_inst_i_9_n_0),
        .I2(\PRODUCT_OBUF[51]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_7_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_13_n_0 ),
        .I5(COUT_OBUF_inst_i_10_n_0),
        .O(COUT_OBUF_inst_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair263" *) 
  LUT4 #(
    .INIT(16'h1000)) 
    COUT_OBUF_inst_i_3
       (.I0(COUT_OBUF_inst_i_11_n_0),
        .I1(\PRODUCT_OBUF[63]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[60]_inst_i_5_n_0 ),
        .O(COUT_OBUF_inst_i_3_n_0));
  LUT4 #(
    .INIT(16'h004F)) 
    COUT_OBUF_inst_i_4
       (.I0(\PRODUCT_OBUF[63]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[63]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_3_n_0 ),
        .I3(COUT_OBUF_inst_i_11_n_0),
        .O(COUT_OBUF_inst_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair252" *) 
  LUT3 #(
    .INIT(8'h02)) 
    COUT_OBUF_inst_i_5
       (.I0(\PRODUCT_OBUF[63]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[63]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .O(COUT_OBUF_inst_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair263" *) 
  LUT4 #(
    .INIT(16'hEFFF)) 
    COUT_OBUF_inst_i_6
       (.I0(COUT_OBUF_inst_i_11_n_0),
        .I1(\PRODUCT_OBUF[63]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[60]_inst_i_3_n_0 ),
        .O(COUT_OBUF_inst_i_6_n_0));
  LUT6 #(
    .INIT(64'h0040FFBF000040BF)) 
    COUT_OBUF_inst_i_7
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_14_n_0 ),
        .I5(\PRODUCT_OBUF[63]_inst_i_9_n_0 ),
        .O(COUT_OBUF_inst_i_7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT2 #(
    .INIT(4'h1)) 
    COUT_OBUF_inst_i_8
       (.I0(CSA_CARRY_wire[51]),
        .I1(CSA_SUM_wire[51]),
        .O(COUT_OBUF_inst_i_8_n_0));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    COUT_OBUF_inst_i_9
       (.I0(CSA_SUM_wire[51]),
        .I1(CSA_CARRY_wire[51]),
        .I2(\PRODUCT_OBUF[51]_inst_i_2_n_0 ),
        .O(COUT_OBUF_inst_i_9_n_0));
  OBUF \PRODUCT_OBUF[0]_inst 
       (.I(PRODUCT_OBUF[0]),
        .O(PRODUCT[0]));
  (* SOFT_HLUTNM = "soft_lutpair245" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \PRODUCT_OBUF[0]_inst_i_1 
       (.I0(B_IBUF[0]),
        .I1(A_IBUF[0]),
        .O(PRODUCT_OBUF[0]));
  OBUF \PRODUCT_OBUF[10]_inst 
       (.I(PRODUCT_OBUF[10]),
        .O(PRODUCT[10]));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[10]_inst_i_1 
       (.I0(\PRODUCT_OBUF[11]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[10]),
        .I2(CSA_CARRY_wire[10]),
        .O(PRODUCT_OBUF[10]));
  OBUF \PRODUCT_OBUF[11]_inst 
       (.I(PRODUCT_OBUF[11]),
        .O(PRODUCT[11]));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[11]_inst_i_1 
       (.I0(CSA_CARRY_wire[10]),
        .I1(CSA_SUM_wire[10]),
        .I2(\PRODUCT_OBUF[11]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[11]_inst_i_5_n_0 ),
        .I4(CSA_CARRY_wire[11]),
        .O(PRODUCT_OBUF[11]));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[11]_inst_i_10 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[0]),
        .I5(\PRODUCT_OBUF[11]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT5 #(
    .INIT(32'h8EEE8888)) 
    \PRODUCT_OBUF[11]_inst_i_11 
       (.I0(\PRODUCT_OBUF[11]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_22_n_0 ),
        .I2(B_IBUF[7]),
        .I3(B_IBUF[8]),
        .I4(B_IBUF[9]),
        .O(\PRODUCT_OBUF[11]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[11]_inst_i_12 
       (.I0(\PRODUCT_OBUF[11]_inst_i_23_n_0 ),
        .I1(A_IBUF[9]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[10]),
        .O(\PRODUCT_OBUF[11]_inst_i_12_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[11]_inst_i_13 
       (.I0(\PRODUCT_OBUF[11]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[11]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair231" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[11]_inst_i_14 
       (.I0(\PRODUCT_OBUF[13]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[11]_inst_i_15 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[11]_inst_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[11]_inst_i_16 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[11]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[11]_inst_i_17 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[11]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[11]_inst_i_18 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[11]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[11]_inst_i_19 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[11]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair233" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[11]_inst_i_2 
       (.I0(\PRODUCT_OBUF[11]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[11]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[11]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[11]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[10]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[11]_inst_i_20 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[11]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[11]_inst_i_21 
       (.I0(\PRODUCT_OBUF[11]_inst_i_17_n_0 ),
        .I1(A_IBUF[8]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[7]),
        .I5(\PRODUCT_OBUF[11]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[11]_inst_i_22 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[7]),
        .I4(\PRODUCT_OBUF[9]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[11]_inst_i_23 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[11]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h5995A66AA66A5995)) 
    \PRODUCT_OBUF[11]_inst_i_3 
       (.I0(\PRODUCT_OBUF[11]_inst_i_12_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[9]),
        .I3(B_IBUF[10]),
        .I4(\PRODUCT_OBUF[11]_inst_i_13_n_0 ),
        .I5(\PRODUCT_OBUF[11]_inst_i_14_n_0 ),
        .O(CSA_SUM_wire[10]));
  (* SOFT_HLUTNM = "soft_lutpair143" *) 
  LUT5 #(
    .INIT(32'h11171777)) 
    \PRODUCT_OBUF[11]_inst_i_4 
       (.I0(CSA_SUM_wire[9]),
        .I1(CSA_CARRY_wire[9]),
        .I2(CSA_SUM_wire[8]),
        .I3(CSA_CARRY_wire[8]),
        .I4(\PRODUCT_OBUF[9]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair350" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[11]_inst_i_5 
       (.I0(\PRODUCT_OBUF[13]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF599559950000)) 
    \PRODUCT_OBUF[11]_inst_i_6 
       (.I0(\PRODUCT_OBUF[11]_inst_i_12_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[9]),
        .I3(B_IBUF[10]),
        .I4(\PRODUCT_OBUF[11]_inst_i_14_n_0 ),
        .I5(\PRODUCT_OBUF[11]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[11]));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[11]_inst_i_7 
       (.I0(\PRODUCT_OBUF[11]_inst_i_15_n_0 ),
        .I1(A_IBUF[9]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[8]),
        .I5(\PRODUCT_OBUF[11]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[11]_inst_i_8 
       (.I0(\PRODUCT_OBUF[11]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_18_n_0 ),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[8]),
        .O(\PRODUCT_OBUF[11]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT5 #(
    .INIT(32'h00001760)) 
    \PRODUCT_OBUF[11]_inst_i_9 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[9]),
        .I4(\PRODUCT_OBUF[11]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[11]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[12]_inst 
       (.I(PRODUCT_OBUF[12]),
        .O(PRODUCT[12]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[12]_inst_i_1 
       (.I0(\PRODUCT_OBUF[13]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[12]),
        .I2(CSA_CARRY_wire[12]),
        .O(PRODUCT_OBUF[12]));
  OBUF \PRODUCT_OBUF[13]_inst 
       (.I(PRODUCT_OBUF[13]),
        .O(PRODUCT[13]));
  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[13]_inst_i_1 
       (.I0(\PRODUCT_OBUF[13]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[12]),
        .I2(CSA_CARRY_wire[12]),
        .I3(CSA_SUM_wire[13]),
        .I4(CSA_CARRY_wire[13]),
        .O(PRODUCT_OBUF[13]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[13]_inst_i_10 
       (.I0(\PRODUCT_OBUF[15]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair231" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[13]_inst_i_11 
       (.I0(\PRODUCT_OBUF[13]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair232" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[13]_inst_i_12 
       (.I0(\PRODUCT_OBUF[13]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[13]_inst_i_13 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[13]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[13]_inst_i_14 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[13]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[13]_inst_i_15 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[13]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair358" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[13]_inst_i_16 
       (.I0(\PRODUCT_OBUF[15]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h022A0EEA)) 
    \PRODUCT_OBUF[13]_inst_i_17 
       (.I0(B_IBUF[11]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[10]),
        .I3(B_IBUF[9]),
        .I4(\PRODUCT_OBUF[11]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[13]_inst_i_18 
       (.I0(\PRODUCT_OBUF[17]_inst_i_59_n_0 ),
        .I1(A_IBUF[12]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[11]),
        .I5(\PRODUCT_OBUF[17]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[13]_inst_i_19 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[3]),
        .I5(\PRODUCT_OBUF[17]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair371" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \PRODUCT_OBUF[13]_inst_i_2 
       (.I0(\PRODUCT_OBUF[17]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[13]_inst_i_20 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[11]),
        .I4(\PRODUCT_OBUF[15]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[13]_inst_i_21 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[0]),
        .I5(\PRODUCT_OBUF[11]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[13]_inst_i_22 
       (.I0(\PRODUCT_OBUF[11]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_16_n_0 ),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[9]),
        .O(\PRODUCT_OBUF[13]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair349" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[13]_inst_i_3 
       (.I0(\PRODUCT_OBUF[13]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_9_n_0 ),
        .O(CSA_SUM_wire[12]));
  (* SOFT_HLUTNM = "soft_lutpair350" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[13]_inst_i_4 
       (.I0(\PRODUCT_OBUF[13]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[12]));
  (* SOFT_HLUTNM = "soft_lutpair346" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[13]_inst_i_5 
       (.I0(\PRODUCT_OBUF[15]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_8_n_0 ),
        .O(CSA_SUM_wire[13]));
  (* SOFT_HLUTNM = "soft_lutpair349" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[13]_inst_i_6 
       (.I0(\PRODUCT_OBUF[13]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_8_n_0 ),
        .O(CSA_CARRY_wire[13]));
  (* SOFT_HLUTNM = "soft_lutpair232" *) 
  LUT5 #(
    .INIT(32'h2BFF002B)) 
    \PRODUCT_OBUF[13]_inst_i_7 
       (.I0(\PRODUCT_OBUF[13]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair224" *) 
  LUT5 #(
    .INIT(32'h718E8E71)) 
    \PRODUCT_OBUF[13]_inst_i_8 
       (.I0(\PRODUCT_OBUF[15]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair359" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[13]_inst_i_9 
       (.I0(\PRODUCT_OBUF[13]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[13]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[14]_inst 
       (.I(PRODUCT_OBUF[14]),
        .O(PRODUCT[14]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[14]_inst_i_1 
       (.I0(\PRODUCT_OBUF[15]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[14]),
        .I2(CSA_CARRY_wire[14]),
        .O(PRODUCT_OBUF[14]));
  OBUF \PRODUCT_OBUF[15]_inst 
       (.I(PRODUCT_OBUF[15]),
        .O(PRODUCT[15]));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[15]_inst_i_1 
       (.I0(CSA_CARRY_wire[14]),
        .I1(CSA_SUM_wire[14]),
        .I2(\PRODUCT_OBUF[15]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[15]),
        .I4(CSA_CARRY_wire[15]),
        .O(PRODUCT_OBUF[15]));
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[15]_inst_i_10 
       (.I0(\PRODUCT_OBUF[15]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair345" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[15]_inst_i_11 
       (.I0(\PRODUCT_OBUF[17]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair223" *) 
  LUT5 #(
    .INIT(32'h006969FF)) 
    \PRODUCT_OBUF[15]_inst_i_12 
       (.I0(\PRODUCT_OBUF[15]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0A20A020AFBAFABA)) 
    \PRODUCT_OBUF[15]_inst_i_13 
       (.I0(\PRODUCT_OBUF[17]_inst_i_57_n_0 ),
        .I1(A_IBUF[11]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[12]),
        .I5(\PRODUCT_OBUF[17]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_14 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[15]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_15 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[15]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair359" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[15]_inst_i_16 
       (.I0(\PRODUCT_OBUF[13]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT5 #(
    .INIT(32'h022A3E2A)) 
    \PRODUCT_OBUF[15]_inst_i_17 
       (.I0(B_IBUF[13]),
        .I1(B_IBUF[12]),
        .I2(B_IBUF[11]),
        .I3(A_IBUF[0]),
        .I4(\PRODUCT_OBUF[15]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[15]_inst_i_18 
       (.I0(\PRODUCT_OBUF[15]_inst_i_27_n_0 ),
        .I1(A_IBUF[10]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[11]),
        .O(\PRODUCT_OBUF[15]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_19 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[15]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair346" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[15]_inst_i_2 
       (.I0(\PRODUCT_OBUF[15]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_9_n_0 ),
        .O(CSA_CARRY_wire[14]));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[15]_inst_i_20 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[10]),
        .I4(\PRODUCT_OBUF[11]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair358" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[15]_inst_i_21 
       (.I0(\PRODUCT_OBUF[15]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT4 #(
    .INIT(16'h5995)) 
    \PRODUCT_OBUF[15]_inst_i_22 
       (.I0(\PRODUCT_OBUF[15]_inst_i_26_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[11]),
        .I3(B_IBUF[12]),
        .O(\PRODUCT_OBUF[15]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[15]_inst_i_23 
       (.I0(\PRODUCT_OBUF[17]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[15]_inst_i_24 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[4]),
        .I5(\PRODUCT_OBUF[17]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h0A20A020AFBAFABA)) 
    \PRODUCT_OBUF[15]_inst_i_25 
       (.I0(\PRODUCT_OBUF[17]_inst_i_31_n_0 ),
        .I1(A_IBUF[12]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[13]),
        .I5(\PRODUCT_OBUF[17]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_26 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[15]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_27 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[15]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_28 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[15]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_29 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[15]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair344" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[15]_inst_i_3 
       (.I0(\PRODUCT_OBUF[15]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[14]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[15]_inst_i_30 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[15]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[15]_inst_i_4 
       (.I0(\PRODUCT_OBUF[13]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[13]),
        .I2(CSA_CARRY_wire[13]),
        .I3(CSA_SUM_wire[12]),
        .I4(CSA_CARRY_wire[12]),
        .O(\PRODUCT_OBUF[15]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[15]_inst_i_5 
       (.I0(\PRODUCT_OBUF[17]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[15]));
  (* SOFT_HLUTNM = "soft_lutpair344" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[15]_inst_i_6 
       (.I0(\PRODUCT_OBUF[15]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[15]));
  (* SOFT_HLUTNM = "soft_lutpair223" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[15]_inst_i_7 
       (.I0(\PRODUCT_OBUF[15]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[15]_inst_i_8 
       (.I0(\PRODUCT_OBUF[17]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair224" *) 
  LUT5 #(
    .INIT(32'hFF717100)) 
    \PRODUCT_OBUF[15]_inst_i_9 
       (.I0(\PRODUCT_OBUF[15]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[15]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[16]_inst 
       (.I(PRODUCT_OBUF[16]),
        .O(PRODUCT[16]));
  (* SOFT_HLUTNM = "soft_lutpair370" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[16]_inst_i_1 
       (.I0(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[16]),
        .I2(CSA_CARRY_wire[16]),
        .O(PRODUCT_OBUF[16]));
  OBUF \PRODUCT_OBUF[17]_inst 
       (.I(PRODUCT_OBUF[17]),
        .O(PRODUCT[17]));
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[17]_inst_i_1 
       (.I0(CSA_CARRY_wire[16]),
        .I1(CSA_SUM_wire[16]),
        .I2(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[17]),
        .I4(CSA_CARRY_wire[17]),
        .O(PRODUCT_OBUF[17]));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \PRODUCT_OBUF[17]_inst_i_10 
       (.I0(\PRODUCT_OBUF[17]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_39_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_40_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair226" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[17]_inst_i_11 
       (.I0(\PRODUCT_OBUF[19]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hEEEF177F066E0001)) 
    \PRODUCT_OBUF[17]_inst_i_12 
       (.I0(\PRODUCT_OBUF[17]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_46_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair226" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[17]_inst_i_13 
       (.I0(\PRODUCT_OBUF[19]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair227" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[17]_inst_i_14 
       (.I0(\PRODUCT_OBUF[19]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair225" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[17]_inst_i_15 
       (.I0(\PRODUCT_OBUF[17]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h6969966996696969)) 
    \PRODUCT_OBUF[17]_inst_i_16 
       (.I0(\PRODUCT_OBUF[19]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_23_n_0 ),
        .I3(A_IBUF[0]),
        .I4(B_IBUF[15]),
        .I5(B_IBUF[16]),
        .O(\PRODUCT_OBUF[17]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair236" *) 
  LUT5 #(
    .INIT(32'hFFFF111F)) 
    \PRODUCT_OBUF[17]_inst_i_17 
       (.I0(CSA_SUM_wire[9]),
        .I1(CSA_CARRY_wire[9]),
        .I2(CSA_SUM_wire[8]),
        .I3(CSA_CARRY_wire[8]),
        .I4(\PRODUCT_OBUF[17]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h5454540054000000)) 
    \PRODUCT_OBUF[17]_inst_i_18 
       (.I0(\PRODUCT_OBUF[17]_inst_i_48_n_0 ),
        .I1(CSA_CARRY_wire[15]),
        .I2(CSA_SUM_wire[15]),
        .I3(CSA_SUM_wire[13]),
        .I4(CSA_CARRY_wire[13]),
        .I5(\PRODUCT_OBUF[17]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT4 #(
    .INIT(16'hF880)) 
    \PRODUCT_OBUF[17]_inst_i_19 
       (.I0(CSA_CARRY_wire[14]),
        .I1(CSA_SUM_wire[14]),
        .I2(CSA_CARRY_wire[15]),
        .I3(CSA_SUM_wire[15]),
        .O(\PRODUCT_OBUF[17]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[17]_inst_i_2 
       (.I0(\PRODUCT_OBUF[17]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[16]));
  LUT6 #(
    .INIT(64'h000000000000EEE0)) 
    \PRODUCT_OBUF[17]_inst_i_20 
       (.I0(CSA_CARRY_wire[14]),
        .I1(CSA_SUM_wire[14]),
        .I2(CSA_CARRY_wire[15]),
        .I3(CSA_SUM_wire[15]),
        .I4(\PRODUCT_OBUF[17]_inst_i_50_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_51_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_20_n_0 ));
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[17]_inst_i_21 
       (.I0(\PRODUCT_OBUF[17]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_5_n_0 ),
        .I2(CSA_CARRY_wire[11]),
        .I3(CSA_SUM_wire[10]),
        .I4(CSA_CARRY_wire[10]),
        .O(\PRODUCT_OBUF[17]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h9696966996696969)) 
    \PRODUCT_OBUF[17]_inst_i_22 
       (.I0(\PRODUCT_OBUF[19]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_26_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_24_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT5 #(
    .INIT(32'h1760E89F)) 
    \PRODUCT_OBUF[17]_inst_i_23 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[15]),
        .I4(\PRODUCT_OBUF[17]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[17]_inst_i_24 
       (.I0(\PRODUCT_OBUF[17]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[17]_inst_i_25 
       (.I0(\PRODUCT_OBUF[17]_inst_i_54_n_0 ),
        .I1(A_IBUF[14]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[13]),
        .I5(\PRODUCT_OBUF[17]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_26 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[17]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_27 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[17]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    \PRODUCT_OBUF[17]_inst_i_28 
       (.I0(B_IBUF[15]),
        .I1(B_IBUF[14]),
        .I2(B_IBUF[13]),
        .O(\PRODUCT_OBUF[17]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_29 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[17]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[17]_inst_i_3 
       (.I0(\PRODUCT_OBUF[17]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_16_n_0 ),
        .O(CSA_SUM_wire[16]));
  (* SOFT_HLUTNM = "soft_lutpair250" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[17]_inst_i_30 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[12]),
        .O(\PRODUCT_OBUF[17]_inst_i_30_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[17]_inst_i_31 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[17]_inst_i_31_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_32 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[17]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_33 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[17]_inst_i_33_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_34 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[17]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT5 #(
    .INIT(32'h00001760)) 
    \PRODUCT_OBUF[17]_inst_i_35 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[15]),
        .I4(\PRODUCT_OBUF[17]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_35_n_0 ));
  LUT6 #(
    .INIT(64'h0A20A020AFBAFABA)) 
    \PRODUCT_OBUF[17]_inst_i_36 
       (.I0(\PRODUCT_OBUF[17]_inst_i_55_n_0 ),
        .I1(A_IBUF[13]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[14]),
        .I5(\PRODUCT_OBUF[17]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_36_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[17]_inst_i_37 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[4]),
        .I5(\PRODUCT_OBUF[17]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_37_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[17]_inst_i_38 
       (.I0(\PRODUCT_OBUF[17]_inst_i_29_n_0 ),
        .I1(A_IBUF[13]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[12]),
        .I5(\PRODUCT_OBUF[17]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[17]_inst_i_39 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[3]),
        .I5(\PRODUCT_OBUF[17]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFF4FFF0FFFFFFF0)) 
    \PRODUCT_OBUF[17]_inst_i_4 
       (.I0(\PRODUCT_OBUF[17]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[9]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_20_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hD4D4D42B2B2B2BD4)) 
    \PRODUCT_OBUF[17]_inst_i_40 
       (.I0(\PRODUCT_OBUF[17]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_31_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_27_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_40_n_0 ));
  LUT5 #(
    .INIT(32'h008E8EFF)) 
    \PRODUCT_OBUF[17]_inst_i_41 
       (.I0(\PRODUCT_OBUF[17]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_59_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[17]_inst_i_42 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[0]),
        .I5(\PRODUCT_OBUF[19]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_42_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[17]_inst_i_43 
       (.I0(\PRODUCT_OBUF[19]_inst_i_35_n_0 ),
        .I1(A_IBUF[15]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[14]),
        .I5(\PRODUCT_OBUF[19]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair245" *) 
  LUT4 #(
    .INIT(16'hF995)) 
    \PRODUCT_OBUF[17]_inst_i_44 
       (.I0(B_IBUF[15]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[13]),
        .I3(B_IBUF[14]),
        .O(\PRODUCT_OBUF[17]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_45 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[17]_inst_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hE8E817E817E81717)) 
    \PRODUCT_OBUF[17]_inst_i_46 
       (.I0(\PRODUCT_OBUF[17]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_54_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_60_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h11111111F11F1FF1)) 
    \PRODUCT_OBUF[17]_inst_i_47 
       (.I0(CSA_SUM_wire[10]),
        .I1(CSA_CARRY_wire[10]),
        .I2(\PRODUCT_OBUF[13]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_10_n_0 ),
        .I5(CSA_CARRY_wire[11]),
        .O(\PRODUCT_OBUF[17]_inst_i_47_n_0 ));
  LUT6 #(
    .INIT(64'h1700001700171700)) 
    \PRODUCT_OBUF[17]_inst_i_48 
       (.I0(\PRODUCT_OBUF[15]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[15]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[15]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_11_n_0 ),
        .I5(\PRODUCT_OBUF[15]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h8E00008E008E8E00)) 
    \PRODUCT_OBUF[17]_inst_i_49 
       (.I0(\PRODUCT_OBUF[13]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_8_n_0 ),
        .I5(\PRODUCT_OBUF[13]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hE81717E817E8E817)) 
    \PRODUCT_OBUF[17]_inst_i_5 
       (.I0(\PRODUCT_OBUF[17]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_7_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[19]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[17]));
  LUT6 #(
    .INIT(64'h0071710071000071)) 
    \PRODUCT_OBUF[17]_inst_i_50 
       (.I0(\PRODUCT_OBUF[13]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[13]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[13]_inst_i_8_n_0 ),
        .I5(\PRODUCT_OBUF[13]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h0017170017000017)) 
    \PRODUCT_OBUF[17]_inst_i_51 
       (.I0(\PRODUCT_OBUF[13]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[13]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[13]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[15]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[15]_inst_i_9_n_0 ),
        .I5(\PRODUCT_OBUF[15]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_51_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair236" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[17]_inst_i_52 
       (.I0(CSA_CARRY_wire[8]),
        .I1(CSA_SUM_wire[8]),
        .I2(CSA_CARRY_wire[9]),
        .I3(CSA_SUM_wire[9]),
        .O(\PRODUCT_OBUF[17]_inst_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h66969666)) 
    \PRODUCT_OBUF[17]_inst_i_53 
       (.I0(\PRODUCT_OBUF[21]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_62_n_0 ),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[17]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_54 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[17]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[17]_inst_i_55 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[17]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_56 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[17]_inst_i_56_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[17]_inst_i_57 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[17]_inst_i_57_n_0 ));
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[17]_inst_i_58 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[11]),
        .O(\PRODUCT_OBUF[17]_inst_i_58_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[17]_inst_i_59 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[17]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[17]_inst_i_6 
       (.I0(\PRODUCT_OBUF[17]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_16_n_0 ),
        .O(CSA_CARRY_wire[17]));
  (* SOFT_HLUTNM = "soft_lutpair250" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[17]_inst_i_60 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[13]),
        .O(\PRODUCT_OBUF[17]_inst_i_60_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair345" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[17]_inst_i_7 
       (.I0(\PRODUCT_OBUF[17]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hF1F110F110F11010)) 
    \PRODUCT_OBUF[17]_inst_i_8 
       (.I0(\PRODUCT_OBUF[17]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_30_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair225" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[17]_inst_i_9 
       (.I0(\PRODUCT_OBUF[17]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[17]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[17]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[18]_inst 
       (.I(PRODUCT_OBUF[18]),
        .O(PRODUCT[18]));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[18]_inst_i_1 
       (.I0(\PRODUCT_OBUF[19]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[18]),
        .I2(CSA_CARRY_wire[18]),
        .O(PRODUCT_OBUF[18]));
  OBUF \PRODUCT_OBUF[19]_inst 
       (.I(PRODUCT_OBUF[19]),
        .O(PRODUCT[19]));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[19]_inst_i_1 
       (.I0(CSA_CARRY_wire[18]),
        .I1(CSA_SUM_wire[18]),
        .I2(\PRODUCT_OBUF[19]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[19]),
        .I4(CSA_CARRY_wire[19]),
        .O(PRODUCT_OBUF[19]));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[19]_inst_i_10 
       (.I0(\PRODUCT_OBUF[21]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[19]_inst_i_11 
       (.I0(\PRODUCT_OBUF[17]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[19]_inst_i_12 
       (.I0(\PRODUCT_OBUF[21]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT4 #(
    .INIT(16'h5995)) 
    \PRODUCT_OBUF[19]_inst_i_13 
       (.I0(\PRODUCT_OBUF[19]_inst_i_29_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[17]),
        .I3(B_IBUF[18]),
        .O(\PRODUCT_OBUF[19]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair336" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[19]_inst_i_14 
       (.I0(\PRODUCT_OBUF[19]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair219" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    \PRODUCT_OBUF[19]_inst_i_15 
       (.I0(\PRODUCT_OBUF[19]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair215" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[19]_inst_i_16 
       (.I0(\PRODUCT_OBUF[21]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_52_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_51_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[19]_inst_i_17 
       (.I0(CSA_CARRY_wire[16]),
        .I1(CSA_SUM_wire[16]),
        .I2(CSA_CARRY_wire[17]),
        .I3(CSA_SUM_wire[17]),
        .O(\PRODUCT_OBUF[19]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_18 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[19]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_19 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[19]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair219" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[19]_inst_i_2 
       (.I0(\PRODUCT_OBUF[19]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[18]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_20 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[19]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[19]_inst_i_21 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[0]),
        .I5(\PRODUCT_OBUF[19]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h0A20A020AFBAFABA)) 
    \PRODUCT_OBUF[19]_inst_i_22 
       (.I0(\PRODUCT_OBUF[19]_inst_i_34_n_0 ),
        .I1(A_IBUF[14]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[15]),
        .I5(\PRODUCT_OBUF[19]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[19]_inst_i_23 
       (.I0(\PRODUCT_OBUF[21]_inst_i_62_n_0 ),
        .I1(A_IBUF[15]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[16]),
        .O(\PRODUCT_OBUF[19]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair360" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[19]_inst_i_24 
       (.I0(\PRODUCT_OBUF[19]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair334" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[19]_inst_i_25 
       (.I0(\PRODUCT_OBUF[19]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h0EEA022A022A0EEA)) 
    \PRODUCT_OBUF[19]_inst_i_26 
       (.I0(B_IBUF[17]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[16]),
        .I3(B_IBUF[15]),
        .I4(\PRODUCT_OBUF[21]_inst_i_62_n_0 ),
        .I5(\PRODUCT_OBUF[21]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair334" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[19]_inst_i_27 
       (.I0(\PRODUCT_OBUF[19]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair360" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[19]_inst_i_28 
       (.I0(\PRODUCT_OBUF[19]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_29 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[19]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair214" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[19]_inst_i_3 
       (.I0(\PRODUCT_OBUF[19]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_16_n_0 ),
        .O(CSA_SUM_wire[18]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_30 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[19]_inst_i_30_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_31 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[19]_inst_i_31_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_32 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[19]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_33 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[19]_inst_i_33_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[19]_inst_i_34 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[19]_inst_i_34_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_35 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[19]_inst_i_35_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_36 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[19]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_37 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[19]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_38 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[19]_inst_i_38_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_39 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[19]_inst_i_39_n_0 ));
  LUT5 #(
    .INIT(32'hF100FF00)) 
    \PRODUCT_OBUF[19]_inst_i_4 
       (.I0(CSA_CARRY_wire[17]),
        .I1(CSA_SUM_wire[17]),
        .I2(\PRODUCT_OBUF[21]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_40 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[19]_inst_i_40_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[19]_inst_i_41 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[19]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair212" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[19]_inst_i_5 
       (.I0(\PRODUCT_OBUF[21]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_18_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_19_n_0 ),
        .O(CSA_SUM_wire[19]));
  (* SOFT_HLUTNM = "soft_lutpair214" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[19]_inst_i_6 
       (.I0(\PRODUCT_OBUF[19]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_15_n_0 ),
        .O(CSA_CARRY_wire[19]));
  (* SOFT_HLUTNM = "soft_lutpair227" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[19]_inst_i_7 
       (.I0(\PRODUCT_OBUF[19]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[19]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF9F609F600000)) 
    \PRODUCT_OBUF[19]_inst_i_8 
       (.I0(B_IBUF[16]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[0]),
        .I3(\PRODUCT_OBUF[19]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[19]_inst_i_24_n_0 ),
        .I5(\PRODUCT_OBUF[19]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair333" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[19]_inst_i_9 
       (.I0(\PRODUCT_OBUF[19]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[19]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[1]_inst 
       (.I(PRODUCT_OBUF[1]),
        .O(PRODUCT[1]));
  (* SOFT_HLUTNM = "soft_lutpair251" *) 
  LUT4 #(
    .INIT(16'h6AC0)) 
    \PRODUCT_OBUF[1]_inst_i_1 
       (.I0(B_IBUF[0]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[1]),
        .O(PRODUCT_OBUF[1]));
  OBUF \PRODUCT_OBUF[20]_inst 
       (.I(PRODUCT_OBUF[20]),
        .O(PRODUCT[20]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[20]_inst_i_1 
       (.I0(\PRODUCT_OBUF[21]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[20]),
        .I2(CSA_CARRY_wire[20]),
        .O(PRODUCT_OBUF[20]));
  OBUF \PRODUCT_OBUF[21]_inst 
       (.I(PRODUCT_OBUF[21]),
        .O(PRODUCT[21]));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[21]_inst_i_1 
       (.I0(\PRODUCT_OBUF[21]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[20]),
        .I2(CSA_CARRY_wire[20]),
        .I3(CSA_SUM_wire[21]),
        .I4(CSA_CARRY_wire[21]),
        .O(PRODUCT_OBUF[21]));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[21]_inst_i_10 
       (.I0(\PRODUCT_OBUF[21]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT5 #(
    .INIT(32'hFF8E8E00)) 
    \PRODUCT_OBUF[21]_inst_i_11 
       (.I0(\PRODUCT_OBUF[21]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_25_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT5 #(
    .INIT(32'h4DB2B24D)) 
    \PRODUCT_OBUF[21]_inst_i_12 
       (.I0(\PRODUCT_OBUF[21]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[21]_inst_i_13 
       (.I0(\PRODUCT_OBUF[21]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_33_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair216" *) 
  LUT5 #(
    .INIT(32'hFFE8E800)) 
    \PRODUCT_OBUF[21]_inst_i_14 
       (.I0(\PRODUCT_OBUF[21]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_37_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_38_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[21]_inst_i_15 
       (.I0(\PRODUCT_OBUF[21]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_42_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_43_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[21]_inst_i_16 
       (.I0(\PRODUCT_OBUF[21]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair337" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[21]_inst_i_17 
       (.I0(\PRODUCT_OBUF[21]_inst_i_45_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_46_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair215" *) 
  LUT5 #(
    .INIT(32'h17FF0017)) 
    \PRODUCT_OBUF[21]_inst_i_18 
       (.I0(\PRODUCT_OBUF[21]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair216" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[21]_inst_i_19 
       (.I0(\PRODUCT_OBUF[21]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_37_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_38_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFFF10000FFFF0000)) 
    \PRODUCT_OBUF[21]_inst_i_2 
       (.I0(CSA_CARRY_wire[17]),
        .I1(CSA_SUM_wire[17]),
        .I2(\PRODUCT_OBUF[21]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_9_n_0 ),
        .I5(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[21]_inst_i_20 
       (.I0(\PRODUCT_OBUF[21]_inst_i_53_n_0 ),
        .I1(A_IBUF[19]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[18]),
        .I5(\PRODUCT_OBUF[21]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[21]_inst_i_21 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[10]),
        .I5(\PRODUCT_OBUF[21]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[21]_inst_i_22 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[9]),
        .I5(\PRODUCT_OBUF[21]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[21]_inst_i_23 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[9]),
        .I5(\PRODUCT_OBUF[21]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[21]_inst_i_24 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[17]),
        .I4(\PRODUCT_OBUF[21]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[21]_inst_i_25 
       (.I0(\PRODUCT_OBUF[21]_inst_i_40_n_0 ),
        .I1(A_IBUF[18]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[21]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT5 #(
    .INIT(32'h022A3E2A)) 
    \PRODUCT_OBUF[21]_inst_i_26 
       (.I0(B_IBUF[19]),
        .I1(B_IBUF[18]),
        .I2(B_IBUF[17]),
        .I3(A_IBUF[0]),
        .I4(\PRODUCT_OBUF[19]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair336" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[21]_inst_i_27 
       (.I0(\PRODUCT_OBUF[19]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT5 #(
    .INIT(32'hFF717100)) 
    \PRODUCT_OBUF[21]_inst_i_28 
       (.I0(\PRODUCT_OBUF[21]_inst_i_42_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_40_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_44_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair337" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[21]_inst_i_29 
       (.I0(\PRODUCT_OBUF[21]_inst_i_47_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_46_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair213" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[21]_inst_i_3 
       (.I0(\PRODUCT_OBUF[21]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_12_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_13_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_14_n_0 ),
        .O(CSA_SUM_wire[20]));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[21]_inst_i_30 
       (.I0(\PRODUCT_OBUF[25]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hE89F17601760E89F)) 
    \PRODUCT_OBUF[21]_inst_i_31 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[21]),
        .I4(\PRODUCT_OBUF[21]_inst_i_58_n_0 ),
        .I5(\PRODUCT_OBUF[21]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    \PRODUCT_OBUF[21]_inst_i_32 
       (.I0(B_IBUF[21]),
        .I1(B_IBUF[20]),
        .I2(B_IBUF[19]),
        .O(\PRODUCT_OBUF[21]_inst_i_32_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[21]_inst_i_33 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[10]),
        .I5(\PRODUCT_OBUF[21]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_33_n_0 ));
  LUT6 #(
    .INIT(64'hF5DF5FDF50450545)) 
    \PRODUCT_OBUF[21]_inst_i_34 
       (.I0(\PRODUCT_OBUF[21]_inst_i_54_n_0 ),
        .I1(A_IBUF[18]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[19]),
        .I5(\PRODUCT_OBUF[21]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT5 #(
    .INIT(32'h099F0909)) 
    \PRODUCT_OBUF[21]_inst_i_35 
       (.I0(\PRODUCT_OBUF[21]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_60_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_61_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_62_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair335" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[21]_inst_i_36 
       (.I0(\PRODUCT_OBUF[21]_inst_i_64_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_65_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_66_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair361" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[21]_inst_i_37 
       (.I0(\PRODUCT_OBUF[21]_inst_i_67_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_68_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT5 #(
    .INIT(32'h2BB2B22B)) 
    \PRODUCT_OBUF[21]_inst_i_38 
       (.I0(\PRODUCT_OBUF[19]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_25_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[21]_inst_i_39 
       (.I0(\PRODUCT_OBUF[21]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair212" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[21]_inst_i_4 
       (.I0(\PRODUCT_OBUF[21]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_18_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_19_n_0 ),
        .O(CSA_CARRY_wire[20]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_40 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[21]_inst_i_40_n_0 ));
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[21]_inst_i_41 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[17]),
        .O(\PRODUCT_OBUF[21]_inst_i_41_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[21]_inst_i_42 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[21]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_43 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[21]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_44 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[21]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_45 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[21]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_46 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[21]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_47 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[21]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair335" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[21]_inst_i_48 
       (.I0(\PRODUCT_OBUF[21]_inst_i_66_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_65_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_64_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair361" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[21]_inst_i_49 
       (.I0(\PRODUCT_OBUF[21]_inst_i_69_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_68_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair207" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[21]_inst_i_5 
       (.I0(\PRODUCT_OBUF[23]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[21]));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT5 #(
    .INIT(32'h69966969)) 
    \PRODUCT_OBUF[21]_inst_i_50 
       (.I0(\PRODUCT_OBUF[21]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_57_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_61_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_62_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_50_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair333" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[21]_inst_i_51 
       (.I0(\PRODUCT_OBUF[19]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[19]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[19]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[21]_inst_i_52 
       (.I0(\PRODUCT_OBUF[21]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[21]_inst_i_52_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_53 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[21]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[21]_inst_i_54 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[21]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_55 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[21]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_56 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[21]_inst_i_56_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_57 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[21]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_58 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[21]_inst_i_58_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_59 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[21]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair213" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[21]_inst_i_6 
       (.I0(\PRODUCT_OBUF[21]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_12_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_14_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[21]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[21]_inst_i_60 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[16]),
        .O(\PRODUCT_OBUF[21]_inst_i_60_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_61 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[21]_inst_i_61_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_62 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[21]_inst_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[21]_inst_i_63 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[15]),
        .O(\PRODUCT_OBUF[21]_inst_i_63_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_64 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[21]_inst_i_64_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_65 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[21]_inst_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_66 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[21]_inst_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_67 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[21]_inst_i_67_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_68 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[21]_inst_i_68_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[21]_inst_i_69 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[21]_inst_i_69_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[21]_inst_i_7 
       (.I0(CSA_CARRY_wire[16]),
        .I1(CSA_SUM_wire[16]),
        .O(\PRODUCT_OBUF[21]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[21]_inst_i_8 
       (.I0(CSA_SUM_wire[18]),
        .I1(CSA_CARRY_wire[18]),
        .I2(CSA_SUM_wire[19]),
        .I3(CSA_CARRY_wire[19]),
        .O(\PRODUCT_OBUF[21]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[21]_inst_i_9 
       (.I0(\PRODUCT_OBUF[19]_inst_i_17_n_0 ),
        .I1(CSA_SUM_wire[19]),
        .I2(CSA_CARRY_wire[19]),
        .I3(CSA_SUM_wire[18]),
        .I4(CSA_CARRY_wire[18]),
        .O(\PRODUCT_OBUF[21]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[22]_inst 
       (.I(PRODUCT_OBUF[22]),
        .O(PRODUCT[22]));
  (* SOFT_HLUTNM = "soft_lutpair257" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[22]_inst_i_1 
       (.I0(\PRODUCT_OBUF[23]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[22]),
        .I2(CSA_CARRY_wire[22]),
        .O(PRODUCT_OBUF[22]));
  OBUF \PRODUCT_OBUF[23]_inst 
       (.I(PRODUCT_OBUF[23]),
        .O(PRODUCT[23]));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[23]_inst_i_1 
       (.I0(CSA_CARRY_wire[22]),
        .I1(CSA_SUM_wire[22]),
        .I2(\PRODUCT_OBUF[23]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[23]),
        .I4(CSA_CARRY_wire[23]),
        .O(PRODUCT_OBUF[23]));
  (* SOFT_HLUTNM = "soft_lutpair326" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[23]_inst_i_10 
       (.I0(\PRODUCT_OBUF[23]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[23]_inst_i_11 
       (.I0(\PRODUCT_OBUF[21]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair339" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[23]_inst_i_12 
       (.I0(\PRODUCT_OBUF[25]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair229" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[23]_inst_i_13 
       (.I0(\PRODUCT_OBUF[23]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_33_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hD4D42BD42BD4D4D4)) 
    \PRODUCT_OBUF[23]_inst_i_14 
       (.I0(\PRODUCT_OBUF[23]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_37_n_0 ),
        .I3(A_IBUF[0]),
        .I4(B_IBUF[21]),
        .I5(B_IBUF[22]),
        .O(\PRODUCT_OBUF[23]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair326" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[23]_inst_i_15 
       (.I0(\PRODUCT_OBUF[23]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[23]_inst_i_16 
       (.I0(\PRODUCT_OBUF[25]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[23]_inst_i_17 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[23]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_18 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[23]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_19 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[23]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair207" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[23]_inst_i_2 
       (.I0(\PRODUCT_OBUF[23]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[22]));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[23]_inst_i_20 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[5]),
        .I5(\PRODUCT_OBUF[23]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[23]_inst_i_21 
       (.I0(\PRODUCT_OBUF[23]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_40_n_0 ),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[20]),
        .O(\PRODUCT_OBUF[23]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair351" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[23]_inst_i_22 
       (.I0(\PRODUCT_OBUF[25]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_48_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[23]_inst_i_23 
       (.I0(\PRODUCT_OBUF[23]_inst_i_35_n_0 ),
        .I1(A_IBUF[21]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[20]),
        .I5(\PRODUCT_OBUF[23]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[23]_inst_i_24 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[6]),
        .I5(\PRODUCT_OBUF[25]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_25 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[23]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_26 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[23]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_27 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[23]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[23]_inst_i_28 
       (.I0(\PRODUCT_OBUF[25]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_53_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_31_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT5 #(
    .INIT(32'h566AA995)) 
    \PRODUCT_OBUF[23]_inst_i_29 
       (.I0(\PRODUCT_OBUF[25]_inst_i_55_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_53_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_54_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair206" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[23]_inst_i_3 
       (.I0(\PRODUCT_OBUF[23]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_16_n_0 ),
        .O(CSA_SUM_wire[22]));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT5 #(
    .INIT(32'hB2FF00B2)) 
    \PRODUCT_OBUF[23]_inst_i_30 
       (.I0(\PRODUCT_OBUF[21]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[21]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_30_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_31 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[23]_inst_i_31_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_32 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[23]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_33 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[23]_inst_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[23]_inst_i_34 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[1]),
        .I5(\PRODUCT_OBUF[25]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_34_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_35 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[23]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair248" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[23]_inst_i_36 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[20]),
        .O(\PRODUCT_OBUF[23]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[23]_inst_i_37 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[23]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[23]_inst_i_38 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[23]_inst_i_38_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[23]_inst_i_39 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[23]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[23]_inst_i_4 
       (.I0(\PRODUCT_OBUF[21]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[21]),
        .I2(CSA_CARRY_wire[21]),
        .I3(CSA_SUM_wire[20]),
        .I4(CSA_CARRY_wire[20]),
        .O(\PRODUCT_OBUF[23]_inst_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[23]_inst_i_40 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[23]_inst_i_40_n_0 ));
  LUT6 #(
    .INIT(64'h2B2B2BD4D4D4D42B)) 
    \PRODUCT_OBUF[23]_inst_i_41 
       (.I0(\PRODUCT_OBUF[21]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_59_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_54_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_58_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_55_n_0 ),
        .I5(\PRODUCT_OBUF[21]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[23]_inst_i_5 
       (.I0(\PRODUCT_OBUF[25]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_14_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_16_n_0 ),
        .O(CSA_SUM_wire[23]));
  (* SOFT_HLUTNM = "soft_lutpair206" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[23]_inst_i_6 
       (.I0(\PRODUCT_OBUF[23]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_15_n_0 ),
        .O(CSA_CARRY_wire[23]));
  (* SOFT_HLUTNM = "soft_lutpair228" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[23]_inst_i_7 
       (.I0(\PRODUCT_OBUF[23]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_20_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair338" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[23]_inst_i_8 
       (.I0(\PRODUCT_OBUF[23]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair318" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[23]_inst_i_9 
       (.I0(\PRODUCT_OBUF[23]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[23]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[24]_inst 
       (.I(PRODUCT_OBUF[24]),
        .O(PRODUCT[24]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[24]_inst_i_1 
       (.I0(\PRODUCT_OBUF[25]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[24]),
        .I2(CSA_CARRY_wire[24]),
        .O(PRODUCT_OBUF[24]));
  OBUF \PRODUCT_OBUF[25]_inst 
       (.I(PRODUCT_OBUF[25]),
        .O(PRODUCT[25]));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[25]_inst_i_1 
       (.I0(\PRODUCT_OBUF[25]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[24]),
        .I2(CSA_CARRY_wire[24]),
        .I3(CSA_SUM_wire[25]),
        .I4(CSA_CARRY_wire[25]),
        .O(PRODUCT_OBUF[25]));
  LUT6 #(
    .INIT(64'hD7414141D7D7D741)) 
    \PRODUCT_OBUF[25]_inst_i_10 
       (.I0(\PRODUCT_OBUF[25]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_38_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_24_n_0 ),
        .I5(\PRODUCT_OBUF[25]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h17E8E817E81717E8)) 
    \PRODUCT_OBUF[25]_inst_i_11 
       (.I0(\PRODUCT_OBUF[27]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_37_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_36_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h6FF6F66F06606006)) 
    \PRODUCT_OBUF[25]_inst_i_12 
       (.I0(\PRODUCT_OBUF[25]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_30_n_0 ),
        .I5(\PRODUCT_OBUF[23]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[25]_inst_i_13 
       (.I0(\PRODUCT_OBUF[25]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[25]_inst_i_14 
       (.I0(\PRODUCT_OBUF[27]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT5 #(
    .INIT(32'h7DD71441)) 
    \PRODUCT_OBUF[25]_inst_i_15 
       (.I0(\PRODUCT_OBUF[25]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair204" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[25]_inst_i_16 
       (.I0(\PRODUCT_OBUF[25]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_34_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_35_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_36_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[25]_inst_i_17 
       (.I0(\PRODUCT_OBUF[27]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT4 #(
    .INIT(16'h5995)) 
    \PRODUCT_OBUF[25]_inst_i_18 
       (.I0(\PRODUCT_OBUF[27]_inst_i_43_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[23]),
        .I3(B_IBUF[24]),
        .O(\PRODUCT_OBUF[25]_inst_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h7711717711777177)) 
    \PRODUCT_OBUF[25]_inst_i_19 
       (.I0(\PRODUCT_OBUF[25]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_39_n_0 ),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[23]),
        .O(\PRODUCT_OBUF[25]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair370" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \PRODUCT_OBUF[25]_inst_i_2 
       (.I0(\PRODUCT_OBUF[33]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[25]_inst_i_20 
       (.I0(\PRODUCT_OBUF[27]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[25]_inst_i_21 
       (.I0(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I1(A_IBUF[23]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[24]),
        .O(\PRODUCT_OBUF[25]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h00FF96699669FF00)) 
    \PRODUCT_OBUF[25]_inst_i_22 
       (.I0(\PRODUCT_OBUF[23]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_33_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_26_n_0 ),
        .I5(\PRODUCT_OBUF[23]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair338" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[25]_inst_i_23 
       (.I0(\PRODUCT_OBUF[23]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair228" *) 
  LUT5 #(
    .INIT(32'h00D4D4FF)) 
    \PRODUCT_OBUF[25]_inst_i_24 
       (.I0(\PRODUCT_OBUF[23]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_20_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair318" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[25]_inst_i_25 
       (.I0(\PRODUCT_OBUF[23]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair146" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[25]_inst_i_26 
       (.I0(\PRODUCT_OBUF[25]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[25]_inst_i_27 
       (.I0(\PRODUCT_OBUF[25]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_44_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_31_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_27_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[25]_inst_i_28 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[6]),
        .I5(\PRODUCT_OBUF[25]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair351" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[25]_inst_i_29 
       (.I0(\PRODUCT_OBUF[25]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair203" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[25]_inst_i_3 
       (.I0(\PRODUCT_OBUF[25]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[24]));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[25]_inst_i_30 
       (.I0(\PRODUCT_OBUF[25]_inst_i_49_n_0 ),
        .I1(A_IBUF[22]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[21]),
        .I5(\PRODUCT_OBUF[25]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h69000069FF6969FF)) 
    \PRODUCT_OBUF[25]_inst_i_31 
       (.I0(\PRODUCT_OBUF[23]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_20_n_0 ),
        .I5(\PRODUCT_OBUF[23]_inst_i_9_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT5 #(
    .INIT(32'h1700FF17)) 
    \PRODUCT_OBUF[25]_inst_i_32 
       (.I0(\PRODUCT_OBUF[25]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_53_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_54_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_55_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[25]_inst_i_33 
       (.I0(\PRODUCT_OBUF[23]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[25]_inst_i_34 
       (.I0(\PRODUCT_OBUF[25]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_50_n_0 ),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[22]),
        .O(\PRODUCT_OBUF[25]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_35 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[25]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair230" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[25]_inst_i_36 
       (.I0(\PRODUCT_OBUF[27]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_54_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair319" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[25]_inst_i_37 
       (.I0(\PRODUCT_OBUF[27]_inst_i_55_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_57_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_38 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[25]_inst_i_38_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_39 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[25]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[25]_inst_i_4 
       (.I0(\PRODUCT_OBUF[25]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_16_n_0 ),
        .O(CSA_CARRY_wire[24]));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_40 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[25]_inst_i_40_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_41 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[25]_inst_i_41_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_42 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[25]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_43 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[25]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_44 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[25]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_45 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[25]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_46 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[25]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_47 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[25]_inst_i_47_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_48 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[25]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_49 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[25]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair199" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[25]_inst_i_5 
       (.I0(\PRODUCT_OBUF[27]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[25]));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[25]_inst_i_50 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[25]_inst_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h1717E817E817E8E8)) 
    \PRODUCT_OBUF[25]_inst_i_51 
       (.I0(\PRODUCT_OBUF[23]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_57_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_18_n_0 ),
        .I5(\PRODUCT_OBUF[23]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_51_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[25]_inst_i_52 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[5]),
        .I5(\PRODUCT_OBUF[23]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_52_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[25]_inst_i_53 
       (.I0(\PRODUCT_OBUF[23]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_53_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[25]_inst_i_54 
       (.I0(\PRODUCT_OBUF[23]_inst_i_39_n_0 ),
        .I1(A_IBUF[20]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[19]),
        .I5(\PRODUCT_OBUF[23]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_54_n_0 ));
  LUT6 #(
    .INIT(64'h00E0E0EEEEFEFEFF)) 
    \PRODUCT_OBUF[25]_inst_i_55 
       (.I0(\PRODUCT_OBUF[25]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[21]_inst_i_53_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_59_n_0 ),
        .I4(\PRODUCT_OBUF[21]_inst_i_54_n_0 ),
        .I5(\PRODUCT_OBUF[21]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_55_n_0 ));
  LUT6 #(
    .INIT(64'h1111177117717171)) 
    \PRODUCT_OBUF[25]_inst_i_56 
       (.I0(\PRODUCT_OBUF[21]_inst_i_59_n_0 ),
        .I1(\PRODUCT_OBUF[21]_inst_i_58_n_0 ),
        .I2(B_IBUF[21]),
        .I3(A_IBUF[0]),
        .I4(B_IBUF[19]),
        .I5(B_IBUF[20]),
        .O(\PRODUCT_OBUF[25]_inst_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair249" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[25]_inst_i_57 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[19]),
        .O(\PRODUCT_OBUF[25]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[25]_inst_i_58 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[25]_inst_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair249" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[25]_inst_i_59 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[18]),
        .O(\PRODUCT_OBUF[25]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair203" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[25]_inst_i_6 
       (.I0(\PRODUCT_OBUF[25]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_10_n_0 ),
        .O(CSA_CARRY_wire[25]));
  (* SOFT_HLUTNM = "soft_lutpair220" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[25]_inst_i_7 
       (.I0(\PRODUCT_OBUF[27]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair352" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[25]_inst_i_8 
       (.I0(\PRODUCT_OBUF[25]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair208" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[25]_inst_i_9 
       (.I0(\PRODUCT_OBUF[29]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[25]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[26]_inst 
       (.I(PRODUCT_OBUF[26]),
        .O(PRODUCT[26]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[26]_inst_i_1 
       (.I0(\PRODUCT_OBUF[27]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[26]),
        .I2(CSA_CARRY_wire[26]),
        .O(PRODUCT_OBUF[26]));
  OBUF \PRODUCT_OBUF[27]_inst 
       (.I(PRODUCT_OBUF[27]),
        .O(PRODUCT[27]));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[27]_inst_i_1 
       (.I0(CSA_CARRY_wire[26]),
        .I1(CSA_SUM_wire[26]),
        .I2(\PRODUCT_OBUF[27]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[27]),
        .I4(CSA_CARRY_wire[27]),
        .O(PRODUCT_OBUF[27]));
  LUT6 #(
    .INIT(64'h6969966996699696)) 
    \PRODUCT_OBUF[27]_inst_i_10 
       (.I0(\PRODUCT_OBUF[27]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_31_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_33_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h7D7D7D147D141414)) 
    \PRODUCT_OBUF[27]_inst_i_11 
       (.I0(\PRODUCT_OBUF[27]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_38_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h6FFF666F06660006)) 
    \PRODUCT_OBUF[27]_inst_i_12 
       (.I0(\PRODUCT_OBUF[27]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_33_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_32_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair196" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[27]_inst_i_13 
       (.I0(\PRODUCT_OBUF[29]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[27]_inst_i_14 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[27]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_15 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[27]_inst_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_16 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[27]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair363" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[27]_inst_i_17 
       (.I0(\PRODUCT_OBUF[27]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT5 #(
    .INIT(32'hFDD5C1D5)) 
    \PRODUCT_OBUF[27]_inst_i_18 
       (.I0(B_IBUF[25]),
        .I1(B_IBUF[24]),
        .I2(B_IBUF[23]),
        .I3(A_IBUF[0]),
        .I4(\PRODUCT_OBUF[27]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_19 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[27]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair199" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[27]_inst_i_2 
       (.I0(\PRODUCT_OBUF[27]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[26]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_20 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[27]_inst_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_21 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[27]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair362" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[27]_inst_i_22 
       (.I0(\PRODUCT_OBUF[29]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[27]_inst_i_23 
       (.I0(\PRODUCT_OBUF[31]_inst_i_85_n_0 ),
        .I1(A_IBUF[24]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[25]),
        .O(\PRODUCT_OBUF[27]_inst_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_24 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[27]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[27]_inst_i_25 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[23]),
        .O(\PRODUCT_OBUF[27]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_26 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[27]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_27 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[27]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair320" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[27]_inst_i_28 
       (.I0(\PRODUCT_OBUF[27]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_46_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[27]_inst_i_29 
       (.I0(\PRODUCT_OBUF[31]_inst_i_78_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_77_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_76_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[27]_inst_i_3 
       (.I0(\PRODUCT_OBUF[27]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_13_n_0 ),
        .O(CSA_SUM_wire[26]));
  LUT6 #(
    .INIT(64'hF66F60066006F66F)) 
    \PRODUCT_OBUF[27]_inst_i_30 
       (.I0(\PRODUCT_OBUF[25]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_49_n_0 ),
        .I5(\PRODUCT_OBUF[25]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'hE8171717E8E8E817)) 
    \PRODUCT_OBUF[27]_inst_i_31 
       (.I0(\PRODUCT_OBUF[29]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_21_n_0 ),
        .I5(\PRODUCT_OBUF[25]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair230" *) 
  LUT5 #(
    .INIT(32'h009696FF)) 
    \PRODUCT_OBUF[27]_inst_i_32 
       (.I0(\PRODUCT_OBUF[27]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_53_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair204" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[27]_inst_i_33 
       (.I0(\PRODUCT_OBUF[25]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair319" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[27]_inst_i_34 
       (.I0(\PRODUCT_OBUF[27]_inst_i_55_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_56_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_34_n_0 ));
  LUT6 #(
    .INIT(64'hF66F60066006F66F)) 
    \PRODUCT_OBUF[27]_inst_i_35 
       (.I0(\PRODUCT_OBUF[27]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_59_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_55_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_60_n_0 ),
        .I5(\PRODUCT_OBUF[25]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_35_n_0 ));
  LUT6 #(
    .INIT(64'h17E81717E8E817E8)) 
    \PRODUCT_OBUF[27]_inst_i_36 
       (.I0(\PRODUCT_OBUF[27]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_56_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_35_n_0 ),
        .I5(\PRODUCT_OBUF[25]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_36_n_0 ));
  LUT6 #(
    .INIT(64'h1555555515151555)) 
    \PRODUCT_OBUF[27]_inst_i_37 
       (.I0(\PRODUCT_OBUF[27]_inst_i_61_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_62_n_0 ),
        .I2(A_IBUF[0]),
        .I3(\PRODUCT_OBUF[23]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[23]_inst_i_36_n_0 ),
        .I5(\PRODUCT_OBUF[23]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair339" *) 
  LUT3 #(
    .INIT(8'h4D)) 
    \PRODUCT_OBUF[27]_inst_i_38 
       (.I0(\PRODUCT_OBUF[25]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair229" *) 
  LUT5 #(
    .INIT(32'h009696FF)) 
    \PRODUCT_OBUF[27]_inst_i_39 
       (.I0(\PRODUCT_OBUF[23]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[23]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[23]_inst_i_33_n_0 ),
        .I3(\PRODUCT_OBUF[23]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[27]_inst_i_4 
       (.I0(\PRODUCT_OBUF[25]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[25]),
        .I2(CSA_CARRY_wire[25]),
        .I3(CSA_SUM_wire[24]),
        .I4(CSA_CARRY_wire[24]),
        .O(\PRODUCT_OBUF[27]_inst_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[27]_inst_i_40 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[27]_inst_i_40_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_41 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[27]_inst_i_41_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_42 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[27]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_43 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[27]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[27]_inst_i_44 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[27]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_45 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[27]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_46 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[27]_inst_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[27]_inst_i_47 
       (.I0(\PRODUCT_OBUF[27]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_43_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_64_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_20_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT5 #(
    .INIT(32'h1EEE111E)) 
    \PRODUCT_OBUF[27]_inst_i_48 
       (.I0(\PRODUCT_OBUF[29]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_65_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_39_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_38_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'h66696999)) 
    \PRODUCT_OBUF[27]_inst_i_49 
       (.I0(\PRODUCT_OBUF[27]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_49_n_0 ));
  LUT6 #(
    .INIT(64'h4DB2B24DB24D4DB2)) 
    \PRODUCT_OBUF[27]_inst_i_5 
       (.I0(\PRODUCT_OBUF[29]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_13_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_14_n_0 ),
        .I5(\PRODUCT_OBUF[29]_inst_i_18_n_0 ),
        .O(CSA_SUM_wire[27]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_50 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[27]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_51 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[27]_inst_i_51_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_52 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[27]_inst_i_52_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[27]_inst_i_53 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[2]),
        .I5(\PRODUCT_OBUF[29]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_53_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[27]_inst_i_54 
       (.I0(\PRODUCT_OBUF[29]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_54_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[27]_inst_i_55 
       (.I0(\PRODUCT_OBUF[25]_inst_i_38_n_0 ),
        .I1(A_IBUF[23]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[22]),
        .I5(\PRODUCT_OBUF[25]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_55_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[27]_inst_i_56 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[1]),
        .I5(\PRODUCT_OBUF[25]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_56_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[27]_inst_i_57 
       (.I0(\PRODUCT_OBUF[25]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_57_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[27]_inst_i_58 
       (.I0(\PRODUCT_OBUF[27]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair146" *) 
  LUT5 #(
    .INIT(32'hE111EEE1)) 
    \PRODUCT_OBUF[27]_inst_i_59 
       (.I0(\PRODUCT_OBUF[25]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_43_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[27]_inst_i_6 
       (.I0(\PRODUCT_OBUF[29]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[27]));
  LUT4 #(
    .INIT(16'h566A)) 
    \PRODUCT_OBUF[27]_inst_i_60 
       (.I0(\PRODUCT_OBUF[25]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_60_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT4 #(
    .INIT(16'h022A)) 
    \PRODUCT_OBUF[27]_inst_i_61 
       (.I0(B_IBUF[23]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[21]),
        .I3(B_IBUF[22]),
        .O(\PRODUCT_OBUF[27]_inst_i_61_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PRODUCT_OBUF[27]_inst_i_62 
       (.I0(B_IBUF[21]),
        .I1(B_IBUF[22]),
        .O(\PRODUCT_OBUF[27]_inst_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT4 #(
    .INIT(16'hF995)) 
    \PRODUCT_OBUF[27]_inst_i_63 
       (.I0(B_IBUF[25]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[23]),
        .I3(B_IBUF[24]),
        .O(\PRODUCT_OBUF[27]_inst_i_63_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    \PRODUCT_OBUF[27]_inst_i_64 
       (.I0(B_IBUF[25]),
        .I1(B_IBUF[24]),
        .I2(B_IBUF[23]),
        .O(\PRODUCT_OBUF[27]_inst_i_64_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[27]_inst_i_65 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[27]_inst_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair248" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[27]_inst_i_66 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[21]),
        .O(\PRODUCT_OBUF[27]_inst_i_66_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair209" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[27]_inst_i_7 
       (.I0(\PRODUCT_OBUF[27]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair221" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[27]_inst_i_8 
       (.I0(\PRODUCT_OBUF[27]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hB44B4BB44BB4B44B)) 
    \PRODUCT_OBUF[27]_inst_i_9 
       (.I0(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_26_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_28_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[27]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[28]_inst 
       (.I(PRODUCT_OBUF[28]),
        .O(PRODUCT[28]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[28]_inst_i_1 
       (.I0(\PRODUCT_OBUF[29]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[28]),
        .I2(CSA_CARRY_wire[28]),
        .O(PRODUCT_OBUF[28]));
  OBUF \PRODUCT_OBUF[29]_inst 
       (.I(PRODUCT_OBUF[29]),
        .O(PRODUCT[29]));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[29]_inst_i_1 
       (.I0(\PRODUCT_OBUF[29]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[28]),
        .I2(CSA_CARRY_wire[28]),
        .I3(CSA_SUM_wire[29]),
        .I4(CSA_CARRY_wire[29]),
        .O(PRODUCT_OBUF[29]));
  (* SOFT_HLUTNM = "soft_lutpair197" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[29]_inst_i_10 
       (.I0(\PRODUCT_OBUF[31]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_29_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[29]_inst_i_11 
       (.I0(\PRODUCT_OBUF[31]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair211" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[29]_inst_i_12 
       (.I0(\PRODUCT_OBUF[31]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_43_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair196" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[29]_inst_i_13 
       (.I0(\PRODUCT_OBUF[29]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hD42B2BD42BD4D42B)) 
    \PRODUCT_OBUF[29]_inst_i_14 
       (.I0(\PRODUCT_OBUF[29]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_30_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair308" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[29]_inst_i_15 
       (.I0(\PRODUCT_OBUF[29]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair208" *) 
  LUT5 #(
    .INIT(32'h1700FF17)) 
    \PRODUCT_OBUF[29]_inst_i_16 
       (.I0(\PRODUCT_OBUF[29]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_30_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_31_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_16_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[29]_inst_i_17 
       (.I0(\PRODUCT_OBUF[27]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[29]_inst_i_18 
       (.I0(\PRODUCT_OBUF[31]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_33_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair308" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[29]_inst_i_19 
       (.I0(\PRODUCT_OBUF[29]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_19_n_0 ));
  LUT4 #(
    .INIT(16'hF0E0)) 
    \PRODUCT_OBUF[29]_inst_i_2 
       (.I0(\PRODUCT_OBUF[29]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_2_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h9669696969969696)) 
    \PRODUCT_OBUF[29]_inst_i_20 
       (.I0(\PRODUCT_OBUF[31]_inst_i_83_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_82_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_81_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_85_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_86_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[29]_inst_i_21 
       (.I0(\PRODUCT_OBUF[31]_inst_i_96_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_95_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_94_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'hE89F17601760E89F)) 
    \PRODUCT_OBUF[29]_inst_i_22 
       (.I0(B_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[27]),
        .I4(\PRODUCT_OBUF[31]_inst_i_91_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_90_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h022FFDD0FDD0022F)) 
    \PRODUCT_OBUF[29]_inst_i_23 
       (.I0(\PRODUCT_OBUF[27]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_74_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_75_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair222" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[29]_inst_i_24 
       (.I0(\PRODUCT_OBUF[31]_inst_i_76_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_77_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_78_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_80_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_79_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hB44B0000FFFFB44B)) 
    \PRODUCT_OBUF[29]_inst_i_25 
       (.I0(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_26_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_29_n_0 ),
        .I5(\PRODUCT_OBUF[27]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair209" *) 
  LUT5 #(
    .INIT(32'h2B00FF2B)) 
    \PRODUCT_OBUF[29]_inst_i_26 
       (.I0(\PRODUCT_OBUF[27]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair221" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[29]_inst_i_27 
       (.I0(\PRODUCT_OBUF[27]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[27]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair362" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[29]_inst_i_28 
       (.I0(\PRODUCT_OBUF[29]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_34_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[29]_inst_i_29 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[2]),
        .I5(\PRODUCT_OBUF[29]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair301" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[29]_inst_i_3 
       (.I0(\PRODUCT_OBUF[29]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[28]));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[29]_inst_i_30 
       (.I0(\PRODUCT_OBUF[29]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair220" *) 
  LUT5 #(
    .INIT(32'h009696FF)) 
    \PRODUCT_OBUF[29]_inst_i_31 
       (.I0(\PRODUCT_OBUF[27]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[25]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[25]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair352" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[29]_inst_i_32 
       (.I0(\PRODUCT_OBUF[25]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[25]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[25]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[29]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[29]_inst_i_33 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[29]_inst_i_33_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[29]_inst_i_34 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[29]_inst_i_34_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[29]_inst_i_35 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[29]_inst_i_35_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[29]_inst_i_36 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[29]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[29]_inst_i_37 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[29]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[29]_inst_i_38 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[29]_inst_i_38_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[29]_inst_i_39 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[29]_inst_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hF6FF66F660660060)) 
    \PRODUCT_OBUF[29]_inst_i_4 
       (.I0(\PRODUCT_OBUF[29]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_17_n_0 ),
        .I5(\PRODUCT_OBUF[29]_inst_i_18_n_0 ),
        .O(CSA_CARRY_wire[28]));
  LUT6 #(
    .INIT(64'h4DB2B24DB24D4DB2)) 
    \PRODUCT_OBUF[29]_inst_i_5 
       (.I0(\PRODUCT_OBUF[31]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_13_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_8_n_0 ),
        .O(CSA_SUM_wire[29]));
  (* SOFT_HLUTNM = "soft_lutpair301" *) 
  LUT3 #(
    .INIT(8'h4D)) 
    \PRODUCT_OBUF[29]_inst_i_6 
       (.I0(\PRODUCT_OBUF[29]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[29]));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[29]_inst_i_7 
       (.I0(CSA_SUM_wire[26]),
        .I1(CSA_CARRY_wire[26]),
        .I2(CSA_SUM_wire[27]),
        .I3(CSA_CARRY_wire[27]),
        .O(\PRODUCT_OBUF[29]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair256" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[29]_inst_i_8 
       (.I0(CSA_SUM_wire[25]),
        .I1(CSA_CARRY_wire[25]),
        .I2(CSA_SUM_wire[24]),
        .I3(CSA_CARRY_wire[24]),
        .O(\PRODUCT_OBUF[29]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[29]_inst_i_9 
       (.I0(\PRODUCT_OBUF[33]_inst_i_38_n_0 ),
        .I1(CSA_SUM_wire[27]),
        .I2(CSA_CARRY_wire[27]),
        .I3(CSA_SUM_wire[26]),
        .I4(CSA_CARRY_wire[26]),
        .O(\PRODUCT_OBUF[29]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[2]_inst 
       (.I(PRODUCT_OBUF[2]),
        .O(PRODUCT[2]));
  LUT5 #(
    .INIT(32'h5995A66A)) 
    \PRODUCT_OBUF[2]_inst_i_1 
       (.I0(\PRODUCT_OBUF[3]_inst_i_4_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[2]),
        .I4(\PRODUCT_OBUF[2]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[2]));
  (* SOFT_HLUTNM = "soft_lutpair251" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[2]_inst_i_2 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[1]),
        .O(\PRODUCT_OBUF[2]_inst_i_2_n_0 ));
  OBUF \PRODUCT_OBUF[30]_inst 
       (.I(PRODUCT_OBUF[30]),
        .O(PRODUCT[30]));
  (* SOFT_HLUTNM = "soft_lutpair369" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[30]_inst_i_1 
       (.I0(\PRODUCT_OBUF[31]_inst_i_3_n_0 ),
        .I1(CSA_SUM_wire[30]),
        .I2(CSA_CARRY_wire[30]),
        .O(PRODUCT_OBUF[30]));
  LUT6 #(
    .INIT(64'h6996969669696996)) 
    \PRODUCT_OBUF[30]_inst_i_2 
       (.I0(\PRODUCT_OBUF[30]_inst_i_3_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_19_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_20_n_0 ),
        .O(CSA_SUM_wire[30]));
  LUT6 #(
    .INIT(64'h4DB2B24DB24D4DB2)) 
    \PRODUCT_OBUF[30]_inst_i_3 
       (.I0(\PRODUCT_OBUF[31]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_14_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_23_n_0 ),
        .I5(\PRODUCT_OBUF[30]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[30]_inst_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h96000096FF9696FF)) 
    \PRODUCT_OBUF[30]_inst_i_4 
       (.I0(\PRODUCT_OBUF[31]_inst_i_62_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_60_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_61_n_0 ),
        .I3(\PRODUCT_OBUF[30]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_57_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[30]_inst_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h566A)) 
    \PRODUCT_OBUF[30]_inst_i_5 
       (.I0(\PRODUCT_OBUF[31]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[30]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_107_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_106_n_0 ),
        .O(\PRODUCT_OBUF[30]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair247" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[30]_inst_i_6 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[27]),
        .O(\PRODUCT_OBUF[30]_inst_i_6_n_0 ));
  OBUF \PRODUCT_OBUF[31]_inst 
       (.I(PRODUCT_OBUF[31]),
        .O(PRODUCT[31]));
  LUT6 #(
    .INIT(64'hE187871E871E1E78)) 
    \PRODUCT_OBUF[31]_inst_i_1 
       (.I0(CSA_CARRY_wire[30]),
        .I1(\PRODUCT_OBUF[31]_inst_i_3_n_0 ),
        .I2(CSA_SUM_wire[31]),
        .I3(\PRODUCT_OBUF[31]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[31]));
  (* SOFT_HLUTNM = "soft_lutpair198" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[31]_inst_i_10 
       (.I0(\PRODUCT_OBUF[31]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_33_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_100 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[31]_inst_i_100_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_101 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[31]_inst_i_101_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_102 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[31]_inst_i_102_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_103 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_103_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_104 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[31]_inst_i_104_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_105 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[31]_inst_i_105_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_106 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[31]_inst_i_106_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_107 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_107_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_108 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[31]_inst_i_108_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_109 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_109_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair302" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_11 
       (.I0(\PRODUCT_OBUF[31]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair247" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[31]_inst_i_110 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_110_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_111 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[31]_inst_i_111_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_112 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[31]_inst_i_112_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_113 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[31]_inst_i_113_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_114 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[31]_inst_i_114_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_115 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_115_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_116 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[31]_inst_i_116_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_117 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[31]_inst_i_117_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_118 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[31]_inst_i_118_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_119 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_119_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair211" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[31]_inst_i_12 
       (.I0(\PRODUCT_OBUF[31]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_120 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[31]_inst_i_120_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_121 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[31]_inst_i_121_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[31]_inst_i_122 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[31]_inst_i_122_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_123 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_123_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_124 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[31]_inst_i_124_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_125 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_125_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_126 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[31]_inst_i_126_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_127 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[31]_inst_i_127_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_128 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_128_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair246" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[31]_inst_i_129 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[29]),
        .O(\PRODUCT_OBUF[31]_inst_i_129_n_0 ));
  LUT6 #(
    .INIT(64'h9669696996969669)) 
    \PRODUCT_OBUF[31]_inst_i_13 
       (.I0(\PRODUCT_OBUF[31]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_38_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_130 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[31]_inst_i_130_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_131 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[31]_inst_i_131_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_132 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[31]_inst_i_132_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_133 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[31]_inst_i_133_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_134 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[31]_inst_i_134_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_135 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[31]_inst_i_135_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_136 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[31]_inst_i_136_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_137 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_137_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_138 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[31]_inst_i_138_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT5 #(
    .INIT(32'h006969FF)) 
    \PRODUCT_OBUF[31]_inst_i_14 
       (.I0(\PRODUCT_OBUF[31]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_46_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_47_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT5 #(
    .INIT(32'h4D44DD4D)) 
    \PRODUCT_OBUF[31]_inst_i_15 
       (.I0(\PRODUCT_OBUF[31]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_52_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_15_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[31]_inst_i_16 
       (.I0(\PRODUCT_OBUF[31]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT5 #(
    .INIT(32'h006969FF)) 
    \PRODUCT_OBUF[31]_inst_i_17 
       (.I0(\PRODUCT_OBUF[33]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT5 #(
    .INIT(32'h718E8E71)) 
    \PRODUCT_OBUF[31]_inst_i_18 
       (.I0(\PRODUCT_OBUF[33]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[31]_inst_i_19 
       (.I0(\PRODUCT_OBUF[31]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hDF5D45044504DF5D)) 
    \PRODUCT_OBUF[31]_inst_i_2 
       (.I0(\PRODUCT_OBUF[31]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_12_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[30]));
  (* SOFT_HLUTNM = "soft_lutpair302" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[31]_inst_i_20 
       (.I0(\PRODUCT_OBUF[31]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_21 
       (.I0(\PRODUCT_OBUF[31]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair297" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[31]_inst_i_22 
       (.I0(\PRODUCT_OBUF[31]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair342" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_23 
       (.I0(\PRODUCT_OBUF[31]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_61_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h9669699669969669)) 
    \PRODUCT_OBUF[31]_inst_i_24 
       (.I0(\PRODUCT_OBUF[31]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_66_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_67_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_68_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair191" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[31]_inst_i_25 
       (.I0(\PRODUCT_OBUF[31]_inst_i_69_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_70_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_71_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_72_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_73_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[31]_inst_i_26 
       (.I0(\PRODUCT_OBUF[31]_inst_i_45_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_46_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_44_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_43_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair190" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[31]_inst_i_27 
       (.I0(\PRODUCT_OBUF[33]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_46_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_48_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_28 
       (.I0(\PRODUCT_OBUF[29]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[29]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h022FFFFF0000022F)) 
    \PRODUCT_OBUF[31]_inst_i_29 
       (.I0(\PRODUCT_OBUF[27]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[27]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_74_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_75_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT5 #(
    .INIT(32'hFCD4D4C0)) 
    \PRODUCT_OBUF[31]_inst_i_3 
       (.I0(\PRODUCT_OBUF[29]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[29]),
        .I2(CSA_CARRY_wire[29]),
        .I3(CSA_SUM_wire[28]),
        .I4(CSA_CARRY_wire[28]),
        .O(\PRODUCT_OBUF[31]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair222" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[31]_inst_i_30 
       (.I0(\PRODUCT_OBUF[31]_inst_i_76_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_77_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_78_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_79_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_80_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h0069696969FFFFFF)) 
    \PRODUCT_OBUF[31]_inst_i_31 
       (.I0(\PRODUCT_OBUF[31]_inst_i_81_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_82_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_83_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_85_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_86_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair341" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_32 
       (.I0(\PRODUCT_OBUF[31]_inst_i_87_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_88_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_89_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hEEEEE88EE88E8E8E)) 
    \PRODUCT_OBUF[31]_inst_i_33 
       (.I0(\PRODUCT_OBUF[31]_inst_i_90_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_91_n_0 ),
        .I2(B_IBUF[27]),
        .I3(A_IBUF[0]),
        .I4(B_IBUF[25]),
        .I5(B_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[31]_inst_i_34 
       (.I0(\PRODUCT_OBUF[31]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_53_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_92_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_93_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair210" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[31]_inst_i_35 
       (.I0(\PRODUCT_OBUF[31]_inst_i_94_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_95_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_96_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_97_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_98_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[31]_inst_i_36 
       (.I0(\PRODUCT_OBUF[31]_inst_i_51_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_53_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_92_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_93_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair210" *) 
  LUT5 #(
    .INIT(32'hE800FFE8)) 
    \PRODUCT_OBUF[31]_inst_i_37 
       (.I0(\PRODUCT_OBUF[31]_inst_i_94_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_95_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_96_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_98_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_97_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_37_n_0 ));
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[31]_inst_i_38 
       (.I0(\PRODUCT_OBUF[31]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair321" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[31]_inst_i_39 
       (.I0(\PRODUCT_OBUF[31]_inst_i_99_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_100_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_101_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair179" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[31]_inst_i_4 
       (.I0(\PRODUCT_OBUF[33]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[31]));
  (* SOFT_HLUTNM = "soft_lutpair341" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_40 
       (.I0(\PRODUCT_OBUF[31]_inst_i_87_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_89_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_88_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_40_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[31]_inst_i_41 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[13]),
        .I5(\PRODUCT_OBUF[31]_inst_i_102_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[31]_inst_i_42 
       (.I0(\PRODUCT_OBUF[31]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_44_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_48_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_42_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[31]_inst_i_43 
       (.I0(\PRODUCT_OBUF[31]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_49_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair353" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[31]_inst_i_44 
       (.I0(\PRODUCT_OBUF[31]_inst_i_103_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_104_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_105_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_44_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[31]_inst_i_45 
       (.I0(\PRODUCT_OBUF[31]_inst_i_106_n_0 ),
        .I1(A_IBUF[28]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[27]),
        .I5(\PRODUCT_OBUF[31]_inst_i_107_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_45_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[31]_inst_i_46 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[18]),
        .I5(\PRODUCT_OBUF[31]_inst_i_108_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h1717E817E8171717)) 
    \PRODUCT_OBUF[31]_inst_i_47 
       (.I0(\PRODUCT_OBUF[31]_inst_i_109_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_110_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_111_n_0 ),
        .I3(A_IBUF[0]),
        .I4(B_IBUF[27]),
        .I5(B_IBUF[28]),
        .O(\PRODUCT_OBUF[31]_inst_i_47_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_48 
       (.I0(\PRODUCT_OBUF[33]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair322" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[31]_inst_i_49 
       (.I0(\PRODUCT_OBUF[31]_inst_i_112_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_113_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_114_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair189" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[31]_inst_i_5 
       (.I0(\PRODUCT_OBUF[31]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair303" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[31]_inst_i_50 
       (.I0(\PRODUCT_OBUF[31]_inst_i_115_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_116_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_117_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[31]_inst_i_51 
       (.I0(\PRODUCT_OBUF[31]_inst_i_111_n_0 ),
        .I1(A_IBUF[27]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[26]),
        .I5(\PRODUCT_OBUF[31]_inst_i_109_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_51_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF917E89F)) 
    \PRODUCT_OBUF[31]_inst_i_52 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[31]_inst_i_118_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_52_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[31]_inst_i_53 
       (.I0(\PRODUCT_OBUF[31]_inst_i_81_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_83_n_0 ),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_54 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_55 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[31]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_56 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[31]_inst_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair353" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_57 
       (.I0(\PRODUCT_OBUF[31]_inst_i_103_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_104_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_105_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_57_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_58 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[31]_inst_i_58_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[31]_inst_i_59 
       (.I0(\PRODUCT_OBUF[31]_inst_i_106_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_107_n_0 ),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[28]),
        .O(\PRODUCT_OBUF[31]_inst_i_59_n_0 ));
  LUT3 #(
    .INIT(8'h8E)) 
    \PRODUCT_OBUF[31]_inst_i_6 
       (.I0(\PRODUCT_OBUF[31]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair354" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_60 
       (.I0(\PRODUCT_OBUF[31]_inst_i_119_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_120_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_121_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_60_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF917E89F)) 
    \PRODUCT_OBUF[31]_inst_i_61 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[13]),
        .I5(\PRODUCT_OBUF[31]_inst_i_102_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_61_n_0 ));
  LUT6 #(
    .INIT(64'h9966969966999699)) 
    \PRODUCT_OBUF[31]_inst_i_62 
       (.I0(\PRODUCT_OBUF[31]_inst_i_122_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_123_n_0 ),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[29]),
        .O(\PRODUCT_OBUF[31]_inst_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair354" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_63 
       (.I0(\PRODUCT_OBUF[31]_inst_i_119_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_121_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_120_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_63_n_0 ));
  LUT6 #(
    .INIT(64'h88EE8E88EE888E88)) 
    \PRODUCT_OBUF[31]_inst_i_64 
       (.I0(\PRODUCT_OBUF[31]_inst_i_122_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_123_n_0 ),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[0]),
        .I5(A_IBUF[29]),
        .O(\PRODUCT_OBUF[31]_inst_i_64_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[31]_inst_i_65 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[14]),
        .I5(\PRODUCT_OBUF[31]_inst_i_124_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair355" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_66 
       (.I0(\PRODUCT_OBUF[31]_inst_i_125_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_126_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_127_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_66_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[31]_inst_i_67 
       (.I0(\PRODUCT_OBUF[35]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_128_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_129_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_130_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_67_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'h5995)) 
    \PRODUCT_OBUF[31]_inst_i_68 
       (.I0(\PRODUCT_OBUF[31]_inst_i_131_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[29]),
        .I3(B_IBUF[30]),
        .O(\PRODUCT_OBUF[31]_inst_i_68_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_69 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[31]_inst_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[31]_inst_i_7 
       (.I0(\PRODUCT_OBUF[31]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_70 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[31]_inst_i_70_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_71 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[31]_inst_i_71_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair323" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[31]_inst_i_72 
       (.I0(\PRODUCT_OBUF[31]_inst_i_132_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_133_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_134_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_72_n_0 ));
  LUT6 #(
    .INIT(64'hF917E89F06E81760)) 
    \PRODUCT_OBUF[31]_inst_i_73 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[9]),
        .I5(\PRODUCT_OBUF[31]_inst_i_135_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_73_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair340" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_74 
       (.I0(\PRODUCT_OBUF[31]_inst_i_136_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_137_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_138_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_74_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair320" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_75 
       (.I0(\PRODUCT_OBUF[27]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_46_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_75_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_76 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[31]_inst_i_76_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_77 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_77_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_78 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[31]_inst_i_78_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[31]_inst_i_79 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[31]_inst_i_118_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_79_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[31]_inst_i_8 
       (.I0(\PRODUCT_OBUF[31]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair363" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[31]_inst_i_80 
       (.I0(\PRODUCT_OBUF[27]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[27]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[27]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_80_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_81 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[31]_inst_i_81_n_0 ));
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[31]_inst_i_82 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[25]),
        .O(\PRODUCT_OBUF[31]_inst_i_82_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_83 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_83_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[31]_inst_i_84 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[24]),
        .O(\PRODUCT_OBUF[31]_inst_i_84_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_85 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[31]_inst_i_85_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    \PRODUCT_OBUF[31]_inst_i_86 
       (.I0(B_IBUF[27]),
        .I1(B_IBUF[26]),
        .I2(B_IBUF[25]),
        .O(\PRODUCT_OBUF[31]_inst_i_86_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[31]_inst_i_87 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[31]_inst_i_87_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_88 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[31]_inst_i_88_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_89 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[31]_inst_i_89_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair197" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[31]_inst_i_9 
       (.I0(\PRODUCT_OBUF[31]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_90 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[31]_inst_i_90_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_91 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[31]_inst_i_91_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair321" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_92 
       (.I0(\PRODUCT_OBUF[31]_inst_i_101_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_100_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_99_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_92_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair303" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[31]_inst_i_93 
       (.I0(\PRODUCT_OBUF[31]_inst_i_115_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_117_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_116_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_93_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_94 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[31]_inst_i_94_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_95 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[31]_inst_i_95_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_96 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[31]_inst_i_96_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair340" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[31]_inst_i_97 
       (.I0(\PRODUCT_OBUF[31]_inst_i_138_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_137_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_136_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_97_n_0 ));
  LUT6 #(
    .INIT(64'hF917E89F06E81760)) 
    \PRODUCT_OBUF[31]_inst_i_98 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[18]),
        .I5(\PRODUCT_OBUF[31]_inst_i_108_n_0 ),
        .O(\PRODUCT_OBUF[31]_inst_i_98_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[31]_inst_i_99 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[31]_inst_i_99_n_0 ));
  OBUF \PRODUCT_OBUF[32]_inst 
       (.I(PRODUCT_OBUF[32]),
        .O(PRODUCT[32]));
  (* SOFT_HLUTNM = "soft_lutpair367" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[32]_inst_i_1 
       (.I0(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[32]),
        .I2(CSA_CARRY_wire[32]),
        .O(PRODUCT_OBUF[32]));
  OBUF \PRODUCT_OBUF[33]_inst 
       (.I(PRODUCT_OBUF[33]),
        .O(PRODUCT[33]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[33]_inst_i_1 
       (.I0(CSA_CARRY_wire[32]),
        .I1(CSA_SUM_wire[32]),
        .I2(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[33]),
        .I4(CSA_CARRY_wire[33]),
        .O(PRODUCT_OBUF[33]));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[33]_inst_i_10 
       (.I0(\PRODUCT_OBUF[35]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair189" *) 
  LUT5 #(
    .INIT(32'hFF4D4D00)) 
    \PRODUCT_OBUF[33]_inst_i_11 
       (.I0(\PRODUCT_OBUF[31]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair289" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[33]_inst_i_12 
       (.I0(\PRODUCT_OBUF[35]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[33]_inst_i_13 
       (.I0(\PRODUCT_OBUF[33]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_30_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_31_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF1FF)) 
    \PRODUCT_OBUF[33]_inst_i_14 
       (.I0(CSA_CARRY_wire[17]),
        .I1(CSA_SUM_wire[17]),
        .I2(\PRODUCT_OBUF[21]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_33_n_0 ),
        .I5(\PRODUCT_OBUF[21]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h0400040004000404)) 
    \PRODUCT_OBUF[33]_inst_i_15 
       (.I0(\PRODUCT_OBUF[33]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_36_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_7_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hECC8C880FEECECC8)) 
    \PRODUCT_OBUF[33]_inst_i_16 
       (.I0(CSA_CARRY_wire[30]),
        .I1(CSA_SUM_wire[31]),
        .I2(\PRODUCT_OBUF[31]_inst_i_5_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_6_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_7_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'h00000004)) 
    \PRODUCT_OBUF[33]_inst_i_17 
       (.I0(\PRODUCT_OBUF[33]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_36_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[29]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h0E0F000F)) 
    \PRODUCT_OBUF[33]_inst_i_18 
       (.I0(\PRODUCT_OBUF[21]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_40_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair342" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_19 
       (.I0(\PRODUCT_OBUF[31]_inst_i_62_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_60_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_61_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair179" *) 
  LUT5 #(
    .INIT(32'h006969FF)) 
    \PRODUCT_OBUF[33]_inst_i_2 
       (.I0(\PRODUCT_OBUF[33]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[32]));
  (* SOFT_HLUTNM = "soft_lutpair297" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_20 
       (.I0(\PRODUCT_OBUF[31]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_59_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_21 
       (.I0(\PRODUCT_OBUF[31]_inst_i_71_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_70_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT5 #(
    .INIT(32'h88E8E8EE)) 
    \PRODUCT_OBUF[33]_inst_i_22 
       (.I0(\PRODUCT_OBUF[33]_inst_i_42_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_43_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_44_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_46_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair190" *) 
  LUT5 #(
    .INIT(32'h001717FF)) 
    \PRODUCT_OBUF[33]_inst_i_23 
       (.I0(\PRODUCT_OBUF[33]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_46_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_47_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'hF66F6FF660060660)) 
    \PRODUCT_OBUF[33]_inst_i_24 
       (.I0(\PRODUCT_OBUF[31]_inst_i_66_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_67_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_63_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_64_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_65_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_68_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair191" *) 
  LUT5 #(
    .INIT(32'hE800FFE8)) 
    \PRODUCT_OBUF[33]_inst_i_25 
       (.I0(\PRODUCT_OBUF[31]_inst_i_69_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_70_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_71_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_73_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_72_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[33]_inst_i_26 
       (.I0(\PRODUCT_OBUF[35]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_53_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_52_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_51_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair192" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[33]_inst_i_27 
       (.I0(\PRODUCT_OBUF[31]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_56_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_62_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_28 
       (.I0(\PRODUCT_OBUF[35]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair217" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[33]_inst_i_29 
       (.I0(\PRODUCT_OBUF[33]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_40_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair180" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[33]_inst_i_3 
       (.I0(\PRODUCT_OBUF[33]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_13_n_0 ),
        .O(CSA_SUM_wire[32]));
  (* SOFT_HLUTNM = "soft_lutpair313" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_30 
       (.I0(\PRODUCT_OBUF[35]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h17E8E8E8171717E8)) 
    \PRODUCT_OBUF[33]_inst_i_31 
       (.I0(\PRODUCT_OBUF[33]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_56_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_57_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair257" *) 
  LUT4 #(
    .INIT(16'hEEE0)) 
    \PRODUCT_OBUF[33]_inst_i_32 
       (.I0(CSA_SUM_wire[23]),
        .I1(CSA_CARRY_wire[23]),
        .I2(CSA_SUM_wire[22]),
        .I3(CSA_CARRY_wire[22]),
        .O(\PRODUCT_OBUF[33]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair258" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[33]_inst_i_33 
       (.I0(CSA_SUM_wire[21]),
        .I1(CSA_CARRY_wire[21]),
        .I2(CSA_SUM_wire[20]),
        .I3(CSA_CARRY_wire[20]),
        .O(\PRODUCT_OBUF[33]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT5 #(
    .INIT(32'h51107DD3)) 
    \PRODUCT_OBUF[33]_inst_i_34 
       (.I0(CSA_SUM_wire[29]),
        .I1(\PRODUCT_OBUF[29]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_12_n_0 ),
        .I4(CSA_CARRY_wire[28]),
        .O(\PRODUCT_OBUF[33]_inst_i_34_n_0 ));
  LUT6 #(
    .INIT(64'hFF69FF96FF96FF69)) 
    \PRODUCT_OBUF[33]_inst_i_35 
       (.I0(\PRODUCT_OBUF[33]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_9_n_0 ),
        .I3(CSA_CARRY_wire[31]),
        .I4(\PRODUCT_OBUF[33]_inst_i_10_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair369" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[33]_inst_i_36 
       (.I0(CSA_CARRY_wire[30]),
        .I1(CSA_SUM_wire[30]),
        .O(\PRODUCT_OBUF[33]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT4 #(
    .INIT(16'hF880)) 
    \PRODUCT_OBUF[33]_inst_i_37 
       (.I0(CSA_CARRY_wire[26]),
        .I1(CSA_SUM_wire[26]),
        .I2(CSA_CARRY_wire[27]),
        .I3(CSA_SUM_wire[27]),
        .O(\PRODUCT_OBUF[33]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair256" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[33]_inst_i_38 
       (.I0(CSA_CARRY_wire[24]),
        .I1(CSA_SUM_wire[24]),
        .I2(CSA_CARRY_wire[25]),
        .I3(CSA_SUM_wire[25]),
        .O(\PRODUCT_OBUF[33]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT5 #(
    .INIT(32'h40D4FDFF)) 
    \PRODUCT_OBUF[33]_inst_i_39 
       (.I0(CSA_CARRY_wire[28]),
        .I1(\PRODUCT_OBUF[29]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[29]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[29]_inst_i_10_n_0 ),
        .I4(CSA_SUM_wire[29]),
        .O(\PRODUCT_OBUF[33]_inst_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFF4FFF0FFFFFFF0)) 
    \PRODUCT_OBUF[33]_inst_i_4 
       (.I0(\PRODUCT_OBUF[33]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[17]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_17_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT4 #(
    .INIT(16'hF880)) 
    \PRODUCT_OBUF[33]_inst_i_40 
       (.I0(CSA_CARRY_wire[22]),
        .I1(CSA_SUM_wire[22]),
        .I2(CSA_SUM_wire[23]),
        .I3(CSA_CARRY_wire[23]),
        .O(\PRODUCT_OBUF[33]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair258" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[33]_inst_i_41 
       (.I0(CSA_CARRY_wire[20]),
        .I1(CSA_SUM_wire[20]),
        .I2(CSA_CARRY_wire[21]),
        .I3(CSA_SUM_wire[21]),
        .O(\PRODUCT_OBUF[33]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair323" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[33]_inst_i_42 
       (.I0(\PRODUCT_OBUF[31]_inst_i_134_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_133_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_132_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_42_n_0 ));
  LUT6 #(
    .INIT(64'h0115555555555555)) 
    \PRODUCT_OBUF[33]_inst_i_43 
       (.I0(\PRODUCT_OBUF[33]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_111_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_110_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_109_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_61_n_0 ),
        .I5(A_IBUF[0]),
        .O(\PRODUCT_OBUF[33]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_44 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[33]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_45 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[33]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_46 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[33]_inst_i_46_n_0 ));
  LUT6 #(
    .INIT(64'hF917E89F06E81760)) 
    \PRODUCT_OBUF[33]_inst_i_47 
       (.I0(B_IBUF[14]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[14]),
        .I5(\PRODUCT_OBUF[31]_inst_i_124_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair322" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[33]_inst_i_48 
       (.I0(\PRODUCT_OBUF[31]_inst_i_112_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_114_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_113_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_49 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[33]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair171" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[33]_inst_i_5 
       (.I0(\PRODUCT_OBUF[35]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[33]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_50 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[33]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_51 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[33]_inst_i_51_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001E66780)) 
    \PRODUCT_OBUF[33]_inst_i_52 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[11]),
        .I5(\PRODUCT_OBUF[35]_inst_i_94_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_52_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair246" *) 
  LUT4 #(
    .INIT(16'h4878)) 
    \PRODUCT_OBUF[33]_inst_i_53 
       (.I0(A_IBUF[31]),
        .I1(B_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(A_IBUF[30]),
        .O(\PRODUCT_OBUF[33]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[33]_inst_i_54 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[33]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[33]_inst_i_55 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[33]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_56 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[33]_inst_i_56_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[33]_inst_i_57 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[33]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[33]_inst_i_58 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[33]_inst_i_58_n_0 ));
  LUT6 #(
    .INIT(64'hFF6F6F6666060600)) 
    \PRODUCT_OBUF[33]_inst_i_59 
       (.I0(\PRODUCT_OBUF[31]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[30]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_12_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_7_n_0 ),
        .O(CSA_CARRY_wire[31]));
  (* SOFT_HLUTNM = "soft_lutpair180" *) 
  LUT5 #(
    .INIT(32'hD400FFD4)) 
    \PRODUCT_OBUF[33]_inst_i_6 
       (.I0(\PRODUCT_OBUF[33]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_13_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[33]));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT4 #(
    .INIT(16'h022A)) 
    \PRODUCT_OBUF[33]_inst_i_60 
       (.I0(B_IBUF[29]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[27]),
        .I3(B_IBUF[28]),
        .O(\PRODUCT_OBUF[33]_inst_i_60_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PRODUCT_OBUF[33]_inst_i_61 
       (.I0(B_IBUF[27]),
        .I1(B_IBUF[28]),
        .O(\PRODUCT_OBUF[33]_inst_i_61_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT5 #(
    .INIT(32'hD400FFD4)) 
    \PRODUCT_OBUF[33]_inst_i_7 
       (.I0(\PRODUCT_OBUF[33]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[33]_inst_i_8 
       (.I0(\PRODUCT_OBUF[31]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT5 #(
    .INIT(32'hD44D4DD4)) 
    \PRODUCT_OBUF[33]_inst_i_9 
       (.I0(\PRODUCT_OBUF[31]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[33]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[34]_inst 
       (.I(PRODUCT_OBUF[34]),
        .O(PRODUCT[34]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[34]_inst_i_1 
       (.I0(\PRODUCT_OBUF[35]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[34]),
        .I2(CSA_CARRY_wire[34]),
        .O(PRODUCT_OBUF[34]));
  OBUF \PRODUCT_OBUF[35]_inst 
       (.I(PRODUCT_OBUF[35]),
        .O(PRODUCT[35]));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[35]_inst_i_1 
       (.I0(CSA_CARRY_wire[34]),
        .I1(CSA_SUM_wire[34]),
        .I2(\PRODUCT_OBUF[35]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[35]),
        .I4(CSA_CARRY_wire[35]),
        .O(PRODUCT_OBUF[35]));
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[35]_inst_i_10 
       (.I0(\PRODUCT_OBUF[35]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_100 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[35]_inst_i_100_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_101 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[35]_inst_i_101_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_102 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[35]_inst_i_102_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_103 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[35]_inst_i_103_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_104 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[35]_inst_i_104_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_105 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[35]_inst_i_105_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[35]_inst_i_106 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[35]_inst_i_106_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_107 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[35]_inst_i_107_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_108 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[35]_inst_i_108_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[35]_inst_i_109 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[35]_inst_i_109_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair289" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[35]_inst_i_11 
       (.I0(\PRODUCT_OBUF[35]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_110 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[35]_inst_i_110_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_111 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[35]_inst_i_111_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_112 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[35]_inst_i_112_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair286" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[35]_inst_i_12 
       (.I0(\PRODUCT_OBUF[37]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[35]_inst_i_13 
       (.I0(\PRODUCT_OBUF[35]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_36_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[35]_inst_i_14 
       (.I0(\PRODUCT_OBUF[35]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_43_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[35]_inst_i_15 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[0]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[35]_inst_i_44_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_15_n_0 ));
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[35]_inst_i_16 
       (.I0(\PRODUCT_OBUF[35]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_49_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[35]_inst_i_17 
       (.I0(\PRODUCT_OBUF[35]_inst_i_51_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair193" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[35]_inst_i_18 
       (.I0(\PRODUCT_OBUF[35]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_56_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_57_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h006969FF69FF0069)) 
    \PRODUCT_OBUF[35]_inst_i_19 
       (.I0(\PRODUCT_OBUF[35]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_59_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_60_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair171" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[35]_inst_i_2 
       (.I0(\PRODUCT_OBUF[35]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[34]));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_20 
       (.I0(\PRODUCT_OBUF[35]_inst_i_56_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[35]_inst_i_21 
       (.I0(\PRODUCT_OBUF[31]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_21_n_0 ));
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[35]_inst_i_22 
       (.I0(\PRODUCT_OBUF[35]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_46_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_61_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_66_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair192" *) 
  LUT5 #(
    .INIT(32'h2B00FF2B)) 
    \PRODUCT_OBUF[35]_inst_i_23 
       (.I0(\PRODUCT_OBUF[31]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_56_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_62_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h96000096FF9696FF)) 
    \PRODUCT_OBUF[35]_inst_i_24 
       (.I0(\PRODUCT_OBUF[35]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_43_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_40_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair193" *) 
  LUT5 #(
    .INIT(32'h1700FF17)) 
    \PRODUCT_OBUF[35]_inst_i_25 
       (.I0(\PRODUCT_OBUF[35]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_56_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_57_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h9AAA655565559AAA)) 
    \PRODUCT_OBUF[35]_inst_i_26 
       (.I0(\PRODUCT_OBUF[35]_inst_i_64_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[37]_inst_i_26_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair183" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[35]_inst_i_27 
       (.I0(\PRODUCT_OBUF[35]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_67_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_68_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair218" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[35]_inst_i_28 
       (.I0(\PRODUCT_OBUF[35]_inst_i_70_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_71_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_72_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_73_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_74_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair205" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[35]_inst_i_29 
       (.I0(\PRODUCT_OBUF[35]_inst_i_75_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_76_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_77_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_78_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_79_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair172" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[35]_inst_i_3 
       (.I0(\PRODUCT_OBUF[35]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_13_n_0 ),
        .O(CSA_SUM_wire[34]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[35]_inst_i_30 
       (.I0(\PRODUCT_OBUF[35]_inst_i_80_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_81_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_82_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT5 #(
    .INIT(32'h2882BEEB)) 
    \PRODUCT_OBUF[35]_inst_i_31 
       (.I0(\PRODUCT_OBUF[33]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[35]_inst_i_32 
       (.I0(\PRODUCT_OBUF[35]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT5 #(
    .INIT(32'h444D4DDD)) 
    \PRODUCT_OBUF[35]_inst_i_33 
       (.I0(\PRODUCT_OBUF[33]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h9AAA655565559AAA)) 
    \PRODUCT_OBUF[35]_inst_i_34 
       (.I0(\PRODUCT_OBUF[35]_inst_i_83_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[39]_inst_i_50_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair184" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[35]_inst_i_35 
       (.I0(\PRODUCT_OBUF[35]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_67_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_66_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_85_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair200" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[35]_inst_i_36 
       (.I0(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_89_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_90_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[35]_inst_i_37 
       (.I0(\PRODUCT_OBUF[39]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[35]_inst_i_38 
       (.I0(\PRODUCT_OBUF[35]_inst_i_82_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_81_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_80_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_91_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_92_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT5 #(
    .INIT(32'hE8E817E8)) 
    \PRODUCT_OBUF[35]_inst_i_39 
       (.I0(\PRODUCT_OBUF[33]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_93_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_94_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT5 #(
    .INIT(32'h11171777)) 
    \PRODUCT_OBUF[35]_inst_i_4 
       (.I0(CSA_SUM_wire[33]),
        .I1(CSA_CARRY_wire[33]),
        .I2(CSA_SUM_wire[32]),
        .I3(CSA_CARRY_wire[32]),
        .I4(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h6955A5A596AA5A5A)) 
    \PRODUCT_OBUF[35]_inst_i_40 
       (.I0(\PRODUCT_OBUF[35]_inst_i_95_n_0 ),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[31]),
        .I5(\PRODUCT_OBUF[35]_inst_i_96_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_41 
       (.I0(\PRODUCT_OBUF[35]_inst_i_75_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_77_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_76_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair356" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_42 
       (.I0(\PRODUCT_OBUF[35]_inst_i_97_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_98_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_99_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_42_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair330" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_43 
       (.I0(\PRODUCT_OBUF[35]_inst_i_100_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_101_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_102_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_44 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[35]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_45 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[35]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_46 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[35]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_47 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[35]_inst_i_47_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_48 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[35]_inst_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[35]_inst_i_49 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[9]),
        .I5(\PRODUCT_OBUF[31]_inst_i_135_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair265" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[35]_inst_i_5 
       (.I0(\PRODUCT_OBUF[37]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[35]));
  (* SOFT_HLUTNM = "soft_lutpair355" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[35]_inst_i_50 
       (.I0(\PRODUCT_OBUF[31]_inst_i_125_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_127_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_126_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_50_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_51 
       (.I0(\PRODUCT_OBUF[33]_inst_i_51_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_51_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[35]_inst_i_52 
       (.I0(\PRODUCT_OBUF[33]_inst_i_55_n_0 ),
        .I1(A_IBUF[31]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[30]),
        .I5(\PRODUCT_OBUF[33]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_52_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_53 
       (.I0(\PRODUCT_OBUF[33]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_57_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_54 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[35]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_55 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[35]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_56 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[35]_inst_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT5 #(
    .INIT(32'h00D4D4FF)) 
    \PRODUCT_OBUF[35]_inst_i_57 
       (.I0(\PRODUCT_OBUF[31]_inst_i_130_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_128_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_129_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_103_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_104_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_57_n_0 ));
  LUT6 #(
    .INIT(64'hFE19987F01E66780)) 
    \PRODUCT_OBUF[35]_inst_i_58 
       (.I0(B_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[27]),
        .I4(A_IBUF[6]),
        .I5(\PRODUCT_OBUF[35]_inst_i_105_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_58_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT5 #(
    .INIT(32'h718E8E71)) 
    \PRODUCT_OBUF[35]_inst_i_59 
       (.I0(\PRODUCT_OBUF[31]_inst_i_129_n_0 ),
        .I1(\PRODUCT_OBUF[31]_inst_i_128_n_0 ),
        .I2(\PRODUCT_OBUF[31]_inst_i_130_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_103_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_104_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair172" *) 
  LUT5 #(
    .INIT(32'h00E8E8FF)) 
    \PRODUCT_OBUF[35]_inst_i_6 
       (.I0(\PRODUCT_OBUF[35]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_13_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[35]));
  LUT6 #(
    .INIT(64'h17E8E8E8171717E8)) 
    \PRODUCT_OBUF[35]_inst_i_60 
       (.I0(\PRODUCT_OBUF[35]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_46_n_0 ),
        .I3(\PRODUCT_OBUF[31]_inst_i_126_n_0 ),
        .I4(\PRODUCT_OBUF[31]_inst_i_127_n_0 ),
        .I5(\PRODUCT_OBUF[31]_inst_i_125_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_60_n_0 ));
  LUT6 #(
    .INIT(64'h65956A959A6A956A)) 
    \PRODUCT_OBUF[35]_inst_i_61 
       (.I0(\PRODUCT_OBUF[31]_inst_i_130_n_0 ),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[31]_inst_i_128_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_61_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT5 #(
    .INIT(32'h022A3E2A)) 
    \PRODUCT_OBUF[35]_inst_i_62 
       (.I0(B_IBUF[31]),
        .I1(B_IBUF[30]),
        .I2(B_IBUF[29]),
        .I3(A_IBUF[0]),
        .I4(\PRODUCT_OBUF[31]_inst_i_131_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_62_n_0 ));
  LUT6 #(
    .INIT(64'hFE19987F01E66780)) 
    \PRODUCT_OBUF[35]_inst_i_63 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[11]),
        .I5(\PRODUCT_OBUF[35]_inst_i_94_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_63_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_64 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[35]_inst_i_64_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[35]_inst_i_65 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[35]_inst_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_66 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[35]_inst_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_67 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[35]_inst_i_67_n_0 ));
  LUT6 #(
    .INIT(64'h00E8E8E8000000E8)) 
    \PRODUCT_OBUF[35]_inst_i_68 
       (.I0(\PRODUCT_OBUF[33]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[33]_inst_i_56_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_57_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_68_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT5 #(
    .INIT(32'hFFBFBF00)) 
    \PRODUCT_OBUF[35]_inst_i_69 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[35]_inst_i_45_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h2882BEEB)) 
    \PRODUCT_OBUF[35]_inst_i_7 
       (.I0(\PRODUCT_OBUF[35]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_70 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[35]_inst_i_70_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_71 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[35]_inst_i_71_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_72 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[35]_inst_i_72_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair312" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_73 
       (.I0(\PRODUCT_OBUF[35]_inst_i_106_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_107_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_108_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_73_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair357" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_74 
       (.I0(\PRODUCT_OBUF[39]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_74_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[35]_inst_i_75 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[35]_inst_i_75_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_76 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[35]_inst_i_76_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_77 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[35]_inst_i_77_n_0 ));
  LUT6 #(
    .INIT(64'h6A6A955595956AAA)) 
    \PRODUCT_OBUF[35]_inst_i_78 
       (.I0(\PRODUCT_OBUF[39]_inst_i_66_n_0 ),
        .I1(A_IBUF[31]),
        .I2(s_u_a_IBUF),
        .I3(B_IBUF[0]),
        .I4(B_IBUF[1]),
        .I5(\PRODUCT_OBUF[39]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_78_n_0 ));
  LUT6 #(
    .INIT(64'h0000000001E66780)) 
    \PRODUCT_OBUF[35]_inst_i_79 
       (.I0(B_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[27]),
        .I4(A_IBUF[6]),
        .I5(\PRODUCT_OBUF[35]_inst_i_105_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_79_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT5 #(
    .INIT(32'hABBF022A)) 
    \PRODUCT_OBUF[35]_inst_i_8 
       (.I0(\PRODUCT_OBUF[35]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair330" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[35]_inst_i_80 
       (.I0(\PRODUCT_OBUF[35]_inst_i_102_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_101_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_100_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_80_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair356" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[35]_inst_i_81 
       (.I0(\PRODUCT_OBUF[35]_inst_i_99_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_98_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_97_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_81_n_0 ));
  LUT6 #(
    .INIT(64'h8E8EE888EE8E8888)) 
    \PRODUCT_OBUF[35]_inst_i_82 
       (.I0(\PRODUCT_OBUF[35]_inst_i_95_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_96_n_0 ),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[0]),
        .I4(B_IBUF[1]),
        .I5(s_u_a_IBUF),
        .O(\PRODUCT_OBUF[35]_inst_i_82_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_83 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[35]_inst_i_83_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair275" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_84 
       (.I0(\PRODUCT_OBUF[37]_inst_i_47_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_48_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_84_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair312" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[35]_inst_i_85 
       (.I0(\PRODUCT_OBUF[35]_inst_i_106_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_108_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_107_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_85_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[35]_inst_i_86 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[35]_inst_i_86_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_87 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[35]_inst_i_87_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_88 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[35]_inst_i_88_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair327" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_89 
       (.I0(\PRODUCT_OBUF[35]_inst_i_109_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_110_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_111_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_89_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[35]_inst_i_9 
       (.I0(\PRODUCT_OBUF[35]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair347" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[35]_inst_i_90 
       (.I0(\PRODUCT_OBUF[37]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_51_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_90_n_0 ));
  LUT6 #(
    .INIT(64'hF917E89F06E81760)) 
    \PRODUCT_OBUF[35]_inst_i_91 
       (.I0(B_IBUF[28]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[29]),
        .I4(A_IBUF[5]),
        .I5(\PRODUCT_OBUF[35]_inst_i_112_n_0 ),
        .O(\PRODUCT_OBUF[35]_inst_i_91_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair240" *) 
  LUT4 #(
    .INIT(16'hAA2A)) 
    \PRODUCT_OBUF[35]_inst_i_92 
       (.I0(\PRODUCT_OBUF[35]_inst_i_64_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[1]),
        .I3(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[35]_inst_i_92_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[35]_inst_i_93 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[35]_inst_i_93_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_94 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[35]_inst_i_94_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[35]_inst_i_95 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[35]_inst_i_95_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[35]_inst_i_96 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[35]_inst_i_96_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_97 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[35]_inst_i_97_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_98 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[35]_inst_i_98_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[35]_inst_i_99 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[35]_inst_i_99_n_0 ));
  OBUF \PRODUCT_OBUF[36]_inst 
       (.I(PRODUCT_OBUF[36]),
        .O(PRODUCT[36]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[36]_inst_i_1 
       (.I0(\PRODUCT_OBUF[37]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[36]),
        .I2(CSA_CARRY_wire[36]),
        .O(PRODUCT_OBUF[36]));
  OBUF \PRODUCT_OBUF[37]_inst 
       (.I(PRODUCT_OBUF[37]),
        .O(PRODUCT[37]));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[37]_inst_i_1 
       (.I0(\PRODUCT_OBUF[37]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[36]),
        .I2(CSA_CARRY_wire[36]),
        .I3(CSA_SUM_wire[37]),
        .I4(CSA_CARRY_wire[37]),
        .O(PRODUCT_OBUF[37]));
  (* SOFT_HLUTNM = "soft_lutpair274" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_10 
       (.I0(\PRODUCT_OBUF[37]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair286" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    \PRODUCT_OBUF[37]_inst_i_11 
       (.I0(\PRODUCT_OBUF[37]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[37]_inst_i_12 
       (.I0(\PRODUCT_OBUF[39]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'hA880FEEA)) 
    \PRODUCT_OBUF[37]_inst_i_13 
       (.I0(\PRODUCT_OBUF[37]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_26_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'h14417DD7)) 
    \PRODUCT_OBUF[37]_inst_i_14 
       (.I0(\PRODUCT_OBUF[35]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_48_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[37]_inst_i_15 
       (.I0(\PRODUCT_OBUF[39]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_46_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_16 
       (.I0(\PRODUCT_OBUF[41]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[37]_inst_i_17 
       (.I0(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_30_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair307" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_18 
       (.I0(\PRODUCT_OBUF[37]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hF7F708F708F70808)) 
    \PRODUCT_OBUF[37]_inst_i_19 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[4]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[37]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_36_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair367" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \PRODUCT_OBUF[37]_inst_i_2 
       (.I0(\PRODUCT_OBUF[41]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[37]_inst_i_20 
       (.I0(\PRODUCT_OBUF[37]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_40_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_41_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'h04455DDF)) 
    \PRODUCT_OBUF[37]_inst_i_21 
       (.I0(\PRODUCT_OBUF[35]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[37]_inst_i_22 
       (.I0(\PRODUCT_OBUF[37]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[37]_inst_i_23 
       (.I0(\PRODUCT_OBUF[37]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair183" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[37]_inst_i_24 
       (.I0(\PRODUCT_OBUF[35]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_67_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_68_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair313" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_25 
       (.I0(\PRODUCT_OBUF[35]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_43_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair217" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[37]_inst_i_26 
       (.I0(\PRODUCT_OBUF[33]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[33]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[33]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_40_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair240" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[37]_inst_i_27 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[1]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[35]_inst_i_64_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_27_n_0 ));
  LUT6 #(
    .INIT(64'h06606FF66FF60660)) 
    \PRODUCT_OBUF[37]_inst_i_28 
       (.I0(\PRODUCT_OBUF[35]_inst_i_73_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_44_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_45_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_78_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_46_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_80_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[37]_inst_i_29 
       (.I0(\PRODUCT_OBUF[39]_inst_i_72_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_84_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_89_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_71_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_43_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_73_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair266" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_3 
       (.I0(\PRODUCT_OBUF[37]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_9_n_0 ),
        .O(CSA_SUM_wire[36]));
  (* SOFT_HLUTNM = "soft_lutpair343" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_30 
       (.I0(\PRODUCT_OBUF[43]_inst_i_131_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_133_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_132_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair324" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[37]_inst_i_31 
       (.I0(\PRODUCT_OBUF[43]_inst_i_130_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_129_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_128_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair328" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[37]_inst_i_32 
       (.I0(\PRODUCT_OBUF[39]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_59_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair348" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_33 
       (.I0(\PRODUCT_OBUF[39]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair306" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_34 
       (.I0(\PRODUCT_OBUF[39]_inst_i_68_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_70_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_34_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[37]_inst_i_35 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[37]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hF787878F)) 
    \PRODUCT_OBUF[37]_inst_i_36 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[3]),
        .I3(B_IBUF[2]),
        .I4(B_IBUF[1]),
        .O(\PRODUCT_OBUF[37]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[37]_inst_i_37 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[37]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \PRODUCT_OBUF[37]_inst_i_38 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[3]),
        .I2(B_IBUF[31]),
        .O(\PRODUCT_OBUF[37]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair275" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[37]_inst_i_39 
       (.I0(\PRODUCT_OBUF[37]_inst_i_47_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_48_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_49_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair265" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[37]_inst_i_4 
       (.I0(\PRODUCT_OBUF[37]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[36]));
  (* SOFT_HLUTNM = "soft_lutpair347" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_40 
       (.I0(\PRODUCT_OBUF[37]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair290" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_41 
       (.I0(\PRODUCT_OBUF[39]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_61_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[37]_inst_i_42 
       (.I0(B_IBUF[24]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[25]),
        .I4(A_IBUF[11]),
        .I5(\PRODUCT_OBUF[43]_inst_i_127_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_42_n_0 ));
  LUT6 #(
    .INIT(64'h9669699669969669)) 
    \PRODUCT_OBUF[37]_inst_i_43 
       (.I0(\PRODUCT_OBUF[37]_inst_i_44_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_73_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_45_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_78_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_46_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_80_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_43_n_0 ));
  LUT6 #(
    .INIT(64'h9669699669969669)) 
    \PRODUCT_OBUF[37]_inst_i_44 
       (.I0(\PRODUCT_OBUF[39]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_63_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_70_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_71_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_72_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_44_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT5 #(
    .INIT(32'h4BBB444B)) 
    \PRODUCT_OBUF[37]_inst_i_45 
       (.I0(\PRODUCT_OBUF[35]_inst_i_105_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_53_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_77_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_76_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_75_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_45_n_0 ));
  LUT6 #(
    .INIT(64'h171717E817E8E8E8)) 
    \PRODUCT_OBUF[37]_inst_i_46 
       (.I0(\PRODUCT_OBUF[35]_inst_i_95_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_96_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_54_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_99_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_98_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_97_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[37]_inst_i_47 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[37]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[37]_inst_i_48 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[2]),
        .I3(B_IBUF[3]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[37]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[37]_inst_i_49 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[37]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair267" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[37]_inst_i_5 
       (.I0(\PRODUCT_OBUF[39]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_7_n_0 ),
        .O(CSA_SUM_wire[37]));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[37]_inst_i_50 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[37]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[37]_inst_i_51 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[37]_inst_i_51_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[37]_inst_i_52 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[37]_inst_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[37]_inst_i_53 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[37]_inst_i_53_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair238" *) 
  LUT4 #(
    .INIT(16'h60CC)) 
    \PRODUCT_OBUF[37]_inst_i_54 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[31]),
        .O(\PRODUCT_OBUF[37]_inst_i_54_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair266" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[37]_inst_i_6 
       (.I0(\PRODUCT_OBUF[37]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_8_n_0 ),
        .O(CSA_CARRY_wire[37]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h4DB2B24D)) 
    \PRODUCT_OBUF[37]_inst_i_7 
       (.I0(\PRODUCT_OBUF[39]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair274" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[37]_inst_i_8 
       (.I0(\PRODUCT_OBUF[37]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[37]_inst_i_9 
       (.I0(\PRODUCT_OBUF[37]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[37]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[38]_inst 
       (.I(PRODUCT_OBUF[38]),
        .O(PRODUCT[38]));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[38]_inst_i_1 
       (.I0(\PRODUCT_OBUF[39]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[38]),
        .I2(CSA_CARRY_wire[38]),
        .O(PRODUCT_OBUF[38]));
  OBUF \PRODUCT_OBUF[39]_inst 
       (.I(PRODUCT_OBUF[39]),
        .O(PRODUCT[39]));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[39]_inst_i_1 
       (.I0(CSA_CARRY_wire[38]),
        .I1(CSA_SUM_wire[38]),
        .I2(\PRODUCT_OBUF[39]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[39]),
        .I4(CSA_CARRY_wire[39]),
        .O(PRODUCT_OBUF[39]));
  (* SOFT_HLUTNM = "soft_lutpair268" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[39]_inst_i_10 
       (.I0(\PRODUCT_OBUF[39]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair270" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_11 
       (.I0(\PRODUCT_OBUF[41]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[39]_inst_i_12 
       (.I0(\PRODUCT_OBUF[43]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_38_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_13 
       (.I0(\PRODUCT_OBUF[41]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[39]_inst_i_14 
       (.I0(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_92_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_93_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair276" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_15 
       (.I0(\PRODUCT_OBUF[43]_inst_i_88_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_86_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_87_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[39]_inst_i_16 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[5]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[39]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h4555BAAABAAA4555)) 
    \PRODUCT_OBUF[39]_inst_i_17 
       (.I0(\PRODUCT_OBUF[39]_inst_i_30_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[39]_inst_i_31_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[39]_inst_i_18 
       (.I0(\PRODUCT_OBUF[39]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_34_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_35_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_36_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[39]_inst_i_19 
       (.I0(\PRODUCT_OBUF[39]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair267" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[39]_inst_i_2 
       (.I0(\PRODUCT_OBUF[39]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_9_n_0 ),
        .O(CSA_CARRY_wire[38]));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[39]_inst_i_20 
       (.I0(\PRODUCT_OBUF[39]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_43_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_44_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h444D4DDD)) 
    \PRODUCT_OBUF[39]_inst_i_21 
       (.I0(\PRODUCT_OBUF[39]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_47_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_49_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[39]_inst_i_22 
       (.I0(\PRODUCT_OBUF[39]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_39_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h4114D77D)) 
    \PRODUCT_OBUF[39]_inst_i_23 
       (.I0(\PRODUCT_OBUF[39]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_35_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h718E8E71)) 
    \PRODUCT_OBUF[39]_inst_i_24 
       (.I0(\PRODUCT_OBUF[41]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h088AAEEF)) 
    \PRODUCT_OBUF[39]_inst_i_25 
       (.I0(\PRODUCT_OBUF[39]_inst_i_51_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_40_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[39]_inst_i_26 
       (.I0(\PRODUCT_OBUF[43]_inst_i_80_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_79_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_81_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_85_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_84_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair194" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[39]_inst_i_27 
       (.I0(\PRODUCT_OBUF[43]_inst_i_94_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_95_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_96_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_97_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_98_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_28 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[39]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_29 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[39]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair269" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[39]_inst_i_3 
       (.I0(\PRODUCT_OBUF[39]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[38]));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[39]_inst_i_30 
       (.I0(\PRODUCT_OBUF[37]_inst_i_37_n_0 ),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[2]),
        .I3(B_IBUF[3]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair325" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_31 
       (.I0(\PRODUCT_OBUF[43]_inst_i_118_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_119_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_120_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair291" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[39]_inst_i_32 
       (.I0(\PRODUCT_OBUF[41]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_43_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair348" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[39]_inst_i_33 
       (.I0(\PRODUCT_OBUF[39]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair328" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_34 
       (.I0(\PRODUCT_OBUF[39]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_34_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[39]_inst_i_35 
       (.I0(\PRODUCT_OBUF[37]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[3]),
        .I3(B_IBUF[2]),
        .I4(B_IBUF[1]),
        .I5(\PRODUCT_OBUF[37]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[39]_inst_i_36 
       (.I0(\PRODUCT_OBUF[37]_inst_i_39_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_40_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[3]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[39]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair201" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[39]_inst_i_37 
       (.I0(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair200" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[39]_inst_i_38 
       (.I0(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_90_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_89_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair290" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[39]_inst_i_39 
       (.I0(\PRODUCT_OBUF[39]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_61_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT5 #(
    .INIT(32'hFCD4D4C0)) 
    \PRODUCT_OBUF[39]_inst_i_4 
       (.I0(\PRODUCT_OBUF[37]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[37]),
        .I2(CSA_CARRY_wire[37]),
        .I3(CSA_SUM_wire[36]),
        .I4(CSA_CARRY_wire[36]),
        .O(\PRODUCT_OBUF[39]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair184" *) 
  LUT5 #(
    .INIT(32'h00D4D4FF)) 
    \PRODUCT_OBUF[39]_inst_i_40 
       (.I0(\PRODUCT_OBUF[35]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_67_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_66_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_85_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair357" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[39]_inst_i_41 
       (.I0(\PRODUCT_OBUF[39]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_65_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_41_n_0 ));
  LUT6 #(
    .INIT(64'h40401555D5D57FFF)) 
    \PRODUCT_OBUF[39]_inst_i_42 
       (.I0(\PRODUCT_OBUF[39]_inst_i_66_n_0 ),
        .I1(A_IBUF[31]),
        .I2(s_u_a_IBUF),
        .I3(B_IBUF[0]),
        .I4(B_IBUF[1]),
        .I5(\PRODUCT_OBUF[39]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[39]_inst_i_43 
       (.I0(\PRODUCT_OBUF[35]_inst_i_72_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_71_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_70_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair241" *) 
  LUT4 #(
    .INIT(16'hAA2A)) 
    \PRODUCT_OBUF[39]_inst_i_44 
       (.I0(\PRODUCT_OBUF[35]_inst_i_83_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[2]),
        .I3(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[39]_inst_i_44_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair306" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_45 
       (.I0(\PRODUCT_OBUF[39]_inst_i_68_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_69_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_70_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_45_n_0 ));
  LUT6 #(
    .INIT(64'hF66F60066006F66F)) 
    \PRODUCT_OBUF[39]_inst_i_46 
       (.I0(\PRODUCT_OBUF[35]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_71_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_72_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_73_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_46_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[39]_inst_i_47 
       (.I0(\PRODUCT_OBUF[35]_inst_i_80_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_81_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_82_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_92_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_91_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair241" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[39]_inst_i_48 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[2]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[35]_inst_i_83_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair218" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[39]_inst_i_49 
       (.I0(\PRODUCT_OBUF[35]_inst_i_70_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_71_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_72_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_73_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_74_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair271" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_5 
       (.I0(\PRODUCT_OBUF[41]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_16_n_0 ),
        .O(CSA_SUM_wire[39]));
  (* SOFT_HLUTNM = "soft_lutpair205" *) 
  LUT5 #(
    .INIT(32'h2B00FF2B)) 
    \PRODUCT_OBUF[39]_inst_i_50 
       (.I0(\PRODUCT_OBUF[35]_inst_i_75_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_76_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_77_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_79_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_78_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h06606FF66FF60660)) 
    \PRODUCT_OBUF[39]_inst_i_51 
       (.I0(\PRODUCT_OBUF[39]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_74_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_75_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_76_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_51_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h1700FF17)) 
    \PRODUCT_OBUF[39]_inst_i_52 
       (.I0(\PRODUCT_OBUF[39]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_44_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_52_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[39]_inst_i_53 
       (.I0(\PRODUCT_OBUF[41]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_33_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_34_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[39]_inst_i_54 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[39]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_55 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[39]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_56 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[39]_inst_i_56_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[39]_inst_i_57 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[39]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_58 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[39]_inst_i_58_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_59 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[39]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair269" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[39]_inst_i_6 
       (.I0(\PRODUCT_OBUF[39]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[39]));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[39]_inst_i_60 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[39]_inst_i_60_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_61 
       (.I0(A_IBUF[6]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[7]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[39]_inst_i_61_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_62 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[39]_inst_i_62_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_63 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[39]_inst_i_63_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_64 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[39]_inst_i_64_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_65 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[39]_inst_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_66 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[39]_inst_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_67 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[39]_inst_i_67_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[39]_inst_i_68 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[39]_inst_i_68_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_69 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[39]_inst_i_69_n_0 ));
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[39]_inst_i_7 
       (.I0(\PRODUCT_OBUF[39]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[39]_inst_i_70 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[39]_inst_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[39]_inst_i_71 
       (.I0(\PRODUCT_OBUF[37]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_51_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_71_n_0 ));
  LUT6 #(
    .INIT(64'hD4D42BD42BD42B2B)) 
    \PRODUCT_OBUF[39]_inst_i_72 
       (.I0(\PRODUCT_OBUF[35]_inst_i_106_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_108_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_107_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_65_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_67_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_66_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_72_n_0 ));
  LUT6 #(
    .INIT(64'hE8E8E817E8171717)) 
    \PRODUCT_OBUF[39]_inst_i_73 
       (.I0(\PRODUCT_OBUF[39]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_66_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_77_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_73_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[39]_inst_i_74 
       (.I0(\PRODUCT_OBUF[37]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_35_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_59_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_58_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_74_n_0 ));
  LUT6 #(
    .INIT(64'h718E8E8E7171718E)) 
    \PRODUCT_OBUF[39]_inst_i_75 
       (.I0(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I3(\PRODUCT_OBUF[35]_inst_i_110_n_0 ),
        .I4(\PRODUCT_OBUF[35]_inst_i_111_n_0 ),
        .I5(\PRODUCT_OBUF[35]_inst_i_109_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_75_n_0 ));
  LUT6 #(
    .INIT(64'hF7080808F7F7F708)) 
    \PRODUCT_OBUF[39]_inst_i_76 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[3]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[37]_inst_i_52_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_51_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_76_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair238" *) 
  LUT4 #(
    .INIT(16'h7780)) 
    \PRODUCT_OBUF[39]_inst_i_77 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .O(\PRODUCT_OBUF[39]_inst_i_77_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h4D00FF4D)) 
    \PRODUCT_OBUF[39]_inst_i_8 
       (.I0(\PRODUCT_OBUF[39]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair268" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[39]_inst_i_9 
       (.I0(\PRODUCT_OBUF[39]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[39]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[3]_inst 
       (.I(PRODUCT_OBUF[3]),
        .O(PRODUCT[3]));
  (* SOFT_HLUTNM = "soft_lutpair145" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[3]_inst_i_1 
       (.I0(CSA_SUM_wire[2]),
        .I1(CSA_CARRY_wire[2]),
        .I2(\PRODUCT_OBUF[3]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[3]),
        .I4(CSA_CARRY_wire[3]),
        .O(PRODUCT_OBUF[3]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT5 #(
    .INIT(32'h65956A95)) 
    \PRODUCT_OBUF[3]_inst_i_2 
       (.I0(\PRODUCT_OBUF[3]_inst_i_7_n_0 ),
        .I1(A_IBUF[2]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[1]),
        .O(CSA_SUM_wire[2]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    \PRODUCT_OBUF[3]_inst_i_3 
       (.I0(B_IBUF[3]),
        .I1(B_IBUF[2]),
        .I2(B_IBUF[1]),
        .O(CSA_CARRY_wire[2]));
  LUT4 #(
    .INIT(16'h040C)) 
    \PRODUCT_OBUF[3]_inst_i_4 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[1]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[0]),
        .O(\PRODUCT_OBUF[3]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT5 #(
    .INIT(32'h65956A95)) 
    \PRODUCT_OBUF[3]_inst_i_5 
       (.I0(\PRODUCT_OBUF[5]_inst_i_7_n_0 ),
        .I1(A_IBUF[3]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[2]),
        .O(CSA_SUM_wire[3]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[3]_inst_i_6 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[2]),
        .I4(\PRODUCT_OBUF[3]_inst_i_7_n_0 ),
        .O(CSA_CARRY_wire[3]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT4 #(
    .INIT(16'hF995)) 
    \PRODUCT_OBUF[3]_inst_i_7 
       (.I0(B_IBUF[3]),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[2]),
        .O(\PRODUCT_OBUF[3]_inst_i_7_n_0 ));
  OBUF \PRODUCT_OBUF[40]_inst 
       (.I(PRODUCT_OBUF[40]),
        .O(PRODUCT[40]));
  (* SOFT_HLUTNM = "soft_lutpair365" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[40]_inst_i_1 
       (.I0(\PRODUCT_OBUF[41]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[40]),
        .I2(CSA_CARRY_wire[40]),
        .O(PRODUCT_OBUF[40]));
  OBUF \PRODUCT_OBUF[41]_inst 
       (.I(PRODUCT_OBUF[41]),
        .O(PRODUCT[41]));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[41]_inst_i_1 
       (.I0(\PRODUCT_OBUF[41]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[40]),
        .I2(CSA_CARRY_wire[40]),
        .I3(CSA_SUM_wire[41]),
        .I4(CSA_CARRY_wire[41]),
        .O(PRODUCT_OBUF[41]));
  (* SOFT_HLUTNM = "soft_lutpair254" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[41]_inst_i_10 
       (.I0(CSA_SUM_wire[37]),
        .I1(CSA_CARRY_wire[37]),
        .I2(CSA_SUM_wire[36]),
        .I3(CSA_CARRY_wire[36]),
        .O(\PRODUCT_OBUF[41]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair253" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \PRODUCT_OBUF[41]_inst_i_11 
       (.I0(\PRODUCT_OBUF[49]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair272" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[41]_inst_i_12 
       (.I0(\PRODUCT_OBUF[41]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair148" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[41]_inst_i_13 
       (.I0(\PRODUCT_OBUF[43]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair185" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[41]_inst_i_14 
       (.I0(\PRODUCT_OBUF[43]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_44_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_45_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_47_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_46_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair272" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[41]_inst_i_15 
       (.I0(\PRODUCT_OBUF[41]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair181" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[41]_inst_i_16 
       (.I0(\PRODUCT_OBUF[43]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair270" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[41]_inst_i_17 
       (.I0(\PRODUCT_OBUF[41]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair277" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[41]_inst_i_18 
       (.I0(\PRODUCT_OBUF[43]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair254" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[41]_inst_i_19 
       (.I0(CSA_CARRY_wire[36]),
        .I1(CSA_SUM_wire[36]),
        .I2(CSA_CARRY_wire[37]),
        .I3(CSA_SUM_wire[37]),
        .O(\PRODUCT_OBUF[41]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h5545550555455545)) 
    \PRODUCT_OBUF[41]_inst_i_2 
       (.I0(\PRODUCT_OBUF[41]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_11_n_0 ),
        .I5(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hBEEB2882)) 
    \PRODUCT_OBUF[41]_inst_i_20 
       (.I0(\PRODUCT_OBUF[39]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_37_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_36_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h022AABBF)) 
    \PRODUCT_OBUF[41]_inst_i_21 
       (.I0(\PRODUCT_OBUF[41]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[41]_inst_i_22 
       (.I0(\PRODUCT_OBUF[43]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_38_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hE88E8EE8)) 
    \PRODUCT_OBUF[41]_inst_i_23 
       (.I0(\PRODUCT_OBUF[41]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[41]_inst_i_24 
       (.I0(\PRODUCT_OBUF[41]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h44D4D4DD)) 
    \PRODUCT_OBUF[41]_inst_i_25 
       (.I0(\PRODUCT_OBUF[41]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_25_n_0 ));
  LUT6 #(
    .INIT(64'h009696FF96FF0096)) 
    \PRODUCT_OBUF[41]_inst_i_26 
       (.I0(\PRODUCT_OBUF[43]_inst_i_88_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_86_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_87_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_37_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_92_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[41]_inst_i_27 
       (.I0(\PRODUCT_OBUF[43]_inst_i_94_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_96_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_95_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair307" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    \PRODUCT_OBUF[41]_inst_i_28 
       (.I0(\PRODUCT_OBUF[37]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair149" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[41]_inst_i_29 
       (.I0(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_31_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair273" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[41]_inst_i_3 
       (.I0(\PRODUCT_OBUF[41]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_14_n_0 ),
        .O(CSA_SUM_wire[40]));
  LUT6 #(
    .INIT(64'hFF08FFFF0000FF08)) 
    \PRODUCT_OBUF[41]_inst_i_30 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[4]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[39]_inst_i_30_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_32_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[41]_inst_i_31 
       (.I0(\PRODUCT_OBUF[41]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_92_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_88_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_86_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_87_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h066F6F066F06066F)) 
    \PRODUCT_OBUF[41]_inst_i_32 
       (.I0(\PRODUCT_OBUF[37]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_34_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_33_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h004D4DFF)) 
    \PRODUCT_OBUF[41]_inst_i_33 
       (.I0(\PRODUCT_OBUF[37]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_38_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair147" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[41]_inst_i_34 
       (.I0(\PRODUCT_OBUF[39]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair201" *) 
  LUT5 #(
    .INIT(32'hFF2B2B00)) 
    \PRODUCT_OBUF[41]_inst_i_35 
       (.I0(\PRODUCT_OBUF[35]_inst_i_86_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_88_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair291" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[41]_inst_i_36 
       (.I0(\PRODUCT_OBUF[41]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hD4D4D42BD42B2B2B)) 
    \PRODUCT_OBUF[41]_inst_i_37 
       (.I0(\PRODUCT_OBUF[43]_inst_i_131_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_132_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_133_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_37_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[41]_inst_i_38 
       (.I0(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_130_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_129_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_128_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[41]_inst_i_39 
       (.I0(B_IBUF[28]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[29]),
        .I4(A_IBUF[5]),
        .I5(\PRODUCT_OBUF[35]_inst_i_112_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair271" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[41]_inst_i_4 
       (.I0(\PRODUCT_OBUF[41]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_17_n_0 ),
        .O(CSA_CARRY_wire[40]));
  (* SOFT_HLUTNM = "soft_lutpair327" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[41]_inst_i_40 
       (.I0(\PRODUCT_OBUF[35]_inst_i_109_n_0 ),
        .I1(\PRODUCT_OBUF[35]_inst_i_111_n_0 ),
        .I2(\PRODUCT_OBUF[35]_inst_i_110_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_40_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[41]_inst_i_41 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[6]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[41]_inst_i_41_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[41]_inst_i_42 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[41]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[41]_inst_i_43 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[41]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair148" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[41]_inst_i_5 
       (.I0(\PRODUCT_OBUF[43]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_18_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_8_n_0 ),
        .O(CSA_SUM_wire[41]));
  (* SOFT_HLUTNM = "soft_lutpair273" *) 
  LUT3 #(
    .INIT(8'h4D)) 
    \PRODUCT_OBUF[41]_inst_i_6 
       (.I0(\PRODUCT_OBUF[41]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[41]));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT5 #(
    .INIT(32'hE888EEE8)) 
    \PRODUCT_OBUF[41]_inst_i_7 
       (.I0(CSA_SUM_wire[39]),
        .I1(CSA_CARRY_wire[39]),
        .I2(CSA_SUM_wire[38]),
        .I3(CSA_CARRY_wire[38]),
        .I4(\PRODUCT_OBUF[41]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[41]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT5 #(
    .INIT(32'h032B2B3F)) 
    \PRODUCT_OBUF[41]_inst_i_8 
       (.I0(\PRODUCT_OBUF[49]_inst_i_34_n_0 ),
        .I1(CSA_SUM_wire[35]),
        .I2(CSA_CARRY_wire[35]),
        .I3(CSA_SUM_wire[34]),
        .I4(CSA_CARRY_wire[34]),
        .O(\PRODUCT_OBUF[41]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT4 #(
    .INIT(16'hEEE0)) 
    \PRODUCT_OBUF[41]_inst_i_9 
       (.I0(CSA_SUM_wire[39]),
        .I1(CSA_CARRY_wire[39]),
        .I2(CSA_SUM_wire[38]),
        .I3(CSA_CARRY_wire[38]),
        .O(\PRODUCT_OBUF[41]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[42]_inst 
       (.I(PRODUCT_OBUF[42]),
        .O(PRODUCT[42]));
  (* SOFT_HLUTNM = "soft_lutpair366" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[42]_inst_i_1 
       (.I0(\PRODUCT_OBUF[43]_inst_i_3_n_0 ),
        .I1(CSA_SUM_wire[42]),
        .I2(CSA_CARRY_wire[42]),
        .O(PRODUCT_OBUF[42]));
  LUT6 #(
    .INIT(64'h8E71718E718E8E71)) 
    \PRODUCT_OBUF[42]_inst_i_2 
       (.I0(\PRODUCT_OBUF[43]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_12_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[42]_inst_i_3_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_6_n_0 ),
        .O(CSA_SUM_wire[42]));
  LUT6 #(
    .INIT(64'hB24DB2B24D4DB24D)) 
    \PRODUCT_OBUF[42]_inst_i_3 
       (.I0(\PRODUCT_OBUF[43]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_48_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_29_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[42]_inst_i_3_n_0 ));
  OBUF \PRODUCT_OBUF[43]_inst 
       (.I(PRODUCT_OBUF[43]),
        .O(PRODUCT[43]));
  LUT6 #(
    .INIT(64'h1E87781E87E11E87)) 
    \PRODUCT_OBUF[43]_inst_i_1 
       (.I0(CSA_CARRY_wire[42]),
        .I1(\PRODUCT_OBUF[43]_inst_i_3_n_0 ),
        .I2(CSA_SUM_wire[43]),
        .I3(\PRODUCT_OBUF[43]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[43]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hF7755110)) 
    \PRODUCT_OBUF[43]_inst_i_10 
       (.I0(\PRODUCT_OBUF[43]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_37_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_38_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_100 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[43]_inst_i_100_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_101 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[43]_inst_i_101_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_102 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[43]_inst_i_102_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_103 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[43]_inst_i_103_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_104 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[43]_inst_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_105 
       (.I0(\PRODUCT_OBUF[47]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_60_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_105_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair242" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[43]_inst_i_106 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[8]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[47]_inst_i_77_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_106_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair315" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_107 
       (.I0(\PRODUCT_OBUF[47]_inst_i_74_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_76_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_75_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_107_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'hE800FFE8)) 
    \PRODUCT_OBUF[43]_inst_i_108 
       (.I0(\PRODUCT_OBUF[43]_inst_i_115_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_114_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_113_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_116_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_117_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_108_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_109 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_109_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair278" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_11 
       (.I0(\PRODUCT_OBUF[43]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_110 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[43]_inst_i_110_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_111 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_111_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_112 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[43]_inst_i_112_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_113 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[43]_inst_i_113_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[43]_inst_i_114 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[5]),
        .I2(B_IBUF[6]),
        .I3(B_IBUF[7]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[43]_inst_i_114_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_115 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[43]_inst_i_115_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_116 
       (.I0(A_IBUF[8]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[9]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[43]_inst_i_116_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair243" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \PRODUCT_OBUF[43]_inst_i_117 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[7]),
        .I2(B_IBUF[31]),
        .O(\PRODUCT_OBUF[43]_inst_i_117_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_118 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[43]_inst_i_118_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_119 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_119_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair185" *) 
  LUT5 #(
    .INIT(32'hFF696900)) 
    \PRODUCT_OBUF[43]_inst_i_12 
       (.I0(\PRODUCT_OBUF[43]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_44_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_45_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_46_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_120 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[43]_inst_i_120_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hF787878F)) 
    \PRODUCT_OBUF[43]_inst_i_121 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[5]),
        .I3(B_IBUF[4]),
        .I4(B_IBUF[3]),
        .O(\PRODUCT_OBUF[43]_inst_i_121_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_122 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[43]_inst_i_122_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_123 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[43]_inst_i_123_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_124 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[43]_inst_i_124_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_125 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[43]_inst_i_125_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_126 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_126_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_127 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[43]_inst_i_127_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_128 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[43]_inst_i_128_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_129 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_129_n_0 ));
  LUT6 #(
    .INIT(64'hB24D4DB24DB2B24D)) 
    \PRODUCT_OBUF[43]_inst_i_13 
       (.I0(\PRODUCT_OBUF[43]_inst_i_42_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_41_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_48_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_49_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_130 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[43]_inst_i_130_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_131 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_131_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_132 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[43]_inst_i_132_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_133 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[43]_inst_i_133_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[43]_inst_i_14 
       (.I0(CSA_CARRY_wire[40]),
        .I1(CSA_SUM_wire[40]),
        .I2(CSA_CARRY_wire[41]),
        .I3(CSA_SUM_wire[41]),
        .O(\PRODUCT_OBUF[43]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair280" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[43]_inst_i_15 
       (.I0(\PRODUCT_OBUF[43]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair279" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[43]_inst_i_16 
       (.I0(\PRODUCT_OBUF[43]_inst_i_49_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_50_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_17 
       (.I0(\PRODUCT_OBUF[47]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_42_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h6996696996966996)) 
    \PRODUCT_OBUF[43]_inst_i_18 
       (.I0(\PRODUCT_OBUF[47]_inst_i_45_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_44_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_43_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_41_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair151" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[43]_inst_i_19 
       (.I0(\PRODUCT_OBUF[45]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'hFEEAA880A880FEEA)) 
    \PRODUCT_OBUF[43]_inst_i_2 
       (.I0(\PRODUCT_OBUF[43]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_12_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[42]));
  LUT6 #(
    .INIT(64'hEFEFEF0EEF0E0E0E)) 
    \PRODUCT_OBUF[43]_inst_i_20 
       (.I0(\PRODUCT_OBUF[43]_inst_i_51_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_52_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_53_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_54_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_55_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[43]_inst_i_21 
       (.I0(\PRODUCT_OBUF[43]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_59_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair329" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_22 
       (.I0(\PRODUCT_OBUF[43]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_61_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h65559AAA9AAA6555)) 
    \PRODUCT_OBUF[43]_inst_i_23 
       (.I0(\PRODUCT_OBUF[43]_inst_i_63_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[43]_inst_i_64_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_65_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair154" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_24 
       (.I0(\PRODUCT_OBUF[45]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair279" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_25 
       (.I0(\PRODUCT_OBUF[43]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair278" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[43]_inst_i_26 
       (.I0(\PRODUCT_OBUF[43]_inst_i_41_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_40_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_26_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[43]_inst_i_27 
       (.I0(\PRODUCT_OBUF[47]_inst_i_67_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_64_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_63_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair182" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[43]_inst_i_28 
       (.I0(\PRODUCT_OBUF[43]_inst_i_59_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_57_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_68_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[43]_inst_i_29 
       (.I0(\PRODUCT_OBUF[47]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_59_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_60_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_62_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_61_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_29_n_0 ));
  LUT4 #(
    .INIT(16'h01FF)) 
    \PRODUCT_OBUF[43]_inst_i_3 
       (.I0(\PRODUCT_OBUF[47]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_2_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[43]_inst_i_30 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[6]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[43]_inst_i_66_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair332" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_31 
       (.I0(\PRODUCT_OBUF[43]_inst_i_68_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_69_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_70_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair304" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[43]_inst_i_32 
       (.I0(\PRODUCT_OBUF[43]_inst_i_71_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_72_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_73_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[43]_inst_i_33 
       (.I0(\PRODUCT_OBUF[43]_inst_i_74_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_75_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_76_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_77_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_78_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[43]_inst_i_34 
       (.I0(\PRODUCT_OBUF[43]_inst_i_79_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_80_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_81_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_82_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_83_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[43]_inst_i_35 
       (.I0(\PRODUCT_OBUF[43]_inst_i_81_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_79_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_80_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_84_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_85_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair276" *) 
  LUT3 #(
    .INIT(8'h4D)) 
    \PRODUCT_OBUF[43]_inst_i_36 
       (.I0(\PRODUCT_OBUF[43]_inst_i_86_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_87_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_88_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair150" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[43]_inst_i_37 
       (.I0(\PRODUCT_OBUF[43]_inst_i_89_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_90_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_91_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_92_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_93_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_37_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair304" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_38 
       (.I0(\PRODUCT_OBUF[43]_inst_i_71_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_73_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_72_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair194" *) 
  LUT5 #(
    .INIT(32'hFF2B2B00)) 
    \PRODUCT_OBUF[43]_inst_i_39 
       (.I0(\PRODUCT_OBUF[43]_inst_i_94_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_95_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_96_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_97_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_98_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_39_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[43]_inst_i_4 
       (.I0(\PRODUCT_OBUF[43]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_18_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_19_n_0 ),
        .O(CSA_SUM_wire[43]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hEEE8E888)) 
    \PRODUCT_OBUF[43]_inst_i_40 
       (.I0(\PRODUCT_OBUF[43]_inst_i_83_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_82_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_81_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_80_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_79_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'h009696FF)) 
    \PRODUCT_OBUF[43]_inst_i_41 
       (.I0(\PRODUCT_OBUF[43]_inst_i_76_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_75_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_74_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_78_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_77_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_41_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[43]_inst_i_42 
       (.I0(\PRODUCT_OBUF[43]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_42_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair298" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[43]_inst_i_43 
       (.I0(\PRODUCT_OBUF[43]_inst_i_99_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_100_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_101_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair314" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[43]_inst_i_44 
       (.I0(\PRODUCT_OBUF[43]_inst_i_102_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_103_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_104_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_44_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[43]_inst_i_45 
       (.I0(B_IBUF[16]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[17]),
        .I4(A_IBUF[23]),
        .I5(\PRODUCT_OBUF[43]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_45_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[43]_inst_i_46 
       (.I0(\PRODUCT_OBUF[47]_inst_i_67_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_105_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_106_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_46_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[43]_inst_i_47 
       (.I0(\PRODUCT_OBUF[43]_inst_i_74_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_76_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_75_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_107_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_108_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_47_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[43]_inst_i_48 
       (.I0(\PRODUCT_OBUF[43]_inst_i_43_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_45_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'h8EE8E88E)) 
    \PRODUCT_OBUF[43]_inst_i_49 
       (.I0(\PRODUCT_OBUF[43]_inst_i_106_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_105_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_66_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_49_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_5 
       (.I0(\PRODUCT_OBUF[43]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'h8E00FF8E)) 
    \PRODUCT_OBUF[43]_inst_i_50 
       (.I0(\PRODUCT_OBUF[43]_inst_i_75_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_76_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_74_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_108_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_107_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_51 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_51_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_52 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_52_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair239" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \PRODUCT_OBUF[43]_inst_i_53 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[9]),
        .I2(B_IBUF[31]),
        .O(\PRODUCT_OBUF[43]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_54 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[43]_inst_i_54_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[43]_inst_i_55 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[7]),
        .I2(B_IBUF[8]),
        .I3(B_IBUF[9]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[43]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_56 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[43]_inst_i_56_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_57 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[43]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_58 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[43]_inst_i_58_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_59 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[43]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[43]_inst_i_6 
       (.I0(\PRODUCT_OBUF[43]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_22_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_60 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[43]_inst_i_60_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_61 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_61_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_62 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_62_n_0 ));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[43]_inst_i_63 
       (.I0(\PRODUCT_OBUF[45]_inst_i_27_n_0 ),
        .I1(B_IBUF[7]),
        .I2(B_IBUF[8]),
        .I3(B_IBUF[9]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[45]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_64 
       (.I0(\PRODUCT_OBUF[47]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_64_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair292" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_65 
       (.I0(\PRODUCT_OBUF[45]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_66 
       (.I0(A_IBUF[7]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[8]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[43]_inst_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_67 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[43]_inst_i_67_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_68 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[43]_inst_i_68_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_69 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[43]_inst_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair277" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[43]_inst_i_7 
       (.I0(\PRODUCT_OBUF[43]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_25_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_70 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[43]_inst_i_70_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_71 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[43]_inst_i_71_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_72 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[43]_inst_i_72_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_73 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[43]_inst_i_73_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair331" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[43]_inst_i_74 
       (.I0(\PRODUCT_OBUF[43]_inst_i_109_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_110_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_111_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_74_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[43]_inst_i_75 
       (.I0(\PRODUCT_OBUF[47]_inst_i_78_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[7]),
        .I3(B_IBUF[6]),
        .I4(B_IBUF[5]),
        .I5(\PRODUCT_OBUF[47]_inst_i_79_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_75_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF917E89F)) 
    \PRODUCT_OBUF[43]_inst_i_76 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[43]_inst_i_112_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_76_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair298" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_77 
       (.I0(\PRODUCT_OBUF[43]_inst_i_101_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_100_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_99_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_77_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[43]_inst_i_78 
       (.I0(\PRODUCT_OBUF[43]_inst_i_113_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_114_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_115_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_116_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_117_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_78_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair325" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[43]_inst_i_79 
       (.I0(\PRODUCT_OBUF[43]_inst_i_118_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_119_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_120_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_79_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair280" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_8 
       (.I0(\PRODUCT_OBUF[43]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_80 
       (.I0(\PRODUCT_OBUF[43]_inst_i_113_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_114_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_115_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_80_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair331" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_81 
       (.I0(\PRODUCT_OBUF[43]_inst_i_111_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_110_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_109_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_81_n_0 ));
  LUT6 #(
    .INIT(64'h7100000071717100)) 
    \PRODUCT_OBUF[43]_inst_i_82 
       (.I0(\PRODUCT_OBUF[43]_inst_i_121_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_122_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_123_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_124_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_125_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_126_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_82_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair314" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[43]_inst_i_83 
       (.I0(\PRODUCT_OBUF[43]_inst_i_102_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_103_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_104_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_83_n_0 ));
  LUT6 #(
    .INIT(64'h8E7171718E8E8E71)) 
    \PRODUCT_OBUF[43]_inst_i_84 
       (.I0(\PRODUCT_OBUF[43]_inst_i_121_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_122_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_123_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_124_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_125_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_126_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_84_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[43]_inst_i_85 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[6]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[43]_inst_i_67_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_66_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_85_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[43]_inst_i_86 
       (.I0(\PRODUCT_OBUF[43]_inst_i_126_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_125_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_124_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_86_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF917E89F)) 
    \PRODUCT_OBUF[43]_inst_i_87 
       (.I0(B_IBUF[24]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[25]),
        .I4(A_IBUF[11]),
        .I5(\PRODUCT_OBUF[43]_inst_i_127_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_87_n_0 ));
  LUT6 #(
    .INIT(64'h6666999669996666)) 
    \PRODUCT_OBUF[43]_inst_i_88 
       (.I0(\PRODUCT_OBUF[43]_inst_i_123_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_122_n_0 ),
        .I2(B_IBUF[3]),
        .I3(B_IBUF[4]),
        .I4(B_IBUF[5]),
        .I5(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_88_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_89 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[43]_inst_i_89_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair181" *) 
  LUT5 #(
    .INIT(32'hFF969600)) 
    \PRODUCT_OBUF[43]_inst_i_9 
       (.I0(\PRODUCT_OBUF[43]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_32_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_33_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[43]_inst_i_90 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[3]),
        .I2(B_IBUF[4]),
        .I3(B_IBUF[5]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[43]_inst_i_90_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_91 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[43]_inst_i_91_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair324" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[43]_inst_i_92 
       (.I0(\PRODUCT_OBUF[43]_inst_i_128_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_129_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_130_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_92_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair343" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[43]_inst_i_93 
       (.I0(\PRODUCT_OBUF[43]_inst_i_131_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_132_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_133_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_93_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[43]_inst_i_94 
       (.I0(A_IBUF[10]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[11]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[43]_inst_i_94_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_95 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[43]_inst_i_95_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_96 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[43]_inst_i_96_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[43]_inst_i_97 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[5]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[39]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_97_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[43]_inst_i_98 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[43]_inst_i_112_n_0 ),
        .O(\PRODUCT_OBUF[43]_inst_i_98_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[43]_inst_i_99 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[43]_inst_i_99_n_0 ));
  OBUF \PRODUCT_OBUF[44]_inst 
       (.I(PRODUCT_OBUF[44]),
        .O(PRODUCT[44]));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \PRODUCT_OBUF[44]_inst_i_1 
       (.I0(\PRODUCT_OBUF[47]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_3_n_0 ),
        .O(PRODUCT_OBUF[44]));
  OBUF \PRODUCT_OBUF[45]_inst 
       (.I(PRODUCT_OBUF[45]),
        .O(PRODUCT[45]));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT5 #(
    .INIT(32'h0DF2F20D)) 
    \PRODUCT_OBUF[45]_inst_i_1 
       (.I0(\PRODUCT_OBUF[47]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_3_n_0 ),
        .I3(CSA_SUM_wire[45]),
        .I4(CSA_CARRY_wire[45]),
        .O(PRODUCT_OBUF[45]));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[45]_inst_i_10 
       (.I0(\PRODUCT_OBUF[45]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[45]_inst_i_11 
       (.I0(B_IBUF[12]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[13]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[45]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h000008F708F7FFFF)) 
    \PRODUCT_OBUF[45]_inst_i_12 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[10]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[43]_inst_i_63_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_65_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_64_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0000F700F700F7F7)) 
    \PRODUCT_OBUF[45]_inst_i_13 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[10]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[45]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_26_n_0 ),
        .I5(\PRODUCT_OBUF[45]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair292" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[45]_inst_i_14 
       (.I0(\PRODUCT_OBUF[45]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[45]_inst_i_15 
       (.I0(\PRODUCT_OBUF[49]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[11]),
        .I3(B_IBUF[10]),
        .I4(B_IBUF[9]),
        .I5(\PRODUCT_OBUF[49]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair202" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[45]_inst_i_16 
       (.I0(\PRODUCT_OBUF[47]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_52_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_51_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair195" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[45]_inst_i_17 
       (.I0(\PRODUCT_OBUF[47]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_56_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_18 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[45]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_19 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[45]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h9669699600000000)) 
    \PRODUCT_OBUF[45]_inst_i_2 
       (.I0(\PRODUCT_OBUF[47]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_22_n_0 ),
        .I5(CSA_CARRY_wire[44]),
        .O(\PRODUCT_OBUF[45]_inst_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_20 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[45]_inst_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_21 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[45]_inst_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_22 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[45]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_23 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[45]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[45]_inst_i_24 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[9]),
        .I2(B_IBUF[10]),
        .I3(B_IBUF[11]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[45]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_25 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[45]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'hF787878F)) 
    \PRODUCT_OBUF[45]_inst_i_26 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[9]),
        .I3(B_IBUF[8]),
        .I4(B_IBUF[7]),
        .O(\PRODUCT_OBUF[45]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[45]_inst_i_27 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[45]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_28 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[45]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_29 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[45]_inst_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0000000069969669)) 
    \PRODUCT_OBUF[45]_inst_i_3 
       (.I0(\PRODUCT_OBUF[47]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_22_n_0 ),
        .I5(CSA_CARRY_wire[44]),
        .O(\PRODUCT_OBUF[45]_inst_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[45]_inst_i_30 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[45]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[45]_inst_i_4 
       (.I0(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[45]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'h2BB2B22B)) 
    \PRODUCT_OBUF[45]_inst_i_5 
       (.I0(\PRODUCT_OBUF[47]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .O(CSA_CARRY_wire[45]));
  (* SOFT_HLUTNM = "soft_lutpair281" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[45]_inst_i_6 
       (.I0(\PRODUCT_OBUF[47]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair154" *) 
  LUT5 #(
    .INIT(32'h004D4DFF)) 
    \PRODUCT_OBUF[45]_inst_i_7 
       (.I0(\PRODUCT_OBUF[45]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair151" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[45]_inst_i_8 
       (.I0(\PRODUCT_OBUF[45]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair309" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[45]_inst_i_9 
       (.I0(\PRODUCT_OBUF[45]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[45]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[46]_inst 
       (.I(PRODUCT_OBUF[46]),
        .O(PRODUCT[46]));
  LUT5 #(
    .INIT(32'h2F2FD02F)) 
    \PRODUCT_OBUF[46]_inst_i_1 
       (.I0(\PRODUCT_OBUF[47]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_5_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_6_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_3_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[46]));
  OBUF \PRODUCT_OBUF[47]_inst 
       (.I(PRODUCT_OBUF[47]),
        .O(PRODUCT[47]));
  LUT6 #(
    .INIT(64'hEEAEAAAA11515555)) 
    \PRODUCT_OBUF[47]_inst_i_1 
       (.I0(\PRODUCT_OBUF[47]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[47]));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[47]_inst_i_10 
       (.I0(\PRODUCT_OBUF[49]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair158" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[47]_inst_i_11 
       (.I0(\PRODUCT_OBUF[50]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_42_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_41_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_12 
       (.I0(\PRODUCT_OBUF[49]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_9_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'hFFD4D400)) 
    \PRODUCT_OBUF[47]_inst_i_13 
       (.I0(\PRODUCT_OBUF[47]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_33_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_35_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_13_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[47]_inst_i_14 
       (.I0(\PRODUCT_OBUF[47]_inst_i_10_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_8_n_0 ),
        .O(CSA_CARRY_wire[46]));
  (* SOFT_HLUTNM = "soft_lutpair282" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_15 
       (.I0(\PRODUCT_OBUF[47]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[46]));
  (* SOFT_HLUTNM = "soft_lutpair365" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[47]_inst_i_16 
       (.I0(CSA_CARRY_wire[40]),
        .I1(CSA_SUM_wire[40]),
        .O(\PRODUCT_OBUF[47]_inst_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[47]_inst_i_17 
       (.I0(CSA_CARRY_wire[41]),
        .I1(CSA_SUM_wire[41]),
        .O(\PRODUCT_OBUF[47]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair366" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[47]_inst_i_18 
       (.I0(CSA_CARRY_wire[42]),
        .I1(CSA_SUM_wire[42]),
        .O(\PRODUCT_OBUF[47]_inst_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[47]_inst_i_19 
       (.I0(CSA_CARRY_wire[43]),
        .I1(CSA_SUM_wire[43]),
        .O(\PRODUCT_OBUF[47]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h0017170017000017)) 
    \PRODUCT_OBUF[47]_inst_i_2 
       (.I0(\PRODUCT_OBUF[47]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_12_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBABABABBBABBBBBB)) 
    \PRODUCT_OBUF[47]_inst_i_20 
       (.I0(\PRODUCT_OBUF[47]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_38_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_18_n_0 ),
        .I3(CSA_SUM_wire[41]),
        .I4(CSA_CARRY_wire[41]),
        .I5(\PRODUCT_OBUF[47]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hBBB2B222)) 
    \PRODUCT_OBUF[47]_inst_i_21 
       (.I0(\PRODUCT_OBUF[43]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_17_n_0 ),
        .O(CSA_CARRY_wire[44]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_22 
       (.I0(\PRODUCT_OBUF[47]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_34_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_23 
       (.I0(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h4D00004DFF4D4DFF)) 
    \PRODUCT_OBUF[47]_inst_i_24 
       (.I0(\PRODUCT_OBUF[47]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_41_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_42_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_43_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_44_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair282" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[47]_inst_i_25 
       (.I0(\PRODUCT_OBUF[47]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[47]));
  (* SOFT_HLUTNM = "soft_lutpair153" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[47]_inst_i_26 
       (.I0(\PRODUCT_OBUF[49]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[47]));
  LUT6 #(
    .INIT(64'h69FF0069006969FF)) 
    \PRODUCT_OBUF[47]_inst_i_27 
       (.I0(\PRODUCT_OBUF[49]_inst_i_57_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_56_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_33_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_46_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_27_n_0 ));
  LUT4 #(
    .INIT(16'hA995)) 
    \PRODUCT_OBUF[47]_inst_i_28 
       (.I0(\PRODUCT_OBUF[49]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_46_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_49_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_28_n_0 ));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[47]_inst_i_29 
       (.I0(\PRODUCT_OBUF[45]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \PRODUCT_OBUF[47]_inst_i_3 
       (.I0(CSA_CARRY_wire[46]),
        .I1(CSA_SUM_wire[46]),
        .O(\PRODUCT_OBUF[47]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair202" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[47]_inst_i_30 
       (.I0(\PRODUCT_OBUF[47]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_49_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_50_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair195" *) 
  LUT5 #(
    .INIT(32'h96FF0096)) 
    \PRODUCT_OBUF[47]_inst_i_31 
       (.I0(\PRODUCT_OBUF[47]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_54_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_55_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_56_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair284" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[47]_inst_i_32 
       (.I0(\PRODUCT_OBUF[49]_inst_i_56_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_32_n_0 ));
  LUT6 #(
    .INIT(64'hE8E817E817E81717)) 
    \PRODUCT_OBUF[47]_inst_i_33 
       (.I0(\PRODUCT_OBUF[49]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_53_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_54_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h9AAA655565559AAA)) 
    \PRODUCT_OBUF[47]_inst_i_34 
       (.I0(\PRODUCT_OBUF[49]_inst_i_43_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[49]_inst_i_49_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_48_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair281" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[47]_inst_i_35 
       (.I0(\PRODUCT_OBUF[47]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair283" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_36 
       (.I0(\PRODUCT_OBUF[49]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hF9909090F9F9F990)) 
    \PRODUCT_OBUF[47]_inst_i_37 
       (.I0(\PRODUCT_OBUF[43]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[42]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_6_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_25_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[43]));
  LUT5 #(
    .INIT(32'hEB3E2A02)) 
    \PRODUCT_OBUF[47]_inst_i_38 
       (.I0(CSA_SUM_wire[43]),
        .I1(\PRODUCT_OBUF[43]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_5_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_6_n_0 ),
        .I4(CSA_CARRY_wire[42]),
        .O(\PRODUCT_OBUF[47]_inst_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h7100007100717100)) 
    \PRODUCT_OBUF[47]_inst_i_39 
       (.I0(\PRODUCT_OBUF[41]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[41]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_14_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_13_n_0 ),
        .I5(\PRODUCT_OBUF[41]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h0E)) 
    \PRODUCT_OBUF[47]_inst_i_4 
       (.I0(CSA_CARRY_wire[45]),
        .I1(CSA_SUM_wire[45]),
        .I2(\PRODUCT_OBUF[45]_inst_i_3_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair186" *) 
  LUT5 #(
    .INIT(32'h002B2BFF)) 
    \PRODUCT_OBUF[47]_inst_i_40 
       (.I0(\PRODUCT_OBUF[47]_inst_i_58_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_59_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_60_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_61_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h88E8E8EE)) 
    \PRODUCT_OBUF[47]_inst_i_41 
       (.I0(\PRODUCT_OBUF[47]_inst_i_63_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_64_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_65_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_66_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair182" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[47]_inst_i_42 
       (.I0(\PRODUCT_OBUF[43]_inst_i_59_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_58_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_57_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_68_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_69_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_42_n_0 ));
  LUT6 #(
    .INIT(64'hB2B24DB24DB24D4D)) 
    \PRODUCT_OBUF[47]_inst_i_43 
       (.I0(\PRODUCT_OBUF[45]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_70_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_65_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_64_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair152" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    \PRODUCT_OBUF[47]_inst_i_44 
       (.I0(\PRODUCT_OBUF[43]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_44_n_0 ));
  LUT6 #(
    .INIT(64'hF66F60066006F66F)) 
    \PRODUCT_OBUF[47]_inst_i_45 
       (.I0(\PRODUCT_OBUF[47]_inst_i_70_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_71_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_72_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_20_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_73_n_0 ),
        .I5(\PRODUCT_OBUF[45]_inst_i_9_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_45_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair243" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[47]_inst_i_46 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[12]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[49]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[47]_inst_i_47 
       (.I0(\PRODUCT_OBUF[49]_inst_i_62_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_63_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_64_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_65_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_66_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_47_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_48 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[47]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_49 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[47]_inst_i_49_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF0000FFFE0000)) 
    \PRODUCT_OBUF[47]_inst_i_5 
       (.I0(\PRODUCT_OBUF[47]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_20_n_0 ),
        .I5(\PRODUCT_OBUF[41]_inst_i_2_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_50 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[47]_inst_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[47]_inst_i_51 
       (.I0(B_IBUF[12]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[13]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[45]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_51_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair329" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[47]_inst_i_52 
       (.I0(\PRODUCT_OBUF[43]_inst_i_60_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_62_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_61_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[47]_inst_i_53 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[47]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_54 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[47]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_55 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[47]_inst_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_56 
       (.I0(\PRODUCT_OBUF[49]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[47]_inst_i_57 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[11]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[49]_inst_i_72_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_71_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_57_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[47]_inst_i_58 
       (.I0(A_IBUF[11]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[47]_inst_i_58_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_59 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[47]_inst_i_59_n_0 ));
  LUT5 #(
    .INIT(32'h7110FFF7)) 
    \PRODUCT_OBUF[47]_inst_i_6 
       (.I0(CSA_CARRY_wire[44]),
        .I1(\PRODUCT_OBUF[47]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_24_n_0 ),
        .I4(CSA_SUM_wire[45]),
        .O(\PRODUCT_OBUF[47]_inst_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_60 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[47]_inst_i_60_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair315" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[47]_inst_i_61 
       (.I0(\PRODUCT_OBUF[47]_inst_i_74_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_75_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_76_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_61_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[47]_inst_i_62 
       (.I0(\PRODUCT_OBUF[45]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[9]),
        .I3(B_IBUF[8]),
        .I4(B_IBUF[7]),
        .I5(\PRODUCT_OBUF[45]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_62_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_63 
       (.I0(\PRODUCT_OBUF[45]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_63_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair242" *) 
  LUT4 #(
    .INIT(16'hAA2A)) 
    \PRODUCT_OBUF[47]_inst_i_64 
       (.I0(\PRODUCT_OBUF[47]_inst_i_77_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[8]),
        .I3(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[47]_inst_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_65 
       (.I0(\PRODUCT_OBUF[43]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_65_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair332" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[47]_inst_i_66 
       (.I0(\PRODUCT_OBUF[43]_inst_i_68_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_69_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_70_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_66_n_0 ));
  LUT6 #(
    .INIT(64'hF7D7D7DF51414145)) 
    \PRODUCT_OBUF[47]_inst_i_67 
       (.I0(\PRODUCT_OBUF[47]_inst_i_78_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[7]),
        .I3(B_IBUF[6]),
        .I4(B_IBUF[5]),
        .I5(\PRODUCT_OBUF[47]_inst_i_79_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_67_n_0 ));
  LUT6 #(
    .INIT(64'hE8E8E817171717E8)) 
    \PRODUCT_OBUF[47]_inst_i_68 
       (.I0(\PRODUCT_OBUF[43]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_56_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_51_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_52_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_53_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_68_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair309" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[47]_inst_i_69 
       (.I0(\PRODUCT_OBUF[45]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PRODUCT_OBUF[47]_inst_i_7 
       (.I0(CSA_CARRY_wire[47]),
        .I1(CSA_SUM_wire[47]),
        .O(\PRODUCT_OBUF[47]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0808F708F708F7F7)) 
    \PRODUCT_OBUF[47]_inst_i_70 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[10]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[45]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_26_n_0 ),
        .I5(\PRODUCT_OBUF[45]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h6996966996696996)) 
    \PRODUCT_OBUF[47]_inst_i_71 
       (.I0(\PRODUCT_OBUF[45]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_29_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_30_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_48_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_49_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_50_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_71_n_0 ));
  LUT6 #(
    .INIT(64'h9696966996696969)) 
    \PRODUCT_OBUF[47]_inst_i_72 
       (.I0(\PRODUCT_OBUF[43]_inst_i_62_n_0 ),
        .I1(\PRODUCT_OBUF[43]_inst_i_61_n_0 ),
        .I2(\PRODUCT_OBUF[43]_inst_i_60_n_0 ),
        .I3(\PRODUCT_OBUF[43]_inst_i_59_n_0 ),
        .I4(\PRODUCT_OBUF[43]_inst_i_58_n_0 ),
        .I5(\PRODUCT_OBUF[43]_inst_i_57_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_72_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h99969666)) 
    \PRODUCT_OBUF[47]_inst_i_73 
       (.I0(\PRODUCT_OBUF[45]_inst_i_24_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_80_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[45]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[45]_inst_i_21_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_73_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[47]_inst_i_74 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[47]_inst_i_74_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_75 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[47]_inst_i_75_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_76 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[47]_inst_i_76_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_77 
       (.I0(A_IBUF[9]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[10]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[47]_inst_i_77_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_78 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[11]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[9]),
        .I4(B_IBUF[10]),
        .O(\PRODUCT_OBUF[47]_inst_i_78_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[47]_inst_i_79 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[9]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[7]),
        .I4(B_IBUF[8]),
        .O(\PRODUCT_OBUF[47]_inst_i_79_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[47]_inst_i_8 
       (.I0(\PRODUCT_OBUF[45]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[45]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[45]_inst_i_6_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[47]_inst_i_80 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[47]_inst_i_80_n_0 ));
  LUT6 #(
    .INIT(64'h9696699669966969)) 
    \PRODUCT_OBUF[47]_inst_i_9 
       (.I0(\PRODUCT_OBUF[47]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_28_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_30_n_0 ),
        .I5(\PRODUCT_OBUF[47]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[47]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[48]_inst 
       (.I(PRODUCT_OBUF[48]),
        .O(PRODUCT[48]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \PRODUCT_OBUF[48]_inst_i_1 
       (.I0(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[48]));
  OBUF \PRODUCT_OBUF[49]_inst 
       (.I(PRODUCT_OBUF[49]),
        .O(PRODUCT[49]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT5 #(
    .INIT(32'h45BABA45)) 
    \PRODUCT_OBUF[49]_inst_i_1 
       (.I0(\PRODUCT_OBUF[49]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[49]),
        .I4(CSA_CARRY_wire[49]),
        .O(PRODUCT_OBUF[49]));
  (* SOFT_HLUTNM = "soft_lutpair163" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[49]_inst_i_10 
       (.I0(\PRODUCT_OBUF[51]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[49]_inst_i_11 
       (.I0(\PRODUCT_OBUF[49]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[49]_inst_i_12 
       (.I0(\PRODUCT_OBUF[49]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_20_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_21_n_0 ),
        .O(CSA_SUM_wire[48]));
  LUT3 #(
    .INIT(8'hF4)) 
    \PRODUCT_OBUF[49]_inst_i_13 
       (.I0(\PRODUCT_OBUF[47]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000FF0E)) 
    \PRODUCT_OBUF[49]_inst_i_14 
       (.I0(\PRODUCT_OBUF[49]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_36_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_37_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_38_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_39_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFD)) 
    \PRODUCT_OBUF[49]_inst_i_15 
       (.I0(\PRODUCT_OBUF[49]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[47]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[47]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair253" *) 
  LUT4 #(
    .INIT(16'hFFFD)) 
    \PRODUCT_OBUF[49]_inst_i_16 
       (.I0(\PRODUCT_OBUF[41]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[41]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_40_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair158" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[49]_inst_i_17 
       (.I0(\PRODUCT_OBUF[50]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_16_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_41_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[49]_inst_i_18 
       (.I0(\PRODUCT_OBUF[50]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair157" *) 
  LUT5 #(
    .INIT(32'h2BFF002B)) 
    \PRODUCT_OBUF[49]_inst_i_19 
       (.I0(\PRODUCT_OBUF[49]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_26_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h000000002BFF002B)) 
    \PRODUCT_OBUF[49]_inst_i_2 
       (.I0(\PRODUCT_OBUF[49]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_11_n_0 ),
        .I5(CSA_SUM_wire[48]),
        .O(\PRODUCT_OBUF[49]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair160" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[49]_inst_i_20 
       (.I0(\PRODUCT_OBUF[50]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h6996696969696969)) 
    \PRODUCT_OBUF[49]_inst_i_21 
       (.I0(\PRODUCT_OBUF[51]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_15_n_0 ),
        .I3(s_u_b_IBUF),
        .I4(A_IBUF[16]),
        .I5(B_IBUF[31]),
        .O(\PRODUCT_OBUF[49]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair300" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[49]_inst_i_22 
       (.I0(\PRODUCT_OBUF[50]_inst_i_32_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair317" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[49]_inst_i_23 
       (.I0(\PRODUCT_OBUF[50]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_34_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[49]_inst_i_24 
       (.I0(\PRODUCT_OBUF[50]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[13]),
        .I3(B_IBUF[12]),
        .I4(B_IBUF[11]),
        .I5(\PRODUCT_OBUF[50]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFF7FFF7FFFF)) 
    \PRODUCT_OBUF[49]_inst_i_25 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[12]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[49]_inst_i_43_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_44_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h2222B222)) 
    \PRODUCT_OBUF[49]_inst_i_26 
       (.I0(\PRODUCT_OBUF[49]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_47_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[13]),
        .I4(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[49]_inst_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hEFFF10001000EFFF)) 
    \PRODUCT_OBUF[49]_inst_i_27 
       (.I0(\PRODUCT_OBUF[49]_inst_i_43_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[12]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[49]_inst_i_44_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_27_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[49]_inst_i_28 
       (.I0(\PRODUCT_OBUF[49]_inst_i_46_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_47_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[13]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[49]_inst_i_28_n_0 ));
  LUT6 #(
    .INIT(64'h1111711177771777)) 
    \PRODUCT_OBUF[49]_inst_i_29 
       (.I0(\PRODUCT_OBUF[49]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_49_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[12]),
        .I4(s_u_b_IBUF),
        .I5(\PRODUCT_OBUF[49]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hD400FFD400000000)) 
    \PRODUCT_OBUF[49]_inst_i_3 
       (.I0(\PRODUCT_OBUF[49]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_11_n_0 ),
        .I5(CSA_SUM_wire[48]),
        .O(\PRODUCT_OBUF[49]_inst_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000E800E800E8E8)) 
    \PRODUCT_OBUF[49]_inst_i_30 
       (.I0(\PRODUCT_OBUF[49]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_51_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_52_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_53_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_54_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_55_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair284" *) 
  LUT3 #(
    .INIT(8'hD4)) 
    \PRODUCT_OBUF[49]_inst_i_31 
       (.I0(\PRODUCT_OBUF[49]_inst_i_56_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_57_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_58_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_31_n_0 ));
  LUT6 #(
    .INIT(64'h000000000E0E0E00)) 
    \PRODUCT_OBUF[49]_inst_i_32 
       (.I0(CSA_CARRY_wire[45]),
        .I1(CSA_SUM_wire[45]),
        .I2(\PRODUCT_OBUF[47]_inst_i_2_n_0 ),
        .I3(CSA_CARRY_wire[47]),
        .I4(CSA_SUM_wire[47]),
        .I5(\PRODUCT_OBUF[45]_inst_i_3_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_32_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT5 #(
    .INIT(32'hE888EEE8)) 
    \PRODUCT_OBUF[49]_inst_i_33 
       (.I0(CSA_SUM_wire[47]),
        .I1(CSA_CARRY_wire[47]),
        .I2(CSA_SUM_wire[46]),
        .I3(CSA_CARRY_wire[46]),
        .I4(\PRODUCT_OBUF[47]_inst_i_6_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair255" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[49]_inst_i_34 
       (.I0(CSA_CARRY_wire[32]),
        .I1(CSA_SUM_wire[32]),
        .I2(CSA_CARRY_wire[33]),
        .I3(CSA_SUM_wire[33]),
        .O(\PRODUCT_OBUF[49]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[49]_inst_i_35 
       (.I0(CSA_SUM_wire[34]),
        .I1(CSA_CARRY_wire[34]),
        .I2(CSA_SUM_wire[35]),
        .I3(CSA_CARRY_wire[35]),
        .O(\PRODUCT_OBUF[49]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT4 #(
    .INIT(16'hF880)) 
    \PRODUCT_OBUF[49]_inst_i_36 
       (.I0(CSA_CARRY_wire[34]),
        .I1(CSA_SUM_wire[34]),
        .I2(CSA_CARRY_wire[35]),
        .I3(CSA_SUM_wire[35]),
        .O(\PRODUCT_OBUF[49]_inst_i_36_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF111FFFFFFFFF)) 
    \PRODUCT_OBUF[49]_inst_i_37 
       (.I0(CSA_CARRY_wire[36]),
        .I1(CSA_SUM_wire[36]),
        .I2(CSA_CARRY_wire[37]),
        .I3(CSA_SUM_wire[37]),
        .I4(\PRODUCT_OBUF[49]_inst_i_59_n_0 ),
        .I5(\PRODUCT_OBUF[49]_inst_i_60_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hFFE8E80000000000)) 
    \PRODUCT_OBUF[49]_inst_i_38 
       (.I0(\PRODUCT_OBUF[49]_inst_i_61_n_0 ),
        .I1(CSA_CARRY_wire[37]),
        .I2(CSA_SUM_wire[37]),
        .I3(CSA_CARRY_wire[38]),
        .I4(CSA_SUM_wire[38]),
        .I5(\PRODUCT_OBUF[49]_inst_i_60_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \PRODUCT_OBUF[49]_inst_i_39 
       (.I0(CSA_CARRY_wire[39]),
        .I1(CSA_SUM_wire[39]),
        .O(\PRODUCT_OBUF[49]_inst_i_39_n_0 ));
  LUT5 #(
    .INIT(32'h54505454)) 
    \PRODUCT_OBUF[49]_inst_i_4 
       (.I0(\PRODUCT_OBUF[49]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[33]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair255" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[49]_inst_i_40 
       (.I0(CSA_SUM_wire[33]),
        .I1(CSA_CARRY_wire[33]),
        .I2(CSA_SUM_wire[32]),
        .I3(CSA_CARRY_wire[32]),
        .O(\PRODUCT_OBUF[49]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair244" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[49]_inst_i_41 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[14]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[50]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair164" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[49]_inst_i_42 
       (.I0(\PRODUCT_OBUF[50]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_43 
       (.I0(A_IBUF[13]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[14]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[49]_inst_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair299" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[49]_inst_i_44 
       (.I0(\PRODUCT_OBUF[49]_inst_i_62_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_63_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_64_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_44_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair316" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[49]_inst_i_45 
       (.I0(\PRODUCT_OBUF[49]_inst_i_65_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_67_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_45_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair285" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[49]_inst_i_46 
       (.I0(\PRODUCT_OBUF[49]_inst_i_68_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_69_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_70_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_47 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[49]_inst_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair299" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[49]_inst_i_48 
       (.I0(\PRODUCT_OBUF[49]_inst_i_64_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_63_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_62_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_48_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair316" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[49]_inst_i_49 
       (.I0(\PRODUCT_OBUF[49]_inst_i_67_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_66_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_65_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_49_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair260" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[49]_inst_i_5 
       (.I0(\PRODUCT_OBUF[50]_inst_i_3_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_4_n_0 ),
        .O(CSA_SUM_wire[49]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_50 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[49]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_51 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[49]_inst_i_51_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_52 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[49]_inst_i_52_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_53 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[49]_inst_i_53_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'hF787878F)) 
    \PRODUCT_OBUF[49]_inst_i_54 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[11]),
        .I3(B_IBUF[10]),
        .I4(B_IBUF[9]),
        .O(\PRODUCT_OBUF[49]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[49]_inst_i_55 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[13]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[11]),
        .I4(B_IBUF[12]),
        .O(\PRODUCT_OBUF[49]_inst_i_55_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair285" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[49]_inst_i_56 
       (.I0(\PRODUCT_OBUF[49]_inst_i_70_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_69_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_68_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_56_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[49]_inst_i_57 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[11]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[49]_inst_i_71_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_72_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_57_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[49]_inst_i_58 
       (.I0(\PRODUCT_OBUF[47]_inst_i_53_n_0 ),
        .I1(\PRODUCT_OBUF[47]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[47]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_58_n_0 ));
  LUT6 #(
    .INIT(64'hE80000E800E8E800)) 
    \PRODUCT_OBUF[49]_inst_i_59 
       (.I0(\PRODUCT_OBUF[39]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[39]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[39]_inst_i_11_n_0 ),
        .I5(\PRODUCT_OBUF[39]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_59_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair156" *) 
  LUT5 #(
    .INIT(32'hFF2B2B00)) 
    \PRODUCT_OBUF[49]_inst_i_6 
       (.I0(\PRODUCT_OBUF[49]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_19_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_20_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_21_n_0 ),
        .O(CSA_CARRY_wire[49]));
  LUT6 #(
    .INIT(64'hFFB2B2FFB2FFFFB2)) 
    \PRODUCT_OBUF[49]_inst_i_60 
       (.I0(\PRODUCT_OBUF[39]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[39]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[39]_inst_i_11_n_0 ),
        .I3(\PRODUCT_OBUF[41]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[41]_inst_i_15_n_0 ),
        .I5(\PRODUCT_OBUF[41]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_60_n_0 ));
  LUT6 #(
    .INIT(64'hB20000B200B2B200)) 
    \PRODUCT_OBUF[49]_inst_i_61 
       (.I0(\PRODUCT_OBUF[37]_inst_i_12_n_0 ),
        .I1(\PRODUCT_OBUF[37]_inst_i_11_n_0 ),
        .I2(\PRODUCT_OBUF[37]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[37]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[37]_inst_i_8_n_0 ),
        .I5(\PRODUCT_OBUF[37]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_61_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_62 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[49]_inst_i_62_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_63 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[49]_inst_i_63_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_64 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[49]_inst_i_64_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_65 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[49]_inst_i_65_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_66 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[49]_inst_i_66_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_67 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[49]_inst_i_67_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_68 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[49]_inst_i_68_n_0 ));
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[49]_inst_i_69 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[11]),
        .I2(B_IBUF[12]),
        .I3(B_IBUF[13]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[49]_inst_i_69_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair157" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[49]_inst_i_7 
       (.I0(\PRODUCT_OBUF[49]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_70 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[49]_inst_i_70_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_71 
       (.I0(A_IBUF[12]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[13]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[49]_inst_i_71_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[49]_inst_i_72 
       (.I0(A_IBUF[14]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[15]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[49]_inst_i_72_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair155" *) 
  LUT5 #(
    .INIT(32'h69FF0069)) 
    \PRODUCT_OBUF[49]_inst_i_8 
       (.I0(\PRODUCT_OBUF[49]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_23_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_24_n_0 ),
        .I3(\PRODUCT_OBUF[49]_inst_i_27_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair283" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[49]_inst_i_9 
       (.I0(\PRODUCT_OBUF[49]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_30_n_0 ),
        .I2(\PRODUCT_OBUF[49]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[49]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[4]_inst 
       (.I(PRODUCT_OBUF[4]),
        .O(PRODUCT[4]));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[4]_inst_i_1 
       (.I0(\PRODUCT_OBUF[5]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[4]),
        .I2(CSA_CARRY_wire[4]),
        .O(PRODUCT_OBUF[4]));
  OBUF \PRODUCT_OBUF[50]_inst 
       (.I(PRODUCT_OBUF[50]),
        .O(PRODUCT[50]));
  (* SOFT_HLUTNM = "soft_lutpair159" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[50]_inst_i_1 
       (.I0(\PRODUCT_OBUF[50]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_3_n_0 ),
        .I4(CSA_SUM_wire[50]),
        .O(PRODUCT_OBUF[50]));
  (* SOFT_HLUTNM = "soft_lutpair162" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[50]_inst_i_10 
       (.I0(\PRODUCT_OBUF[51]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[50]_inst_i_11 
       (.I0(\PRODUCT_OBUF[53]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_13_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair305" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[50]_inst_i_12 
       (.I0(\PRODUCT_OBUF[50]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[50]_inst_i_13 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[17]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[50]_inst_i_28_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair300" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[50]_inst_i_14 
       (.I0(\PRODUCT_OBUF[50]_inst_i_30_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_31_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_32_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair317" *) 
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[50]_inst_i_15 
       (.I0(\PRODUCT_OBUF[50]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_34_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_15_n_0 ));
  LUT6 #(
    .INIT(64'hEEEE888EE888EEEE)) 
    \PRODUCT_OBUF[50]_inst_i_16 
       (.I0(\PRODUCT_OBUF[50]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_37_n_0 ),
        .I2(B_IBUF[11]),
        .I3(B_IBUF[12]),
        .I4(B_IBUF[13]),
        .I5(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_17 
       (.I0(A_IBUF[15]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[50]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[50]_inst_i_18 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[50]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[50]_inst_i_19 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[13]),
        .I2(B_IBUF[14]),
        .I3(B_IBUF[15]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[50]_inst_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[50]_inst_i_2 
       (.I0(\PRODUCT_OBUF[51]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_9_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_20 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[50]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair310" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[50]_inst_i_21 
       (.I0(\PRODUCT_OBUF[50]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_40_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[50]_inst_i_22 
       (.I0(B_IBUF[28]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[29]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[51]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair293" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[50]_inst_i_23 
       (.I0(\PRODUCT_OBUF[51]_inst_i_38_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[50]_inst_i_24 
       (.I0(\PRODUCT_OBUF[51]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_34_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[15]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[50]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_25 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[50]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_26 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[50]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_27 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[50]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_28 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[50]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_29 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[50]_inst_i_29_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair160" *) 
  LUT5 #(
    .INIT(32'h00D4D4FF)) 
    \PRODUCT_OBUF[50]_inst_i_3 
       (.I0(\PRODUCT_OBUF[50]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_10_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_30 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[50]_inst_i_30_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_31 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[50]_inst_i_31_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_32 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[50]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[50]_inst_i_33 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[50]_inst_i_33_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_34 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[50]_inst_i_34_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_35 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[50]_inst_i_35_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[50]_inst_i_36 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[50]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'h3066660C)) 
    \PRODUCT_OBUF[50]_inst_i_37 
       (.I0(A_IBUF[31]),
        .I1(B_IBUF[15]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[13]),
        .I4(B_IBUF[14]),
        .O(\PRODUCT_OBUF[50]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_38 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[50]_inst_i_38_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_39 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[50]_inst_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[50]_inst_i_4 
       (.I0(\PRODUCT_OBUF[50]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[50]_inst_i_40 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[50]_inst_i_40_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair161" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[50]_inst_i_5 
       (.I0(\PRODUCT_OBUF[51]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[50]));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[50]_inst_i_6 
       (.I0(\PRODUCT_OBUF[50]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_15_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair244" *) 
  LUT4 #(
    .INIT(16'hAA2A)) 
    \PRODUCT_OBUF[50]_inst_i_7 
       (.I0(\PRODUCT_OBUF[50]_inst_i_17_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[14]),
        .I3(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[50]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair164" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[50]_inst_i_8 
       (.I0(\PRODUCT_OBUF[50]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair163" *) 
  LUT5 #(
    .INIT(32'h009696FF)) 
    \PRODUCT_OBUF[50]_inst_i_9 
       (.I0(\PRODUCT_OBUF[51]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_18_n_0 ),
        .I3(\PRODUCT_OBUF[50]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[50]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[51]_inst 
       (.I(PRODUCT_OBUF[51]),
        .O(PRODUCT[51]));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT5 #(
    .INIT(32'h0EF1F10E)) 
    \PRODUCT_OBUF[51]_inst_i_1 
       (.I0(\PRODUCT_OBUF[51]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[51]),
        .I4(CSA_CARRY_wire[51]),
        .O(PRODUCT_OBUF[51]));
  (* SOFT_HLUTNM = "soft_lutpair162" *) 
  LUT5 #(
    .INIT(32'h2BFF002B)) 
    \PRODUCT_OBUF[51]_inst_i_10 
       (.I0(\PRODUCT_OBUF[51]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_19_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[51]_inst_i_11 
       (.I0(\PRODUCT_OBUF[50]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_41_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h9669699669969669)) 
    \PRODUCT_OBUF[51]_inst_i_12 
       (.I0(\PRODUCT_OBUF[55]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_25_n_0 ),
        .I5(\PRODUCT_OBUF[53]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair173" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[51]_inst_i_13 
       (.I0(\PRODUCT_OBUF[53]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair294" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[51]_inst_i_14 
       (.I0(\PRODUCT_OBUF[51]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_27_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_14_n_0 ));
  LUT6 #(
    .INIT(64'h2222BBB22BBB2222)) 
    \PRODUCT_OBUF[51]_inst_i_15 
       (.I0(\PRODUCT_OBUF[51]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_29_n_0 ),
        .I2(B_IBUF[13]),
        .I3(B_IBUF[14]),
        .I4(B_IBUF[15]),
        .I5(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair173" *) 
  LUT5 #(
    .INIT(32'hFF696900)) 
    \PRODUCT_OBUF[51]_inst_i_16 
       (.I0(\PRODUCT_OBUF[53]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_23_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair294" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[51]_inst_i_17 
       (.I0(\PRODUCT_OBUF[51]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[51]_inst_i_18 
       (.I0(B_IBUF[28]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[29]),
        .I4(A_IBUF[17]),
        .I5(\PRODUCT_OBUF[51]_inst_i_30_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_18_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[51]_inst_i_19 
       (.I0(\PRODUCT_OBUF[51]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[15]),
        .I3(B_IBUF[14]),
        .I4(B_IBUF[13]),
        .I5(\PRODUCT_OBUF[51]_inst_i_29_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair159" *) 
  LUT4 #(
    .INIT(16'hB200)) 
    \PRODUCT_OBUF[51]_inst_i_2 
       (.I0(\PRODUCT_OBUF[50]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[50]),
        .O(\PRODUCT_OBUF[51]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair311" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[51]_inst_i_20 
       (.I0(\PRODUCT_OBUF[51]_inst_i_31_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h5515FF7F)) 
    \PRODUCT_OBUF[51]_inst_i_21 
       (.I0(\PRODUCT_OBUF[51]_inst_i_34_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[15]),
        .I3(s_u_b_IBUF),
        .I4(\PRODUCT_OBUF[51]_inst_i_35_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair293" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[51]_inst_i_22 
       (.I0(\PRODUCT_OBUF[51]_inst_i_36_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_37_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_22_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[51]_inst_i_23 
       (.I0(B_IBUF[24]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[25]),
        .I4(A_IBUF[23]),
        .I5(\PRODUCT_OBUF[53]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair311" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[51]_inst_i_24 
       (.I0(\PRODUCT_OBUF[51]_inst_i_33_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_32_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_25 
       (.I0(A_IBUF[17]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[18]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[51]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_26 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[51]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_27 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[51]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_28 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[51]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[51]_inst_i_29 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[17]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[15]),
        .I4(B_IBUF[16]),
        .O(\PRODUCT_OBUF[51]_inst_i_29_n_0 ));
  LUT5 #(
    .INIT(32'hFF00FF0E)) 
    \PRODUCT_OBUF[51]_inst_i_3 
       (.I0(CSA_CARRY_wire[49]),
        .I1(CSA_SUM_wire[49]),
        .I2(\PRODUCT_OBUF[49]_inst_i_2_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_7_n_0 ),
        .I4(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_30 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[51]_inst_i_30_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_31 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[51]_inst_i_31_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_32 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[51]_inst_i_32_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_33 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[51]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair310" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[51]_inst_i_34 
       (.I0(\PRODUCT_OBUF[50]_inst_i_40_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_39_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_38_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h2B)) 
    \PRODUCT_OBUF[51]_inst_i_35 
       (.I0(\PRODUCT_OBUF[50]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_20_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_35_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_36 
       (.I0(A_IBUF[18]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[19]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[51]_inst_i_36_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_37 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[51]_inst_i_37_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[51]_inst_i_38 
       (.I0(A_IBUF[16]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[17]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[51]_inst_i_38_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair260" *) 
  LUT4 #(
    .INIT(16'h004D)) 
    \PRODUCT_OBUF[51]_inst_i_4 
       (.I0(\PRODUCT_OBUF[50]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[50]),
        .O(\PRODUCT_OBUF[51]_inst_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[51]_inst_i_5 
       (.I0(\PRODUCT_OBUF[55]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_15_n_0 ),
        .O(CSA_SUM_wire[51]));
  (* SOFT_HLUTNM = "soft_lutpair161" *) 
  LUT5 #(
    .INIT(32'hE800FFE8)) 
    \PRODUCT_OBUF[51]_inst_i_6 
       (.I0(\PRODUCT_OBUF[51]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[51]));
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[51]_inst_i_7 
       (.I0(\PRODUCT_OBUF[49]_inst_i_3_n_0 ),
        .I1(CSA_CARRY_wire[49]),
        .I2(CSA_SUM_wire[49]),
        .O(\PRODUCT_OBUF[51]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hB22BB2B2B2B2B2B2)) 
    \PRODUCT_OBUF[51]_inst_i_8 
       (.I0(\PRODUCT_OBUF[51]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[51]_inst_i_14_n_0 ),
        .I2(\PRODUCT_OBUF[51]_inst_i_15_n_0 ),
        .I3(s_u_b_IBUF),
        .I4(A_IBUF[16]),
        .I5(B_IBUF[31]),
        .O(\PRODUCT_OBUF[51]_inst_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h6555AAAA9AAA5555)) 
    \PRODUCT_OBUF[51]_inst_i_9 
       (.I0(\PRODUCT_OBUF[51]_inst_i_16_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[51]_inst_i_15_n_0 ),
        .I5(\PRODUCT_OBUF[51]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[51]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[52]_inst 
       (.I(PRODUCT_OBUF[52]),
        .O(PRODUCT[52]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \PRODUCT_OBUF[52]_inst_i_1 
       (.I0(\PRODUCT_OBUF[55]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_3_n_0 ),
        .O(PRODUCT_OBUF[52]));
  OBUF \PRODUCT_OBUF[53]_inst 
       (.I(PRODUCT_OBUF[53]),
        .O(PRODUCT[53]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT5 #(
    .INIT(32'h0DF2F20D)) 
    \PRODUCT_OBUF[53]_inst_i_1 
       (.I0(\PRODUCT_OBUF[55]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_3_n_0 ),
        .I3(CSA_SUM_wire[53]),
        .I4(CSA_CARRY_wire[53]),
        .O(PRODUCT_OBUF[53]));
  (* SOFT_HLUTNM = "soft_lutpair166" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[53]_inst_i_10 
       (.I0(\PRODUCT_OBUF[55]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_10_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[53]_inst_i_11 
       (.I0(\PRODUCT_OBUF[55]_inst_i_45_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[17]),
        .I3(B_IBUF[16]),
        .I4(B_IBUF[15]),
        .I5(\PRODUCT_OBUF[55]_inst_i_44_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[53]_inst_i_12 
       (.I0(B_IBUF[24]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[25]),
        .I4(A_IBUF[23]),
        .I5(\PRODUCT_OBUF[53]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[53]_inst_i_13 
       (.I0(\PRODUCT_OBUF[53]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[53]_inst_i_14 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[17]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[50]_inst_i_29_n_0 ),
        .I4(\PRODUCT_OBUF[50]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair305" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[53]_inst_i_15 
       (.I0(\PRODUCT_OBUF[50]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_26_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[53]_inst_i_16 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[18]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[55]_inst_i_47_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_46_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair287" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[53]_inst_i_17 
       (.I0(\PRODUCT_OBUF[53]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair295" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[53]_inst_i_18 
       (.I0(\PRODUCT_OBUF[53]_inst_i_26_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_28_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_19 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[53]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair261" *) 
  LUT4 #(
    .INIT(16'hE800)) 
    \PRODUCT_OBUF[53]_inst_i_2 
       (.I0(\PRODUCT_OBUF[55]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_17_n_0 ),
        .I3(CSA_SUM_wire[52]),
        .O(\PRODUCT_OBUF[53]_inst_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_20 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[53]_inst_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[53]_inst_i_21 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[15]),
        .I2(B_IBUF[16]),
        .I3(B_IBUF[17]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[53]_inst_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_22 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[53]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_23 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[53]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[53]_inst_i_24 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[19]),
        .I2(B_IBUF[20]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[53]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_25 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[53]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_26 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[53]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_27 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[53]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[53]_inst_i_28 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[53]_inst_i_28_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair261" *) 
  LUT4 #(
    .INIT(16'h0017)) 
    \PRODUCT_OBUF[53]_inst_i_3 
       (.I0(\PRODUCT_OBUF[55]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_17_n_0 ),
        .I3(CSA_SUM_wire[52]),
        .O(\PRODUCT_OBUF[53]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair166" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[53]_inst_i_4 
       (.I0(\PRODUCT_OBUF[55]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_12_n_0 ),
        .O(CSA_SUM_wire[53]));
  (* SOFT_HLUTNM = "soft_lutpair165" *) 
  LUT5 #(
    .INIT(32'h00B2B2FF)) 
    \PRODUCT_OBUF[53]_inst_i_5 
       (.I0(\PRODUCT_OBUF[53]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[53]_inst_i_9_n_0 ),
        .I4(\PRODUCT_OBUF[53]_inst_i_10_n_0 ),
        .O(CSA_CARRY_wire[53]));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT5 #(
    .INIT(32'hFFD4D400)) 
    \PRODUCT_OBUF[53]_inst_i_6 
       (.I0(\PRODUCT_OBUF[53]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[53]_inst_i_14_n_0 ),
        .I4(\PRODUCT_OBUF[53]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hE8E8E817171717E8)) 
    \PRODUCT_OBUF[53]_inst_i_7 
       (.I0(\PRODUCT_OBUF[55]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_25_n_0 ),
        .I5(\PRODUCT_OBUF[55]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFF6969FF69000069)) 
    \PRODUCT_OBUF[53]_inst_i_8 
       (.I0(\PRODUCT_OBUF[55]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_21_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_25_n_0 ),
        .I5(\PRODUCT_OBUF[53]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[53]_inst_i_9 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[20]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[53]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[53]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[53]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[54]_inst 
       (.I(PRODUCT_OBUF[54]),
        .O(PRODUCT[54]));
  LUT5 #(
    .INIT(32'hF2F20DF2)) 
    \PRODUCT_OBUF[54]_inst_i_1 
       (.I0(\PRODUCT_OBUF[55]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_5_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_6_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_3_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[54]));
  OBUF \PRODUCT_OBUF[55]_inst 
       (.I(PRODUCT_OBUF[55]),
        .O(PRODUCT[55]));
  LUT6 #(
    .INIT(64'hAAAAEEAE55551151)) 
    \PRODUCT_OBUF[55]_inst_i_1 
       (.I0(\PRODUCT_OBUF[55]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[55]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[55]));
  (* SOFT_HLUTNM = "soft_lutpair188" *) 
  LUT5 #(
    .INIT(32'h17E8E817)) 
    \PRODUCT_OBUF[55]_inst_i_10 
       (.I0(\PRODUCT_OBUF[55]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[55]_inst_i_11 
       (.I0(\PRODUCT_OBUF[55]_inst_i_34_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_35_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_36_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[55]_inst_i_12 
       (.I0(\PRODUCT_OBUF[55]_inst_i_37_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_38_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[20]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[55]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair167" *) 
  LUT5 #(
    .INIT(32'h718E8E71)) 
    \PRODUCT_OBUF[55]_inst_i_13 
       (.I0(\PRODUCT_OBUF[55]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_39_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_40_n_0 ),
        .O(CSA_SUM_wire[54]));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT5 #(
    .INIT(32'h17111717)) 
    \PRODUCT_OBUF[55]_inst_i_14 
       (.I0(CSA_SUM_wire[51]),
        .I1(CSA_CARRY_wire[51]),
        .I2(\PRODUCT_OBUF[51]_inst_i_2_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_4_n_0 ),
        .I4(\PRODUCT_OBUF[51]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair187" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[55]_inst_i_15 
       (.I0(\PRODUCT_OBUF[55]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_29_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_30_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[55]_inst_i_16 
       (.I0(\PRODUCT_OBUF[53]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair174" *) 
  LUT5 #(
    .INIT(32'hFFB2B200)) 
    \PRODUCT_OBUF[55]_inst_i_17 
       (.I0(\PRODUCT_OBUF[50]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[50]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[50]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_41_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_42_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair165" *) 
  LUT5 #(
    .INIT(32'hB24D4DB2)) 
    \PRODUCT_OBUF[55]_inst_i_18 
       (.I0(\PRODUCT_OBUF[53]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[53]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[53]_inst_i_9_n_0 ),
        .O(CSA_SUM_wire[52]));
  (* SOFT_HLUTNM = "soft_lutpair167" *) 
  LUT5 #(
    .INIT(32'h8E00FF8E)) 
    \PRODUCT_OBUF[55]_inst_i_19 
       (.I0(\PRODUCT_OBUF[55]_inst_i_35_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_36_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_34_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_40_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_39_n_0 ),
        .O(CSA_CARRY_wire[55]));
  LUT6 #(
    .INIT(64'h00000000FF171700)) 
    \PRODUCT_OBUF[55]_inst_i_2 
       (.I0(\PRODUCT_OBUF[55]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_12_n_0 ),
        .I5(CSA_SUM_wire[54]),
        .O(\PRODUCT_OBUF[55]_inst_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair178" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[55]_inst_i_20 
       (.I0(\PRODUCT_OBUF[59]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[57]_inst_i_18_n_0 ),
        .O(CSA_SUM_wire[55]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_21 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[55]_inst_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_22 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[55]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_23 
       (.I0(A_IBUF[23]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[55]_inst_i_23_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[55]_inst_i_24 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[55]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_24_n_0 ));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[55]_inst_i_25 
       (.I0(\PRODUCT_OBUF[55]_inst_i_44_n_0 ),
        .I1(B_IBUF[15]),
        .I2(B_IBUF[16]),
        .I3(B_IBUF[17]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[55]_inst_i_45_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[55]_inst_i_26 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[18]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[55]_inst_i_46_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_47_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_26_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_27 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[55]_inst_i_27_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_28 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[55]_inst_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_29 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[55]_inst_i_29_n_0 ));
  LUT6 #(
    .INIT(64'hFF171700FFFFFFFF)) 
    \PRODUCT_OBUF[55]_inst_i_3 
       (.I0(\PRODUCT_OBUF[55]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_10_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_12_n_0 ),
        .I5(CSA_SUM_wire[54]),
        .O(\PRODUCT_OBUF[55]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[55]_inst_i_30 
       (.I0(\PRODUCT_OBUF[55]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_49_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[19]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[55]_inst_i_30_n_0 ));
  LUT6 #(
    .INIT(64'h6666999669996666)) 
    \PRODUCT_OBUF[55]_inst_i_31 
       (.I0(\PRODUCT_OBUF[55]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_51_n_0 ),
        .I2(B_IBUF[17]),
        .I3(B_IBUF[18]),
        .I4(B_IBUF[19]),
        .I5(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_31_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h2222B222)) 
    \PRODUCT_OBUF[55]_inst_i_32 
       (.I0(\PRODUCT_OBUF[55]_inst_i_48_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_49_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[19]),
        .I4(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[55]_inst_i_32_n_0 ));
  LUT6 #(
    .INIT(64'h7777111771117777)) 
    \PRODUCT_OBUF[55]_inst_i_33 
       (.I0(\PRODUCT_OBUF[55]_inst_i_50_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_51_n_0 ),
        .I2(B_IBUF[17]),
        .I3(B_IBUF[18]),
        .I4(B_IBUF[19]),
        .I5(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_33_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[55]_inst_i_34 
       (.I0(\PRODUCT_OBUF[55]_inst_i_52_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_53_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[21]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[55]_inst_i_34_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair188" *) 
  LUT5 #(
    .INIT(32'hFF171700)) 
    \PRODUCT_OBUF[55]_inst_i_35 
       (.I0(\PRODUCT_OBUF[55]_inst_i_29_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_27_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_32_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_33_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_35_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h71777777)) 
    \PRODUCT_OBUF[55]_inst_i_36 
       (.I0(\PRODUCT_OBUF[53]_inst_i_18_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_17_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[20]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[55]_inst_i_36_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair296" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[55]_inst_i_37 
       (.I0(\PRODUCT_OBUF[55]_inst_i_54_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_56_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_37_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[55]_inst_i_38 
       (.I0(\PRODUCT_OBUF[57]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[21]),
        .I3(B_IBUF[20]),
        .I4(B_IBUF[19]),
        .I5(\PRODUCT_OBUF[57]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_38_n_0 ));
  LUT6 #(
    .INIT(64'h9AAA655565559AAA)) 
    \PRODUCT_OBUF[55]_inst_i_39 
       (.I0(\PRODUCT_OBUF[57]_inst_i_14_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[57]_inst_i_24_n_0 ),
        .I5(\PRODUCT_OBUF[57]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_39_n_0 ));
  LUT3 #(
    .INIT(8'h0E)) 
    \PRODUCT_OBUF[55]_inst_i_4 
       (.I0(CSA_CARRY_wire[53]),
        .I1(CSA_SUM_wire[53]),
        .I2(\PRODUCT_OBUF[53]_inst_i_3_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair176" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[55]_inst_i_40 
       (.I0(\PRODUCT_OBUF[59]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[57]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_40_n_0 ));
  LUT6 #(
    .INIT(64'hBAAAFFFF2000AAAA)) 
    \PRODUCT_OBUF[55]_inst_i_41 
       (.I0(\PRODUCT_OBUF[51]_inst_i_16_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[16]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[51]_inst_i_15_n_0 ),
        .I5(\PRODUCT_OBUF[51]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair175" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[55]_inst_i_42 
       (.I0(\PRODUCT_OBUF[53]_inst_i_11_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_13_n_0 ),
        .I3(\PRODUCT_OBUF[53]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[53]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_42_n_0 ));
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[55]_inst_i_43 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[17]),
        .I2(B_IBUF[18]),
        .I3(B_IBUF[19]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[55]_inst_i_43_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[55]_inst_i_44 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[17]),
        .I4(B_IBUF[18]),
        .O(\PRODUCT_OBUF[55]_inst_i_44_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_45 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[55]_inst_i_45_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_46 
       (.I0(A_IBUF[19]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[20]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[55]_inst_i_46_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_47 
       (.I0(A_IBUF[21]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[55]_inst_i_47_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[55]_inst_i_48 
       (.I0(B_IBUF[20]),
        .I1(B_IBUF[19]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[21]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[55]_inst_i_43_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_48_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_49 
       (.I0(A_IBUF[20]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[21]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[55]_inst_i_49_n_0 ));
  LUT3 #(
    .INIT(8'hA8)) 
    \PRODUCT_OBUF[55]_inst_i_5 
       (.I0(\PRODUCT_OBUF[55]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_50 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[55]_inst_i_50_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_51 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[21]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[19]),
        .I4(B_IBUF[20]),
        .O(\PRODUCT_OBUF[55]_inst_i_51_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair287" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[55]_inst_i_52 
       (.I0(\PRODUCT_OBUF[53]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_24_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_52_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair295" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[55]_inst_i_53 
       (.I0(\PRODUCT_OBUF[53]_inst_i_28_n_0 ),
        .I1(\PRODUCT_OBUF[53]_inst_i_27_n_0 ),
        .I2(\PRODUCT_OBUF[53]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_53_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_54 
       (.I0(A_IBUF[22]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[23]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[55]_inst_i_54_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_55 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[55]_inst_i_55_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[55]_inst_i_56 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[55]_inst_i_56_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFE800E8000000)) 
    \PRODUCT_OBUF[55]_inst_i_6 
       (.I0(\PRODUCT_OBUF[55]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_17_n_0 ),
        .I3(CSA_SUM_wire[52]),
        .I4(CSA_CARRY_wire[53]),
        .I5(CSA_SUM_wire[53]),
        .O(\PRODUCT_OBUF[55]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PRODUCT_OBUF[55]_inst_i_7 
       (.I0(CSA_CARRY_wire[55]),
        .I1(CSA_SUM_wire[55]),
        .O(\PRODUCT_OBUF[55]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF1717171700)) 
    \PRODUCT_OBUF[55]_inst_i_8 
       (.I0(\PRODUCT_OBUF[55]_inst_i_21_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_22_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_23_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_25_n_0 ),
        .I5(\PRODUCT_OBUF[55]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair187" *) 
  LUT5 #(
    .INIT(32'h6900FF69)) 
    \PRODUCT_OBUF[55]_inst_i_9 
       (.I0(\PRODUCT_OBUF[55]_inst_i_27_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_28_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_29_n_0 ),
        .I3(\PRODUCT_OBUF[55]_inst_i_30_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_31_n_0 ),
        .O(\PRODUCT_OBUF[55]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[56]_inst 
       (.I(PRODUCT_OBUF[56]),
        .O(PRODUCT[56]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT3 #(
    .INIT(8'h56)) 
    \PRODUCT_OBUF[56]_inst_i_1 
       (.I0(\PRODUCT_OBUF[60]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[57]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[56]));
  OBUF \PRODUCT_OBUF[57]_inst 
       (.I(PRODUCT_OBUF[57]),
        .O(PRODUCT[57]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT5 #(
    .INIT(32'h0DF2F20D)) 
    \PRODUCT_OBUF[57]_inst_i_1 
       (.I0(\PRODUCT_OBUF[60]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_2_n_0 ),
        .I2(\PRODUCT_OBUF[57]_inst_i_3_n_0 ),
        .I3(CSA_SUM_wire[57]),
        .I4(CSA_CARRY_wire[57]),
        .O(PRODUCT_OBUF[57]));
  (* SOFT_HLUTNM = "soft_lutpair178" *) 
  LUT5 #(
    .INIT(32'hFF696900)) 
    \PRODUCT_OBUF[57]_inst_i_10 
       (.I0(\PRODUCT_OBUF[59]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_17_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_17_n_0 ),
        .I4(\PRODUCT_OBUF[57]_inst_i_18_n_0 ),
        .O(CSA_CARRY_wire[56]));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hAF9595F5)) 
    \PRODUCT_OBUF[57]_inst_i_11 
       (.I0(B_IBUF[25]),
        .I1(s_u_a_IBUF),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[57]_inst_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[57]_inst_i_12 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[57]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[57]_inst_i_13 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[57]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[57]_inst_i_14 
       (.I0(\PRODUCT_OBUF[57]_inst_i_19_n_0 ),
        .I1(B_IBUF[19]),
        .I2(B_IBUF[20]),
        .I3(B_IBUF[21]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[57]_inst_i_20_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[57]_inst_i_15 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[23]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[59]_inst_i_25_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair176" *) 
  LUT5 #(
    .INIT(32'hFF696900)) 
    \PRODUCT_OBUF[57]_inst_i_16 
       (.I0(\PRODUCT_OBUF[59]_inst_i_22_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_20_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_21_n_0 ),
        .I4(\PRODUCT_OBUF[57]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h8888E888EEEE8EEE)) 
    \PRODUCT_OBUF[57]_inst_i_17 
       (.I0(\PRODUCT_OBUF[57]_inst_i_23_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_24_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[22]),
        .I4(s_u_b_IBUF),
        .I5(\PRODUCT_OBUF[57]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_17_n_0 ));
  LUT6 #(
    .INIT(64'h9A99999965666666)) 
    \PRODUCT_OBUF[57]_inst_i_18 
       (.I0(\PRODUCT_OBUF[57]_inst_i_16_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_14_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[22]),
        .I4(B_IBUF[31]),
        .I5(\PRODUCT_OBUF[57]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[57]_inst_i_19 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[23]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[21]),
        .I4(B_IBUF[22]),
        .O(\PRODUCT_OBUF[57]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair170" *) 
  LUT5 #(
    .INIT(32'h96690000)) 
    \PRODUCT_OBUF[57]_inst_i_2 
       (.I0(\PRODUCT_OBUF[57]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[57]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_9_n_0 ),
        .I4(CSA_CARRY_wire[56]),
        .O(\PRODUCT_OBUF[57]_inst_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[57]_inst_i_20 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[57]_inst_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[57]_inst_i_21 
       (.I0(B_IBUF[30]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[31]),
        .I4(A_IBUF[23]),
        .I5(\PRODUCT_OBUF[59]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair296" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[57]_inst_i_22 
       (.I0(\PRODUCT_OBUF[55]_inst_i_56_n_0 ),
        .I1(\PRODUCT_OBUF[55]_inst_i_55_n_0 ),
        .I2(\PRODUCT_OBUF[55]_inst_i_54_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_22_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT5 #(
    .INIT(32'h000808FF)) 
    \PRODUCT_OBUF[57]_inst_i_23 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[20]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[55]_inst_i_38_n_0 ),
        .I4(\PRODUCT_OBUF[55]_inst_i_37_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_23_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'hAAEA0080)) 
    \PRODUCT_OBUF[57]_inst_i_24 
       (.I0(\PRODUCT_OBUF[55]_inst_i_53_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[21]),
        .I3(s_u_b_IBUF),
        .I4(\PRODUCT_OBUF[55]_inst_i_52_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_24_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair170" *) 
  LUT5 #(
    .INIT(32'h00006996)) 
    \PRODUCT_OBUF[57]_inst_i_3 
       (.I0(\PRODUCT_OBUF[57]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[57]_inst_i_8_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_9_n_0 ),
        .I4(CSA_CARRY_wire[56]),
        .O(\PRODUCT_OBUF[57]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair168" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[57]_inst_i_4 
       (.I0(\PRODUCT_OBUF[59]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[57]));
  (* SOFT_HLUTNM = "soft_lutpair262" *) 
  LUT4 #(
    .INIT(16'hF990)) 
    \PRODUCT_OBUF[57]_inst_i_5 
       (.I0(\PRODUCT_OBUF[57]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_7_n_0 ),
        .I2(\PRODUCT_OBUF[57]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[57]_inst_i_8_n_0 ),
        .O(CSA_CARRY_wire[57]));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[57]_inst_i_6 
       (.I0(B_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[27]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[57]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[57]_inst_i_7 
       (.I0(\PRODUCT_OBUF[57]_inst_i_12_n_0 ),
        .I1(B_IBUF[21]),
        .I2(B_IBUF[22]),
        .I3(B_IBUF[23]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[57]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBAAABAAA0000)) 
    \PRODUCT_OBUF[57]_inst_i_8 
       (.I0(\PRODUCT_OBUF[57]_inst_i_14_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[22]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[57]_inst_i_15_n_0 ),
        .I5(\PRODUCT_OBUF[57]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair177" *) 
  LUT5 #(
    .INIT(32'h8E71718E)) 
    \PRODUCT_OBUF[57]_inst_i_9 
       (.I0(\PRODUCT_OBUF[59]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_19_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_18_n_0 ),
        .O(\PRODUCT_OBUF[57]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[58]_inst 
       (.I(PRODUCT_OBUF[58]),
        .O(PRODUCT[58]));
  LUT5 #(
    .INIT(32'hF2F2F20D)) 
    \PRODUCT_OBUF[58]_inst_i_1 
       (.I0(\PRODUCT_OBUF[59]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[60]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_3_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_4_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_5_n_0 ),
        .O(PRODUCT_OBUF[58]));
  OBUF \PRODUCT_OBUF[59]_inst 
       (.I(PRODUCT_OBUF[59]),
        .O(PRODUCT[59]));
  LUT6 #(
    .INIT(64'hFFFF000D0000FFF2)) 
    \PRODUCT_OBUF[59]_inst_i_1 
       (.I0(\PRODUCT_OBUF[59]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[60]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_3_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_4_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_5_n_0 ),
        .I5(\PRODUCT_OBUF[59]_inst_i_6_n_0 ),
        .O(PRODUCT_OBUF[59]));
  (* SOFT_HLUTNM = "soft_lutpair177" *) 
  LUT5 #(
    .INIT(32'hFF8E8E00)) 
    \PRODUCT_OBUF[59]_inst_i_10 
       (.I0(\PRODUCT_OBUF[59]_inst_i_15_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_16_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_17_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_18_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[59]_inst_i_11 
       (.I0(\PRODUCT_OBUF[61]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_21_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[25]),
        .I4(B_IBUF[31]),
        .O(\PRODUCT_OBUF[59]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h96999999)) 
    \PRODUCT_OBUF[59]_inst_i_12 
       (.I0(\PRODUCT_OBUF[60]_inst_i_9_n_0 ),
        .I1(\PRODUCT_OBUF[60]_inst_i_8_n_0 ),
        .I2(s_u_b_IBUF),
        .I3(A_IBUF[26]),
        .I4(B_IBUF[31]),
        .O(CSA_SUM_wire[58]));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_13 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[59]_inst_i_13_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_14 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[59]_inst_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[59]_inst_i_15 
       (.I0(\PRODUCT_OBUF[59]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_21_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_15_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[59]_inst_i_16 
       (.I0(B_IBUF[30]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[24]),
        .I3(B_IBUF[31]),
        .I4(A_IBUF[23]),
        .I5(\PRODUCT_OBUF[59]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_16_n_0 ));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[59]_inst_i_17 
       (.I0(\PRODUCT_OBUF[57]_inst_i_13_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[23]),
        .I3(B_IBUF[22]),
        .I4(B_IBUF[21]),
        .I5(\PRODUCT_OBUF[57]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT5 #(
    .INIT(32'h08F7F708)) 
    \PRODUCT_OBUF[59]_inst_i_18 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[24]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[59]_inst_i_14_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[59]_inst_i_19 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[23]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[59]_inst_i_24_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair368" *) 
  LUT3 #(
    .INIT(8'h0E)) 
    \PRODUCT_OBUF[59]_inst_i_2 
       (.I0(CSA_CARRY_wire[57]),
        .I1(CSA_SUM_wire[57]),
        .I2(\PRODUCT_OBUF[57]_inst_i_3_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_20 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[23]),
        .I4(B_IBUF[24]),
        .O(\PRODUCT_OBUF[59]_inst_i_20_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[59]_inst_i_21 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[21]),
        .I2(B_IBUF[22]),
        .I3(B_IBUF[23]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[59]_inst_i_21_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_22 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[59]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_23 
       (.I0(A_IBUF[25]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[59]_inst_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_24 
       (.I0(A_IBUF[24]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[25]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[59]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[59]_inst_i_25 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[59]_inst_i_25_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair368" *) 
  LUT3 #(
    .INIT(8'hE8)) 
    \PRODUCT_OBUF[59]_inst_i_3 
       (.I0(\PRODUCT_OBUF[57]_inst_i_2_n_0 ),
        .I1(CSA_SUM_wire[57]),
        .I2(CSA_CARRY_wire[57]),
        .O(\PRODUCT_OBUF[59]_inst_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF96960000000000)) 
    \PRODUCT_OBUF[59]_inst_i_4 
       (.I0(\PRODUCT_OBUF[59]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_11_n_0 ),
        .I5(CSA_SUM_wire[58]),
        .O(\PRODUCT_OBUF[59]_inst_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000006969FF)) 
    \PRODUCT_OBUF[59]_inst_i_5 
       (.I0(\PRODUCT_OBUF[59]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_11_n_0 ),
        .I5(CSA_SUM_wire[58]),
        .O(\PRODUCT_OBUF[59]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \PRODUCT_OBUF[59]_inst_i_6 
       (.I0(CSA_CARRY_wire[59]),
        .I1(CSA_SUM_wire[59]),
        .O(\PRODUCT_OBUF[59]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair262" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \PRODUCT_OBUF[59]_inst_i_7 
       (.I0(\PRODUCT_OBUF[57]_inst_i_6_n_0 ),
        .I1(\PRODUCT_OBUF[57]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h55A96A55AA5695AA)) 
    \PRODUCT_OBUF[59]_inst_i_8 
       (.I0(\PRODUCT_OBUF[61]_inst_i_24_n_0 ),
        .I1(B_IBUF[23]),
        .I2(B_IBUF[24]),
        .I3(B_IBUF[25]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_23_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[59]_inst_i_9 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[24]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[59]_inst_i_13_n_0 ),
        .I4(\PRODUCT_OBUF[59]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[59]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[5]_inst 
       (.I(PRODUCT_OBUF[5]),
        .O(PRODUCT[5]));
  (* SOFT_HLUTNM = "soft_lutpair144" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[5]_inst_i_1 
       (.I0(CSA_CARRY_wire[4]),
        .I1(CSA_SUM_wire[4]),
        .I2(\PRODUCT_OBUF[5]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[5]),
        .I4(CSA_CARRY_wire[5]),
        .O(PRODUCT_OBUF[5]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[5]_inst_i_2 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[3]),
        .I4(\PRODUCT_OBUF[5]_inst_i_7_n_0 ),
        .O(CSA_CARRY_wire[4]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT4 #(
    .INIT(16'hA66A)) 
    \PRODUCT_OBUF[5]_inst_i_3 
       (.I0(\PRODUCT_OBUF[5]_inst_i_8_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[3]),
        .I3(B_IBUF[4]),
        .O(CSA_SUM_wire[4]));
  (* SOFT_HLUTNM = "soft_lutpair145" *) 
  LUT5 #(
    .INIT(32'hFCE8E8C0)) 
    \PRODUCT_OBUF[5]_inst_i_4 
       (.I0(\PRODUCT_OBUF[3]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[3]),
        .I2(CSA_CARRY_wire[3]),
        .I3(CSA_SUM_wire[2]),
        .I4(CSA_CARRY_wire[2]),
        .O(\PRODUCT_OBUF[5]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair364" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[5]_inst_i_5 
       (.I0(\PRODUCT_OBUF[7]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[7]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[7]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[5]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT5 #(
    .INIT(32'h00CACAAA)) 
    \PRODUCT_OBUF[5]_inst_i_6 
       (.I0(B_IBUF[5]),
        .I1(\PRODUCT_OBUF[5]_inst_i_8_n_0 ),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[4]),
        .I4(B_IBUF[3]),
        .O(CSA_CARRY_wire[5]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[5]_inst_i_7 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[5]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT5 #(
    .INIT(32'h65956A95)) 
    \PRODUCT_OBUF[5]_inst_i_8 
       (.I0(\PRODUCT_OBUF[7]_inst_i_14_n_0 ),
        .I1(A_IBUF[4]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[3]),
        .O(\PRODUCT_OBUF[5]_inst_i_8_n_0 ));
  OBUF \PRODUCT_OBUF[60]_inst 
       (.I(PRODUCT_OBUF[60]),
        .O(PRODUCT[60]));
  LUT5 #(
    .INIT(32'h99996696)) 
    \PRODUCT_OBUF[60]_inst_i_1 
       (.I0(CSA_CARRY_wire[60]),
        .I1(CSA_SUM_wire[60]),
        .I2(\PRODUCT_OBUF[60]_inst_i_3_n_0 ),
        .I3(\PRODUCT_OBUF[60]_inst_i_4_n_0 ),
        .I4(\PRODUCT_OBUF[60]_inst_i_5_n_0 ),
        .O(PRODUCT_OBUF[60]));
  LUT6 #(
    .INIT(64'h5595AA6AAA6A5595)) 
    \PRODUCT_OBUF[60]_inst_i_2 
       (.I0(\PRODUCT_OBUF[61]_inst_i_5_n_0 ),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[28]),
        .I3(s_u_b_IBUF),
        .I4(\PRODUCT_OBUF[61]_inst_i_12_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_4_n_0 ),
        .O(CSA_SUM_wire[60]));
  LUT4 #(
    .INIT(16'h0E00)) 
    \PRODUCT_OBUF[60]_inst_i_3 
       (.I0(CSA_CARRY_wire[59]),
        .I1(CSA_SUM_wire[59]),
        .I2(\PRODUCT_OBUF[59]_inst_i_5_n_0 ),
        .I3(\PRODUCT_OBUF[59]_inst_i_2_n_0 ),
        .O(\PRODUCT_OBUF[60]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair252" *) 
  LUT4 #(
    .INIT(16'h00EF)) 
    \PRODUCT_OBUF[60]_inst_i_4 
       (.I0(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[63]_inst_i_12_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_13_n_0 ),
        .I3(COUT_OBUF_inst_i_2_n_0),
        .O(\PRODUCT_OBUF[60]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT5 #(
    .INIT(32'hFFF4F400)) 
    \PRODUCT_OBUF[60]_inst_i_5 
       (.I0(\PRODUCT_OBUF[59]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[59]),
        .I4(CSA_CARRY_wire[59]),
        .O(\PRODUCT_OBUF[60]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'hFFF7F700)) 
    \PRODUCT_OBUF[60]_inst_i_6 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[26]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[60]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[60]_inst_i_9_n_0 ),
        .O(CSA_CARRY_wire[59]));
  (* SOFT_HLUTNM = "soft_lutpair169" *) 
  LUT5 #(
    .INIT(32'hD42B2BD4)) 
    \PRODUCT_OBUF[60]_inst_i_7 
       (.I0(\PRODUCT_OBUF[61]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[61]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[61]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[59]));
  LUT3 #(
    .INIT(8'h69)) 
    \PRODUCT_OBUF[60]_inst_i_8 
       (.I0(\PRODUCT_OBUF[61]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[61]_inst_i_8_n_0 ),
        .O(\PRODUCT_OBUF[60]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair168" *) 
  LUT3 #(
    .INIT(8'h4D)) 
    \PRODUCT_OBUF[60]_inst_i_9 
       (.I0(\PRODUCT_OBUF[59]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[59]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[59]_inst_i_7_n_0 ),
        .O(\PRODUCT_OBUF[60]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[61]_inst 
       (.I(PRODUCT_OBUF[61]),
        .O(PRODUCT[61]));
  LUT6 #(
    .INIT(64'h4B2D2DB4D24B4B2D)) 
    \PRODUCT_OBUF[61]_inst_i_1 
       (.I0(\PRODUCT_OBUF[63]_inst_i_5_n_0 ),
        .I1(CSA_CARRY_wire[60]),
        .I2(CSA_SUM_wire[61]),
        .I3(\PRODUCT_OBUF[61]_inst_i_4_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_5_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_6_n_0 ),
        .O(PRODUCT_OBUF[61]));
  LUT6 #(
    .INIT(64'hA696969A59696965)) 
    \PRODUCT_OBUF[61]_inst_i_10 
       (.I0(\PRODUCT_OBUF[61]_inst_i_25_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I2(B_IBUF[27]),
        .I3(B_IBUF[26]),
        .I4(B_IBUF[25]),
        .I5(\PRODUCT_OBUF[61]_inst_i_26_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'h56556555)) 
    \PRODUCT_OBUF[61]_inst_i_11 
       (.I0(\PRODUCT_OBUF[61]_inst_i_16_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[26]),
        .I3(B_IBUF[31]),
        .I4(A_IBUF[27]),
        .O(\PRODUCT_OBUF[61]_inst_i_11_n_0 ));
  LUT6 #(
    .INIT(64'hAA0280AAFFABEAFF)) 
    \PRODUCT_OBUF[61]_inst_i_12 
       (.I0(\PRODUCT_OBUF[61]_inst_i_26_n_0 ),
        .I1(B_IBUF[25]),
        .I2(B_IBUF[26]),
        .I3(B_IBUF[27]),
        .I4(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_25_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'h65559AAA)) 
    \PRODUCT_OBUF[61]_inst_i_13 
       (.I0(\PRODUCT_OBUF[63]_inst_i_15_n_0 ),
        .I1(s_u_b_IBUF),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[31]),
        .I4(\PRODUCT_OBUF[63]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[61]_inst_i_14 
       (.I0(B_IBUF[30]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[31]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[61]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'hCF9393F3)) 
    \PRODUCT_OBUF[61]_inst_i_15 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[28]),
        .I4(B_IBUF[27]),
        .O(\PRODUCT_OBUF[61]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair288" *) 
  LUT3 #(
    .INIT(8'h17)) 
    \PRODUCT_OBUF[61]_inst_i_16 
       (.I0(\PRODUCT_OBUF[61]_inst_i_19_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[61]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_17 
       (.I0(A_IBUF[27]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[28]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[61]_inst_i_17_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT5 #(
    .INIT(32'hEB17C0FF)) 
    \PRODUCT_OBUF[61]_inst_i_18 
       (.I0(s_u_a_IBUF),
        .I1(B_IBUF[25]),
        .I2(B_IBUF[26]),
        .I3(B_IBUF[27]),
        .I4(A_IBUF[31]),
        .O(\PRODUCT_OBUF[61]_inst_i_18_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_19 
       (.I0(A_IBUF[29]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[61]_inst_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair169" *) 
  LUT5 #(
    .INIT(32'h00D4D4FF)) 
    \PRODUCT_OBUF[61]_inst_i_2 
       (.I0(\PRODUCT_OBUF[61]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[61]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[61]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[60]));
  LUT6 #(
    .INIT(64'h0000000006E81760)) 
    \PRODUCT_OBUF[61]_inst_i_20 
       (.I0(B_IBUF[26]),
        .I1(B_IBUF[25]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[27]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[57]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_20_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_21 
       (.I0(A_IBUF[26]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[27]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[61]_inst_i_21_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \PRODUCT_OBUF[61]_inst_i_22 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .O(\PRODUCT_OBUF[61]_inst_i_22_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_23 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[27]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[25]),
        .I4(B_IBUF[26]),
        .O(\PRODUCT_OBUF[61]_inst_i_23_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_24 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[61]_inst_i_24_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[61]_inst_i_25 
       (.I0(A_IBUF[28]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[29]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[61]_inst_i_25_n_0 ));
  LUT5 #(
    .INIT(32'h223C3C44)) 
    \PRODUCT_OBUF[61]_inst_i_26 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[27]),
        .I4(B_IBUF[28]),
        .O(\PRODUCT_OBUF[61]_inst_i_26_n_0 ));
  LUT6 #(
    .INIT(64'hFF0800F700F7FF08)) 
    \PRODUCT_OBUF[61]_inst_i_3 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[28]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[61]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_13_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_14_n_0 ),
        .O(CSA_SUM_wire[61]));
  LUT6 #(
    .INIT(64'h06E81760F917E89F)) 
    \PRODUCT_OBUF[61]_inst_i_4 
       (.I0(B_IBUF[30]),
        .I1(B_IBUF[29]),
        .I2(A_IBUF[30]),
        .I3(B_IBUF[31]),
        .I4(A_IBUF[29]),
        .I5(\PRODUCT_OBUF[61]_inst_i_15_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT5 #(
    .INIT(32'h50404000)) 
    \PRODUCT_OBUF[61]_inst_i_5 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[26]),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[27]),
        .I4(\PRODUCT_OBUF[61]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair239" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \PRODUCT_OBUF[61]_inst_i_6 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[28]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[61]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair288" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[61]_inst_i_7 
       (.I0(\PRODUCT_OBUF[61]_inst_i_17_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_18_n_0 ),
        .I2(\PRODUCT_OBUF[61]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'h2222B222)) 
    \PRODUCT_OBUF[61]_inst_i_8 
       (.I0(\PRODUCT_OBUF[61]_inst_i_20_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_21_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[25]),
        .I4(s_u_b_IBUF),
        .O(\PRODUCT_OBUF[61]_inst_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0000F18FF18FFFFF)) 
    \PRODUCT_OBUF[61]_inst_i_9 
       (.I0(B_IBUF[23]),
        .I1(B_IBUF[24]),
        .I2(B_IBUF[25]),
        .I3(\PRODUCT_OBUF[61]_inst_i_22_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_23_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_24_n_0 ),
        .O(\PRODUCT_OBUF[61]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[62]_inst 
       (.I(PRODUCT_OBUF[62]),
        .O(PRODUCT[62]));
  LUT5 #(
    .INIT(32'hF2F20DF2)) 
    \PRODUCT_OBUF[62]_inst_i_1 
       (.I0(\PRODUCT_OBUF[63]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[63]_inst_i_5_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_6_n_0 ),
        .I3(\PRODUCT_OBUF[63]_inst_i_3_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_2_n_0 ),
        .O(PRODUCT_OBUF[62]));
  OBUF \PRODUCT_OBUF[63]_inst 
       (.I(PRODUCT_OBUF[63]),
        .O(PRODUCT[63]));
  LUT6 #(
    .INIT(64'hAAAAEEAE55551151)) 
    \PRODUCT_OBUF[63]_inst_i_1 
       (.I0(\PRODUCT_OBUF[63]_inst_i_2_n_0 ),
        .I1(\PRODUCT_OBUF[63]_inst_i_3_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_4_n_0 ),
        .I3(\PRODUCT_OBUF[63]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[63]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[63]));
  LUT6 #(
    .INIT(64'hFFFFFF08FF080000)) 
    \PRODUCT_OBUF[63]_inst_i_10 
       (.I0(B_IBUF[31]),
        .I1(A_IBUF[28]),
        .I2(s_u_b_IBUF),
        .I3(\PRODUCT_OBUF[61]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[61]_inst_i_13_n_0 ),
        .I5(\PRODUCT_OBUF[61]_inst_i_14_n_0 ),
        .O(CSA_CARRY_wire[62]));
  LUT6 #(
    .INIT(64'h8888E888EEEE8EEE)) 
    \PRODUCT_OBUF[63]_inst_i_11 
       (.I0(\PRODUCT_OBUF[61]_inst_i_4_n_0 ),
        .I1(\PRODUCT_OBUF[61]_inst_i_5_n_0 ),
        .I2(B_IBUF[31]),
        .I3(A_IBUF[28]),
        .I4(s_u_b_IBUF),
        .I5(\PRODUCT_OBUF[61]_inst_i_12_n_0 ),
        .O(CSA_CARRY_wire[61]));
  LUT5 #(
    .INIT(32'hFFFFFFF1)) 
    \PRODUCT_OBUF[63]_inst_i_12 
       (.I0(CSA_CARRY_wire[49]),
        .I1(CSA_SUM_wire[49]),
        .I2(\PRODUCT_OBUF[49]_inst_i_2_n_0 ),
        .I3(\PRODUCT_OBUF[51]_inst_i_4_n_0 ),
        .I4(COUT_OBUF_inst_i_8_n_0),
        .O(\PRODUCT_OBUF[63]_inst_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000EEE0)) 
    \PRODUCT_OBUF[63]_inst_i_13 
       (.I0(CSA_CARRY_wire[55]),
        .I1(CSA_SUM_wire[55]),
        .I2(CSA_CARRY_wire[53]),
        .I3(CSA_SUM_wire[53]),
        .I4(\PRODUCT_OBUF[53]_inst_i_3_n_0 ),
        .I5(\PRODUCT_OBUF[55]_inst_i_2_n_0 ),
        .O(\PRODUCT_OBUF[63]_inst_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h55FC6A003F003F00)) 
    \PRODUCT_OBUF[63]_inst_i_14 
       (.I0(s_u_b_IBUF),
        .I1(B_IBUF[29]),
        .I2(B_IBUF[30]),
        .I3(B_IBUF[31]),
        .I4(s_u_a_IBUF),
        .I5(A_IBUF[31]),
        .O(\PRODUCT_OBUF[63]_inst_i_14_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[63]_inst_i_15 
       (.I0(A_IBUF[30]),
        .I1(B_IBUF[31]),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[63]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'h08787870)) 
    \PRODUCT_OBUF[63]_inst_i_16 
       (.I0(A_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(B_IBUF[29]),
        .I3(B_IBUF[28]),
        .I4(B_IBUF[27]),
        .O(\PRODUCT_OBUF[63]_inst_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h00000000BF4040BF)) 
    \PRODUCT_OBUF[63]_inst_i_2 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_9_n_0 ),
        .I5(CSA_CARRY_wire[62]),
        .O(\PRODUCT_OBUF[63]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBF4040BFFFFFFFFF)) 
    \PRODUCT_OBUF[63]_inst_i_3 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_9_n_0 ),
        .I5(CSA_CARRY_wire[62]),
        .O(\PRODUCT_OBUF[63]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair264" *) 
  LUT4 #(
    .INIT(16'hEEE0)) 
    \PRODUCT_OBUF[63]_inst_i_4 
       (.I0(CSA_CARRY_wire[61]),
        .I1(CSA_SUM_wire[61]),
        .I2(CSA_CARRY_wire[60]),
        .I3(CSA_SUM_wire[60]),
        .O(\PRODUCT_OBUF[63]_inst_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000545555555555)) 
    \PRODUCT_OBUF[63]_inst_i_5 
       (.I0(\PRODUCT_OBUF[60]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[49]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[63]_inst_i_12_n_0 ),
        .I3(\PRODUCT_OBUF[63]_inst_i_13_n_0 ),
        .I4(COUT_OBUF_inst_i_2_n_0),
        .I5(\PRODUCT_OBUF[60]_inst_i_3_n_0 ),
        .O(\PRODUCT_OBUF[63]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair264" *) 
  LUT4 #(
    .INIT(16'hF880)) 
    \PRODUCT_OBUF[63]_inst_i_6 
       (.I0(CSA_CARRY_wire[60]),
        .I1(CSA_SUM_wire[60]),
        .I2(CSA_SUM_wire[61]),
        .I3(CSA_CARRY_wire[61]),
        .O(\PRODUCT_OBUF[63]_inst_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFBF004040FFBF00)) 
    \PRODUCT_OBUF[63]_inst_i_7 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[30]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_8_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_14_n_0 ),
        .I5(\PRODUCT_OBUF[63]_inst_i_9_n_0 ),
        .O(\PRODUCT_OBUF[63]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hAF9595F5)) 
    \PRODUCT_OBUF[63]_inst_i_8 
       (.I0(B_IBUF[31]),
        .I1(s_u_a_IBUF),
        .I2(A_IBUF[31]),
        .I3(B_IBUF[29]),
        .I4(B_IBUF[30]),
        .O(\PRODUCT_OBUF[63]_inst_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'h004040FF)) 
    \PRODUCT_OBUF[63]_inst_i_9 
       (.I0(s_u_b_IBUF),
        .I1(A_IBUF[29]),
        .I2(B_IBUF[31]),
        .I3(\PRODUCT_OBUF[63]_inst_i_15_n_0 ),
        .I4(\PRODUCT_OBUF[63]_inst_i_16_n_0 ),
        .O(\PRODUCT_OBUF[63]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[6]_inst 
       (.I(PRODUCT_OBUF[6]),
        .O(PRODUCT[6]));
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[6]_inst_i_1 
       (.I0(\PRODUCT_OBUF[7]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[7]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[7]_inst_i_7_n_0 ),
        .I3(\PRODUCT_OBUF[7]_inst_i_3_n_0 ),
        .I4(CSA_CARRY_wire[6]),
        .O(PRODUCT_OBUF[6]));
  OBUF \PRODUCT_OBUF[7]_inst 
       (.I(PRODUCT_OBUF[7]),
        .O(PRODUCT[7]));
  LUT6 #(
    .INIT(64'h2D4BB42D4BD22D4B)) 
    \PRODUCT_OBUF[7]_inst_i_1 
       (.I0(CSA_CARRY_wire[6]),
        .I1(\PRODUCT_OBUF[7]_inst_i_3_n_0 ),
        .I2(CSA_SUM_wire[7]),
        .I3(\PRODUCT_OBUF[7]_inst_i_5_n_0 ),
        .I4(\PRODUCT_OBUF[7]_inst_i_6_n_0 ),
        .I5(\PRODUCT_OBUF[7]_inst_i_7_n_0 ),
        .O(PRODUCT_OBUF[7]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[7]_inst_i_10 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[4]),
        .I4(\PRODUCT_OBUF[7]_inst_i_14_n_0 ),
        .O(\PRODUCT_OBUF[7]_inst_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[7]_inst_i_11 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[7]_inst_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[7]_inst_i_12 
       (.I0(A_IBUF[3]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[4]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[7]_inst_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[7]_inst_i_13 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[7]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[7]_inst_i_14 
       (.I0(A_IBUF[1]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[2]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[7]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair364" *) 
  LUT3 #(
    .INIT(8'hB2)) 
    \PRODUCT_OBUF[7]_inst_i_2 
       (.I0(\PRODUCT_OBUF[7]_inst_i_8_n_0 ),
        .I1(\PRODUCT_OBUF[7]_inst_i_9_n_0 ),
        .I2(\PRODUCT_OBUF[7]_inst_i_10_n_0 ),
        .O(CSA_CARRY_wire[6]));
  (* SOFT_HLUTNM = "soft_lutpair144" *) 
  LUT5 #(
    .INIT(32'h11171777)) 
    \PRODUCT_OBUF[7]_inst_i_3 
       (.I0(CSA_SUM_wire[5]),
        .I1(CSA_CARRY_wire[5]),
        .I2(CSA_SUM_wire[4]),
        .I3(CSA_CARRY_wire[4]),
        .I4(\PRODUCT_OBUF[5]_inst_i_4_n_0 ),
        .O(\PRODUCT_OBUF[7]_inst_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair234" *) 
  LUT5 #(
    .INIT(32'h69969669)) 
    \PRODUCT_OBUF[7]_inst_i_4 
       (.I0(\PRODUCT_OBUF[9]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[9]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[9]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[9]_inst_i_11_n_0 ),
        .O(CSA_SUM_wire[7]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT4 #(
    .INIT(16'h5995)) 
    \PRODUCT_OBUF[7]_inst_i_5 
       (.I0(\PRODUCT_OBUF[7]_inst_i_11_n_0 ),
        .I1(A_IBUF[0]),
        .I2(B_IBUF[5]),
        .I3(B_IBUF[6]),
        .O(\PRODUCT_OBUF[7]_inst_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[7]_inst_i_6 
       (.I0(\PRODUCT_OBUF[7]_inst_i_12_n_0 ),
        .I1(A_IBUF[5]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[6]),
        .O(\PRODUCT_OBUF[7]_inst_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[7]_inst_i_7 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[5]),
        .I4(\PRODUCT_OBUF[7]_inst_i_13_n_0 ),
        .O(\PRODUCT_OBUF[7]_inst_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'h65956A95)) 
    \PRODUCT_OBUF[7]_inst_i_8 
       (.I0(\PRODUCT_OBUF[7]_inst_i_13_n_0 ),
        .I1(A_IBUF[5]),
        .I2(B_IBUF[0]),
        .I3(B_IBUF[1]),
        .I4(A_IBUF[4]),
        .O(\PRODUCT_OBUF[7]_inst_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[7]_inst_i_9 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[7]_inst_i_9_n_0 ));
  OBUF \PRODUCT_OBUF[8]_inst 
       (.I(PRODUCT_OBUF[8]),
        .O(PRODUCT[8]));
  (* SOFT_HLUTNM = "soft_lutpair371" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \PRODUCT_OBUF[8]_inst_i_1 
       (.I0(\PRODUCT_OBUF[9]_inst_i_4_n_0 ),
        .I1(CSA_SUM_wire[8]),
        .I2(CSA_CARRY_wire[8]),
        .O(PRODUCT_OBUF[8]));
  OBUF \PRODUCT_OBUF[9]_inst 
       (.I(PRODUCT_OBUF[9]),
        .O(PRODUCT[9]));
  (* SOFT_HLUTNM = "soft_lutpair143" *) 
  LUT5 #(
    .INIT(32'hE81717E8)) 
    \PRODUCT_OBUF[9]_inst_i_1 
       (.I0(CSA_CARRY_wire[8]),
        .I1(CSA_SUM_wire[8]),
        .I2(\PRODUCT_OBUF[9]_inst_i_4_n_0 ),
        .I3(CSA_SUM_wire[9]),
        .I4(CSA_CARRY_wire[9]),
        .O(PRODUCT_OBUF[9]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT5 #(
    .INIT(32'h022A3E2A)) 
    \PRODUCT_OBUF[9]_inst_i_10 
       (.I0(B_IBUF[7]),
        .I1(B_IBUF[6]),
        .I2(B_IBUF[5]),
        .I3(A_IBUF[0]),
        .I4(\PRODUCT_OBUF[7]_inst_i_11_n_0 ),
        .O(\PRODUCT_OBUF[9]_inst_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT5 #(
    .INIT(32'hA59A5A9A)) 
    \PRODUCT_OBUF[9]_inst_i_11 
       (.I0(\PRODUCT_OBUF[9]_inst_i_18_n_0 ),
        .I1(A_IBUF[6]),
        .I2(B_IBUF[1]),
        .I3(B_IBUF[0]),
        .I4(A_IBUF[7]),
        .O(\PRODUCT_OBUF[9]_inst_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT5 #(
    .INIT(32'h5999A666)) 
    \PRODUCT_OBUF[9]_inst_i_12 
       (.I0(\PRODUCT_OBUF[11]_inst_i_21_n_0 ),
        .I1(B_IBUF[9]),
        .I2(B_IBUF[8]),
        .I3(B_IBUF[7]),
        .I4(\PRODUCT_OBUF[11]_inst_i_22_n_0 ),
        .O(\PRODUCT_OBUF[9]_inst_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT5 #(
    .INIT(32'h1760E89F)) 
    \PRODUCT_OBUF[9]_inst_i_13 
       (.I0(B_IBUF[8]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[0]),
        .I3(B_IBUF[9]),
        .I4(\PRODUCT_OBUF[11]_inst_i_19_n_0 ),
        .O(\PRODUCT_OBUF[9]_inst_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair259" *) 
  LUT4 #(
    .INIT(16'h111F)) 
    \PRODUCT_OBUF[9]_inst_i_14 
       (.I0(CSA_CARRY_wire[5]),
        .I1(CSA_SUM_wire[5]),
        .I2(CSA_SUM_wire[4]),
        .I3(CSA_CARRY_wire[4]),
        .O(\PRODUCT_OBUF[9]_inst_i_14_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair237" *) 
  LUT5 #(
    .INIT(32'hFBB22000)) 
    \PRODUCT_OBUF[9]_inst_i_15 
       (.I0(\PRODUCT_OBUF[7]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[7]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[7]_inst_i_7_n_0 ),
        .I3(CSA_CARRY_wire[6]),
        .I4(CSA_SUM_wire[7]),
        .O(\PRODUCT_OBUF[9]_inst_i_15_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair237" *) 
  LUT5 #(
    .INIT(32'hFF69B220)) 
    \PRODUCT_OBUF[9]_inst_i_16 
       (.I0(\PRODUCT_OBUF[7]_inst_i_5_n_0 ),
        .I1(\PRODUCT_OBUF[7]_inst_i_6_n_0 ),
        .I2(\PRODUCT_OBUF[7]_inst_i_7_n_0 ),
        .I3(CSA_CARRY_wire[6]),
        .I4(CSA_SUM_wire[7]),
        .O(\PRODUCT_OBUF[9]_inst_i_16_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair259" *) 
  LUT4 #(
    .INIT(16'h077F)) 
    \PRODUCT_OBUF[9]_inst_i_17 
       (.I0(CSA_CARRY_wire[4]),
        .I1(CSA_SUM_wire[4]),
        .I2(CSA_CARRY_wire[5]),
        .I3(CSA_SUM_wire[5]),
        .O(\PRODUCT_OBUF[9]_inst_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[9]_inst_i_18 
       (.I0(A_IBUF[4]),
        .I1(B_IBUF[3]),
        .I2(A_IBUF[5]),
        .I3(B_IBUF[1]),
        .I4(B_IBUF[2]),
        .O(\PRODUCT_OBUF[9]_inst_i_18_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair234" *) 
  LUT5 #(
    .INIT(32'h9600FF96)) 
    \PRODUCT_OBUF[9]_inst_i_2 
       (.I0(\PRODUCT_OBUF[9]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[9]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[9]_inst_i_10_n_0 ),
        .I4(\PRODUCT_OBUF[9]_inst_i_11_n_0 ),
        .O(CSA_CARRY_wire[8]));
  (* SOFT_HLUTNM = "soft_lutpair235" *) 
  LUT5 #(
    .INIT(32'h2BD4D42B)) 
    \PRODUCT_OBUF[9]_inst_i_3 
       (.I0(\PRODUCT_OBUF[9]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[9]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[9]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[9]_inst_i_13_n_0 ),
        .O(CSA_SUM_wire[8]));
  LUT5 #(
    .INIT(32'hF4F0FFF0)) 
    \PRODUCT_OBUF[9]_inst_i_4 
       (.I0(\PRODUCT_OBUF[9]_inst_i_14_n_0 ),
        .I1(\PRODUCT_OBUF[5]_inst_i_4_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_15_n_0 ),
        .I3(\PRODUCT_OBUF[9]_inst_i_16_n_0 ),
        .I4(\PRODUCT_OBUF[9]_inst_i_17_n_0 ),
        .O(\PRODUCT_OBUF[9]_inst_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair233" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \PRODUCT_OBUF[9]_inst_i_5 
       (.I0(\PRODUCT_OBUF[11]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[11]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[11]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[11]_inst_i_11_n_0 ),
        .I4(\PRODUCT_OBUF[11]_inst_i_10_n_0 ),
        .O(CSA_SUM_wire[9]));
  (* SOFT_HLUTNM = "soft_lutpair235" *) 
  LUT5 #(
    .INIT(32'hFF2B2B00)) 
    \PRODUCT_OBUF[9]_inst_i_6 
       (.I0(\PRODUCT_OBUF[9]_inst_i_7_n_0 ),
        .I1(\PRODUCT_OBUF[9]_inst_i_8_n_0 ),
        .I2(\PRODUCT_OBUF[9]_inst_i_9_n_0 ),
        .I3(\PRODUCT_OBUF[9]_inst_i_12_n_0 ),
        .I4(\PRODUCT_OBUF[9]_inst_i_13_n_0 ),
        .O(CSA_CARRY_wire[9]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT5 #(
    .INIT(32'h000034C4)) 
    \PRODUCT_OBUF[9]_inst_i_7 
       (.I0(A_IBUF[5]),
        .I1(B_IBUF[1]),
        .I2(B_IBUF[0]),
        .I3(A_IBUF[6]),
        .I4(\PRODUCT_OBUF[7]_inst_i_12_n_0 ),
        .O(\PRODUCT_OBUF[9]_inst_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[9]_inst_i_8 
       (.I0(A_IBUF[0]),
        .I1(B_IBUF[7]),
        .I2(A_IBUF[1]),
        .I3(B_IBUF[5]),
        .I4(B_IBUF[6]),
        .O(\PRODUCT_OBUF[9]_inst_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hDDC3C3BB)) 
    \PRODUCT_OBUF[9]_inst_i_9 
       (.I0(A_IBUF[2]),
        .I1(B_IBUF[5]),
        .I2(A_IBUF[3]),
        .I3(B_IBUF[3]),
        .I4(B_IBUF[4]),
        .O(\PRODUCT_OBUF[9]_inst_i_9_n_0 ));
  IBUF s_u_a_IBUF_inst
       (.I(s_u_a),
        .O(s_u_a_IBUF));
  IBUF s_u_b_IBUF_inst
       (.I(s_u_b),
        .O(s_u_b_IBUF));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
