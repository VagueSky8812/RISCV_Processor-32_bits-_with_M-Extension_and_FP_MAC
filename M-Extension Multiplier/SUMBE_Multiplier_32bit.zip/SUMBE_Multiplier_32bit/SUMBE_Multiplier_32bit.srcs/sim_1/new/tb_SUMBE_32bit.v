`timescale 1ns / 1ps

module tb_SUMBE_32bit_BK();

    // Inputs
    reg [31:0] A;
    reg [31:0] B;
    reg s_u;
    
    // Final Output
    wire [63:0] PRODUCT;
    wire Cout_Final;

    // 1. Instantiate the Python-Generated Multiplier
    SUMBE_Multiplier_32 MULT_CORE (
        .A(A), 
        .B(B), 
        .s_u(s_u), 
        .COUT(Cout_Final), 
        .PRODUCT(PRODUCT)
    );


    // Array to hold: {s_u (1), A (32), B (32), Expected (64)} = 129 bits wide
    reg [128:0] test_vectors [0:9]; 
    integer i, errors;

    initial begin
        // --- Load Test Vectors ---
        // 1. Boundary Extremes
        test_vectors[0] = {1'b0, 32'hFFFFFFFF, 32'hFFFFFFFF, 64'hFFFFFFFE00000001};
        test_vectors[1] = {1'b1, 32'h7FFFFFFF, 32'h7FFFFFFF, 64'h3FFFFFFF00000001};
        test_vectors[2] = {1'b1, 32'h80000000, 32'h80000000, 64'h4000000000000000};
        test_vectors[3] = {1'b1, 32'h7FFFFFFF, 32'h80000000, 64'hC000000080000000};
        test_vectors[4] = {1'b0, 32'h80000000, 32'h80000000, 64'h4000000000000000};
        
        // 2. Booth Torture & Negation
        test_vectors[5] = {1'b1, 32'hFFFFFFFF, 32'hFFFFFFFF, 64'h0000000000000001};
        test_vectors[6] = {1'b1, 32'h12345678, 32'hFFFFFFFF, 64'hFFFFFFFFEDCBA988};
        
        // 3. Ripple & Shift Tests
        test_vectors[7] = {1'b0, 32'hFFFFFFFF, 32'h00000001, 64'h00000000FFFFFFFF};
        test_vectors[8] = {1'b0, 32'hFFFFFFFE, 32'h00000002, 64'h00000001FFFFFFFC};
        test_vectors[9] = {1'b0, 32'h80000000, 32'h00000003, 64'h0000000180000000};

        errors = 0;
        $display("--- Starting 32-bit SUMBE + BK Adder Stress Test ---");
        
        for (i = 0; i < 10; i = i + 1) begin
            s_u = test_vectors[i][128];
            A   = test_vectors[i][127:96];
            B   = test_vectors[i][95:64];
            
            // Wait 20ns for signals to propagate through Dadda Tree + BK Adder
            //#20;
            #15; 

            if (PRODUCT !== test_vectors[i][63:0]) begin
                $display("FAIL! s_u=%b", s_u);
                $display("  A = %h", A);
                $display("  B = %h", B);
                $display("  Expected : %h", test_vectors[i][63:0]);
                $display("  Got      : %h", PRODUCT);
                $display("----------------------------------------");
                errors = errors + 1;
            end else begin
                $display("PASS: s_u=%b, A=%h, B=%h", s_u, A, B);
            end
        end

        if (errors == 0) begin
            $display("========================================");
            $display(" SUCCESS: 32-BIT MULTIPLIER IS FLAWLESS ");
            $display("========================================");
        end else begin
            $display("========================================");
            $display(" FAILED: %0d ERRORS FOUND ", errors);
            $display("========================================");
        end
            
        $finish;
    end
endmodule