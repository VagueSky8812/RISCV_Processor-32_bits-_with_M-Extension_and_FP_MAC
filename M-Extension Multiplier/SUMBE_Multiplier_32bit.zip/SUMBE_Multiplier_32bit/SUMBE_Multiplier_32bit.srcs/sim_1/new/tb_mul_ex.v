`timescale 1ns / 1ps

module tb_mul_ex();
    // Inputs
    reg        clk;
    reg       reset;
    reg        start;
    reg [2:0]  func3;      
    reg [31:0] op_a;       
    reg [31:0] op_b;       
    
    // CHANGE 1: Make outputs wires instead of regs
    wire [31:0] result;
    wire        ready;

    wire [31:0] multiplicand_wire;
    wire [31:0] multiplier_wire;
    wire [1:0] state_wire;
    wire led_wire;
    
    // Instantiate your Python-Generated Multiplier
    multiplier_m_ext MMM (
    .clk(clk),
    .reset(reset),
    .start(start),
    .func3(func3),      
    .op_a(op_a),       
    .op_b(op_b),
    .result(result),
    .ready(ready)
    
    /*.multiplicand_wire(multiplicand_wire),
    .multiplier_wire(multiplier_wire),
    .state_wire(state_wire),
    .led_wire(led_wire)*/
    );

    // 1. Start clock at 0 for a clean first rising edge
    initial begin
        clk = 0;
        //forever #8.33333 clk = ~clk;
        forever #8 clk = ~clk;
    end
    
    initial begin
        #100
        #0 reset=1'b0; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b0; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b1; func3=3'b000; op_a=32'd2; op_b=32'd8;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        
        #16 reset=1'b1; start=1'b1; func3=3'b000; op_a=32'd1; op_b=32'd1;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        
        #16 reset=1'b1; start=1'b1; func3=3'b000; op_a=32'd2; op_b=32'd2;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        #16 reset=1'b1; start=1'b0; func3=3'b000; op_a=32'd0; op_b=32'd0;
        
    end
endmodule