`timescale 1ns / 1ps

module tb_multiplier_m_ext();

    // Inputs
    reg clk;
    reg reset;
    reg start;
    reg [2:0] func3;
    reg [31:0] op_a;
    reg [31:0] op_b;

    // Outputs
    wire [31:0] multiplicand_wire;
    wire [31:0] multiplier_wire;
    wire [31:0] result;
    wire ready;

    // Instantiate the Wrapper
    multiplier_m_ext UUT (
        .clk(clk),
        .reset(reset),
        .start(start),
        .func3(func3),
        .op_a(op_a),
        .op_b(op_b),
        .multiplicand_wire(multiplicand_wire),
        .multiplier_wire(multiplier_wire),
        .result(result),
        .ready(ready)
    );

    // Freely running 100MHz clock (10ns period)
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Total Error Counter
    integer errors = 0;

    // Task to mimic the CPU launching an instruction and waiting for the ALU
    task run_test;
        input [8*10:1] test_name; // String to print
        input [2:0]  t_func3;
        input [31:0] t_a;
        input [31:0] t_b;
        input [31:0] t_expected;
        begin
            // 1. Apply inputs safely on the falling edge
            @(negedge clk);
            func3 = t_func3;
            op_a  = t_a;
            op_b  = t_b;
            start = 1'b1;

            // 2. Pulse 'start' for exactly 1 clock cycle (like a real CPU)
            @(negedge clk);
            start = 1'b0;

            // 3. Wait dynamically for the FSM to declare it is done
            wait(ready == 1'b1);
            
            // 4. Check the answer exactly when ready is high
            if (result !== t_expected) begin
                $display("FAIL [%s] | func3=%b | A=%h B=%h | Expected=%h | Got=%h", test_name, t_func3, op_a, op_b, t_expected, result);
                errors = errors + 1;
            end else begin
                $display("PASS [%s] | Result=%h", test_name, result);
            end
            
            // Wait 1 cycle before launching the next instruction
            @(negedge clk); 
        end
    endtask

    initial begin
        // Initialize all CPU lines to zero
        reset = 1'b1;
        start = 1'b0;
        func3 = 3'b000;
        op_a  = 32'd0;
        op_b  = 32'd0;

        // Apply Active-Low Reset (Clears the Red 'X's)
        #15;
        reset = 1'b0;
        #20;
        reset = 1'b1;
        #20;

        $display("=====================================================");
        $display("   STARTING FSM HANDSHAKE MULTIPLIER TESTBENCH       ");
        $display("=====================================================");

        // --- RISC-V M-EXTENSION TEST VECTORS ---
        // Format: run_test("Name", func3, op_a, op_b, expected_32bit_result);

        // 1. Standard MUL (Lower 32 bits, 2 * 8 = 16)
        run_test("MUL Basic ", 3'b000, 32'd2, 32'd8, 32'd16);

        // 2. Standard MUL (Negative: -4 * 3 = -12)
        run_test("MUL Neg   ", 3'b000, 32'hFFFFFFFC, 32'd3, 32'hFFFFFFF4);

        // 3. MULH (Upper 32 bits, Signed x Signed: Max Pos x Max Pos)
        // 2^31-1 * 2^31-1. 64-bit Hex = 3FFFFFFF00000001. Upper 32 = 3FFFFFFF.
        run_test("MULH MaxP ", 3'b001, 32'h7FFFFFFF, 32'h7FFFFFFF, 32'h3FFFFFFF);

        // 4. MULH (Signed Torture Test: Max Neg x Max Neg)
        // -2^31 * -2^31. 64-bit Hex = 4000000000000000. Upper 32 = 40000000.
        run_test("MULH MaxN ", 3'b001, 32'h80000000, 32'h80000000, 32'h40000000);

        // 5. MULHU (Upper 32 bits, Unsigned x Unsigned: Max Bounds)
        // 2^32-1 * 2^32-1. 64-bit Hex = FFFFFFFE00000001. Upper 32 = FFFFFFFE.
        run_test("MULHU MaxU", 3'b011, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'hFFFFFFFE);

        // 6. MULHSU (Upper 32 bits, Signed x Unsigned: Trap Test)
        // Signed -1 (FFFFFFFF) * Unsigned Max (FFFFFFFF). Upper 32 = FFFFFFFF.
        run_test("MULHSU Trp", 3'b010, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'hFFFFFFFF);

        // 7. Carry Avalanche test (forces ripple through the 32-bit output bound)
        run_test("MUL Avalan", 3'b000, 32'hFFFFFFFF, 32'h00000001, 32'hFFFFFFFF);

        if (errors == 0) begin
            $display("\n=====================================================");
            $display(" SUCCESS: WRAPPER PASSED ALL M-EXTENSION TESTS!      ");
            $display("=====================================================\n");
        end else begin
            $display("\n=====================================================");
            $display(" FAILED: %0d ERRORS FOUND ", errors);
            $display("=====================================================\n");
        end

       // $finish;
       $stop; // Changed from $finish!
    end

endmodule