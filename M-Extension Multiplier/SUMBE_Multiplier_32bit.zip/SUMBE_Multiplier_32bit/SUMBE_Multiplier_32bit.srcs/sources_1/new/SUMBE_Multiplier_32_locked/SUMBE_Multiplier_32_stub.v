// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module SUMBE_Multiplier_32(A, B, s_u_a, s_u_b, COUT, PRODUCT);
  input [31:0]A;
  input [31:0]B;
  input s_u_a;
  input s_u_b;
  output COUT;
  output [63:0]PRODUCT;
endmodule
