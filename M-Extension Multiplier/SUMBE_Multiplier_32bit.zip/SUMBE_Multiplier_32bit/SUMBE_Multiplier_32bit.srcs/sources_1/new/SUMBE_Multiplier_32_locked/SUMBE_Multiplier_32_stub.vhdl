-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity SUMBE_Multiplier_32 is
  Port ( 
    A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    B : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s_u_a : in STD_LOGIC;
    s_u_b : in STD_LOGIC;
    COUT : out STD_LOGIC;
    PRODUCT : out STD_LOGIC_VECTOR ( 63 downto 0 )
  );

end SUMBE_Multiplier_32;

architecture stub of SUMBE_Multiplier_32 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
begin
end;
