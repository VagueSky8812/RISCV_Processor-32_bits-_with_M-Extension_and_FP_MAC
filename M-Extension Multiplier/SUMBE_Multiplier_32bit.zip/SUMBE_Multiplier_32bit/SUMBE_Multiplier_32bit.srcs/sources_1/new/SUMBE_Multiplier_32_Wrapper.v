module SUMBE_Multiplier_32_wrapper(
    input wire [31:0] A, B,
	input wire s_u_a, s_u_b,
	output wire COUT,
	output wire [63:0] PRODUCT
    );
    
    SUMBE_Multiplier_32 multiplier_m(
	.A(A), .B(B),
	.s_u_a(s_u_a), .s_u_b(s_u_b),
	.COUT(COUT),
	.PRODUCT(PRODUCT)
    );
    
endmodule
