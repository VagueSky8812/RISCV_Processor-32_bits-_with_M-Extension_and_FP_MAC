module BK_Adder_64(
	input wire [63:0] A, B,
	input wire CIN,
	output wire COUT,
	output wire [63:0] SUM
);
	//Generate p's and g's
	wire [63:0] p, g;
	assign g = A & B;
	assign p = A | B;
	//Leve1 Generates and Propagates
	//Wire Declarations
	wire G1_0, P1_0;
	wire G3_2, P3_2;
	wire G5_4, P5_4;
	wire G7_6, P7_6;
	wire G9_8, P9_8;
	wire G11_10, P11_10;
	wire G13_12, P13_12;
	wire G15_14, P15_14;
	wire G17_16, P17_16;
	wire G19_18, P19_18;
	wire G21_20, P21_20;
	wire G23_22, P23_22;
	wire G25_24, P25_24;
	wire G27_26, P27_26;
	wire G29_28, P29_28;
	wire G31_30, P31_30;
	wire G33_32, P33_32;
	wire G35_34, P35_34;
	wire G37_36, P37_36;
	wire G39_38, P39_38;
	wire G41_40, P41_40;
	wire G43_42, P43_42;
	wire G45_44, P45_44;
	wire G47_46, P47_46;
	wire G49_48, P49_48;
	wire G51_50, P51_50;
	wire G53_52, P53_52;
	wire G55_54, P55_54;
	wire G57_56, P57_56;
	wire G59_58, P59_58;
	wire G61_60, P61_60;
	wire G63_62, P63_62;
	//Generates
	assign G1_0 = g[1] | (p[1] & g[0]);
	assign G3_2 = g[3] | (p[3] & g[2]);
	assign G5_4 = g[5] | (p[5] & g[4]);
	assign G7_6 = g[7] | (p[7] & g[6]);
	assign G9_8 = g[9] | (p[9] & g[8]);
	assign G11_10 = g[11] | (p[11] & g[10]);
	assign G13_12 = g[13] | (p[13] & g[12]);
	assign G15_14 = g[15] | (p[15] & g[14]);
	assign G17_16 = g[17] | (p[17] & g[16]);
	assign G19_18 = g[19] | (p[19] & g[18]);
	assign G21_20 = g[21] | (p[21] & g[20]);
	assign G23_22 = g[23] | (p[23] & g[22]);
	assign G25_24 = g[25] | (p[25] & g[24]);
	assign G27_26 = g[27] | (p[27] & g[26]);
	assign G29_28 = g[29] | (p[29] & g[28]);
	assign G31_30 = g[31] | (p[31] & g[30]);
	assign G33_32 = g[33] | (p[33] & g[32]);
	assign G35_34 = g[35] | (p[35] & g[34]);
	assign G37_36 = g[37] | (p[37] & g[36]);
	assign G39_38 = g[39] | (p[39] & g[38]);
	assign G41_40 = g[41] | (p[41] & g[40]);
	assign G43_42 = g[43] | (p[43] & g[42]);
	assign G45_44 = g[45] | (p[45] & g[44]);
	assign G47_46 = g[47] | (p[47] & g[46]);
	assign G49_48 = g[49] | (p[49] & g[48]);
	assign G51_50 = g[51] | (p[51] & g[50]);
	assign G53_52 = g[53] | (p[53] & g[52]);
	assign G55_54 = g[55] | (p[55] & g[54]);
	assign G57_56 = g[57] | (p[57] & g[56]);
	assign G59_58 = g[59] | (p[59] & g[58]);
	assign G61_60 = g[61] | (p[61] & g[60]);
	assign G63_62 = g[63] | (p[63] & g[62]);
	//Propagates
	assign P1_0 = (p[1] & p[0]);
	assign P3_2 = (p[3] & p[2]);
	assign P5_4 = (p[5] & p[4]);
	assign P7_6 = (p[7] & p[6]);
	assign P9_8 = (p[9] & p[8]);
	assign P11_10 = (p[11] & p[10]);
	assign P13_12 = (p[13] & p[12]);
	assign P15_14 = (p[15] & p[14]);
	assign P17_16 = (p[17] & p[16]);
	assign P19_18 = (p[19] & p[18]);
	assign P21_20 = (p[21] & p[20]);
	assign P23_22 = (p[23] & p[22]);
	assign P25_24 = (p[25] & p[24]);
	assign P27_26 = (p[27] & p[26]);
	assign P29_28 = (p[29] & p[28]);
	assign P31_30 = (p[31] & p[30]);
	assign P33_32 = (p[33] & p[32]);
	assign P35_34 = (p[35] & p[34]);
	assign P37_36 = (p[37] & p[36]);
	assign P39_38 = (p[39] & p[38]);
	assign P41_40 = (p[41] & p[40]);
	assign P43_42 = (p[43] & p[42]);
	assign P45_44 = (p[45] & p[44]);
	assign P47_46 = (p[47] & p[46]);
	assign P49_48 = (p[49] & p[48]);
	assign P51_50 = (p[51] & p[50]);
	assign P53_52 = (p[53] & p[52]);
	assign P55_54 = (p[55] & p[54]);
	assign P57_56 = (p[57] & p[56]);
	assign P59_58 = (p[59] & p[58]);
	assign P61_60 = (p[61] & p[60]);
	assign P63_62 = (p[63] & p[62]);
	//Level 2 Generates and Propagates
	//Wire Declarations
	wire G3_0, P3_0;
	wire G7_4, P7_4;
	wire G11_8, P11_8;
	wire G15_12, P15_12;
	wire G19_16, P19_16;
	wire G23_20, P23_20;
	wire G27_24, P27_24;
	wire G31_28, P31_28;
	wire G35_32, P35_32;
	wire G39_36, P39_36;
	wire G43_40, P43_40;
	wire G47_44, P47_44;
	wire G51_48, P51_48;
	wire G55_52, P55_52;
	wire G59_56, P59_56;
	wire G63_60, P63_60;
	//Generates
	assign G3_0 = G3_2 | (P3_2 & G1_0);
	assign G7_4 = G7_6 | (P7_6 & G5_4);
	assign G11_8 = G11_10 | (P11_10 & G9_8);
	assign G15_12 = G15_14 | (P15_14 & G13_12);
	assign G19_16 = G19_18 | (P19_18 & G17_16);
	assign G23_20 = G23_22 | (P23_22 & G21_20);
	assign G27_24 = G27_26 | (P27_26 & G25_24);
	assign G31_28 = G31_30 | (P31_30 & G29_28);
	assign G35_32 = G35_34 | (P35_34 & G33_32);
	assign G39_36 = G39_38 | (P39_38 & G37_36);
	assign G43_40 = G43_42 | (P43_42 & G41_40);
	assign G47_44 = G47_46 | (P47_46 & G45_44);
	assign G51_48 = G51_50 | (P51_50 & G49_48);
	assign G55_52 = G55_54 | (P55_54 & G53_52);
	assign G59_56 = G59_58 | (P59_58 & G57_56);
	assign G63_60 = G63_62 | (P63_62 & G61_60);
	//Propagates
	assign P3_0 = P3_2 & P1_0;
	assign P7_4 = P7_6 & P5_4;
	assign P11_8 = P11_10 & P9_8;
	assign P15_12 = P15_14 & P13_12;
	assign P19_16 = P19_18 & P17_16;
	assign P23_20 = P23_22 & P21_20;
	assign P27_24 = P27_26 & P25_24;
	assign P31_28 = P31_30 & P29_28;
	assign P35_32 = P35_34 & P33_32;
	assign P39_36 = P39_38 & P37_36;
	assign P43_40 = P43_42 & P41_40;
	assign P47_44 = P47_46 & P45_44;
	assign P51_48 = P51_50 & P49_48;
	assign P55_52 = P55_54 & P53_52;
	assign P59_56 = P59_58 & P57_56;
	assign P63_60 = P63_62 & P61_60;
	//Level 3 Generates and Propagates
	//Wire Declarations
	wire G7_0, P7_0;
	wire G15_8, P15_8;
	wire G23_16, P23_16;
	wire G31_24, P31_24;
	wire G39_32, P39_32;
	wire G47_40, P47_40;
	wire G55_48, P55_48;
	wire G63_56, P63_56;
	//Generates
	assign G7_0 = G7_4 | (P7_4 & G3_0);
	assign G15_8 = G15_12 | (P15_12 & G11_8);
	assign G23_16 = G23_20 | (P23_20 & G19_16);
	assign G31_24 = G31_28 | (P31_28 & G27_24);
	assign G39_32 = G39_36 | (P39_36 & G35_32);
	assign G47_40 = G47_44 | (P47_44 & G43_40);
	assign G55_48 = G55_52 | (P55_52 & G51_48);
	assign G63_56 = G63_60 | (P63_60 & G59_56);
	//Propagates
	assign P7_0 = P7_4 & P3_0;
	assign P15_8 = P15_12 & P11_8;
	assign P23_16 = P23_20 & P19_16;
	assign P31_24 = P31_28 & P27_24;
	assign P39_32 = P39_36 & P35_32;
	assign P47_40 = P47_44 & P43_40;
	assign P55_48 = P55_52 & P51_48;
	assign P63_56 = P63_60 & P59_56;
	//Level 4 Generates and Propagates
	//Wire Declarations
	wire G15_0, P15_0;
	wire G31_16, P31_16;
	wire G47_32, P47_32;
	wire G63_48, P63_48;
	//Generates
	assign G15_0 = G15_8 | (P15_8 & G7_0);
	assign G31_16 = G31_24 | (P31_24 & G23_16);
	assign G47_32 = G47_40 | (P47_40 & G39_32);
	assign G63_48 = G63_56 | (P63_56 & G55_48);
	//Propagates
	assign P15_0 = P15_8 & P7_0;
	assign P31_16 = P31_24 & P23_16;
	assign P47_32 = P47_40 & P39_32;
	assign P63_48 = P63_56 & P55_48;
	//Level 5 Generates and Propagates
	//Wire Declarations
	wire G31_0, P31_0;
	wire G63_32, P63_32;
	//Generates
	assign G31_0 = G31_16 | (P31_16 & G15_0);
	assign G63_32 = G63_48 | (P63_48 & G47_32);
	//Propagates
	assign P31_0 = P31_16 & P15_0;
	assign P63_32 = P63_48 & P47_32;
	//Level 6 Generates and Propagates
	//Wire Declarations
	wire G63_0, P63_0;
	//Generates
	assign G63_0 = G63_32 | (P63_32 & G31_0);
	//Propagates
	assign P63_0 = P63_32 & P31_0;
	//Level 7 Generates and Propagates
	//Wire Declarations
	wire G47_0, P47_0;
	//Generates
	assign G47_0 = G47_32 | (P47_32 & G31_0);
	//Propagates
	assign P47_0 = P47_32 & P31_0;
	//Level 8 Generates and Propagates
	//Wire Declarations
	wire G23_0, P23_0;
	wire G39_0, P39_0;
	wire G55_0, P55_0;
	//Generates
	assign G23_0 = G23_16 | (P23_16 & G15_0);
	assign G39_0 = G39_32 | (P39_32 & G31_0);
	assign G55_0 = G55_48 | (P55_48 & G47_0);
	//Propagates
	assign P23_0 = P23_16 & P15_0;
	assign P39_0 = P39_32 & P31_0;
	assign P55_0 = P55_48 & P47_0;
	//Level 9 Generates and Propagates
	//Wire Declarations
	wire G11_0, P11_0;
	wire G19_0, P19_0;
	wire G27_0, P27_0;
	wire G35_0, P35_0;
	wire G43_0, P43_0;
	wire G51_0, P51_0;
	wire G59_0, P59_0;
	//Generates
	assign G11_0 = G11_8 | (P11_8 & G7_0);
	assign G19_0 = G19_16 | (P19_16 & G15_0);
	assign G27_0 = G27_24 | (P27_24 & G23_0);
	assign G35_0 = G35_32 | (P35_32 & G31_0);
	assign G43_0 = G43_40 | (P43_40 & G39_0);
	assign G51_0 = G51_48 | (P51_48 & G47_0);
	assign G59_0 = G59_56 | (P59_56 & G55_0);
	//Propagates
	assign P11_0 = P11_8 & P7_0;
	assign P19_0 = P19_16 & P15_0;
	assign P27_0 = P27_24 & P23_0;
	assign P35_0 = P35_32 & P31_0;
	assign P43_0 = P43_40 & P39_0;
	assign P51_0 = P51_48 & P47_0;
	assign P59_0 = P59_56 & P55_0;
	//Level 10 Generates and Propagates
	//Wire Declarations
	wire G5_0, P5_0;
	wire G9_0, P9_0;
	wire G13_0, P13_0;
	wire G17_0, P17_0;
	wire G21_0, P21_0;
	wire G25_0, P25_0;
	wire G29_0, P29_0;
	wire G33_0, P33_0;
	wire G37_0, P37_0;
	wire G41_0, P41_0;
	wire G45_0, P45_0;
	wire G49_0, P49_0;
	wire G53_0, P53_0;
	wire G57_0, P57_0;
	wire G61_0, P61_0;
	//Generates
	assign G5_0 = G5_4 | (P5_4 & G3_0);
	assign G9_0 = G9_8 | (P9_8 & G7_0);
	assign G13_0 = G13_12 | (P13_12 & G11_0);
	assign G17_0 = G17_16 | (P17_16 & G15_0);
	assign G21_0 = G21_20 | (P21_20 & G19_0);
	assign G25_0 = G25_24 | (P25_24 & G23_0);
	assign G29_0 = G29_28 | (P29_28 & G27_0);
	assign G33_0 = G33_32 | (P33_32 & G31_0);
	assign G37_0 = G37_36 | (P37_36 & G35_0);
	assign G41_0 = G41_40 | (P41_40 & G39_0);
	assign G45_0 = G45_44 | (P45_44 & G43_0);
	assign G49_0 = G49_48 | (P49_48 & G47_0);
	assign G53_0 = G53_52 | (P53_52 & G51_0);
	assign G57_0 = G57_56 | (P57_56 & G55_0);
	assign G61_0 = G61_60 | (P61_60 & G59_0);
	//Propagates
	assign P5_0 = P5_4 & P3_0;
	assign P9_0 = P9_8 & P7_0;
	assign P13_0 = P13_12 & P11_0;
	assign P17_0 = P17_16 & P15_0;
	assign P21_0 = P21_20 & P19_0;
	assign P25_0 = P25_24 & P23_0;
	assign P29_0 = P29_28 & P27_0;
	assign P33_0 = P33_32 & P31_0;
	assign P37_0 = P37_36 & P35_0;
	assign P41_0 = P41_40 & P39_0;
	assign P45_0 = P45_44 & P43_0;
	assign P49_0 = P49_48 & P47_0;
	assign P53_0 = P53_52 & P51_0;
	assign P57_0 = P57_56 & P55_0;
	assign P61_0 = P61_60 & P59_0;
	//Level 11 Generates and Propagates
	//Wire Declarations
	wire G2_0, P2_0;
	wire G4_0, P4_0;
	wire G6_0, P6_0;
	wire G8_0, P8_0;
	wire G10_0, P10_0;
	wire G12_0, P12_0;
	wire G14_0, P14_0;
	wire G16_0, P16_0;
	wire G18_0, P18_0;
	wire G20_0, P20_0;
	wire G22_0, P22_0;
	wire G24_0, P24_0;
	wire G26_0, P26_0;
	wire G28_0, P28_0;
	wire G30_0, P30_0;
	wire G32_0, P32_0;
	wire G34_0, P34_0;
	wire G36_0, P36_0;
	wire G38_0, P38_0;
	wire G40_0, P40_0;
	wire G42_0, P42_0;
	wire G44_0, P44_0;
	wire G46_0, P46_0;
	wire G48_0, P48_0;
	wire G50_0, P50_0;
	wire G52_0, P52_0;
	wire G54_0, P54_0;
	wire G56_0, P56_0;
	wire G58_0, P58_0;
	wire G60_0, P60_0;
	wire G62_0, P62_0;
	//Generates
	assign G2_0  = g[2]   | (p[2]   & G1_0);
	assign G4_0  = g[4]   | (p[4]   & G3_0);
	assign G6_0  = g[6]   | (p[6]   & G5_0);
	assign G8_0  = g[8]   | (p[8]   & G7_0);
	assign G10_0  = g[10]   | (p[10]   & G9_0);
	assign G12_0  = g[12]   | (p[12]   & G11_0);
	assign G14_0  = g[14]   | (p[14]   & G13_0);
	assign G16_0  = g[16]   | (p[16]   & G15_0);
	assign G18_0  = g[18]   | (p[18]   & G17_0);
	assign G20_0  = g[20]   | (p[20]   & G19_0);
	assign G22_0  = g[22]   | (p[22]   & G21_0);
	assign G24_0  = g[24]   | (p[24]   & G23_0);
	assign G26_0  = g[26]   | (p[26]   & G25_0);
	assign G28_0  = g[28]   | (p[28]   & G27_0);
	assign G30_0  = g[30]   | (p[30]   & G29_0);
	assign G32_0  = g[32]   | (p[32]   & G31_0);
	assign G34_0  = g[34]   | (p[34]   & G33_0);
	assign G36_0  = g[36]   | (p[36]   & G35_0);
	assign G38_0  = g[38]   | (p[38]   & G37_0);
	assign G40_0  = g[40]   | (p[40]   & G39_0);
	assign G42_0  = g[42]   | (p[42]   & G41_0);
	assign G44_0  = g[44]   | (p[44]   & G43_0);
	assign G46_0  = g[46]   | (p[46]   & G45_0);
	assign G48_0  = g[48]   | (p[48]   & G47_0);
	assign G50_0  = g[50]   | (p[50]   & G49_0);
	assign G52_0  = g[52]   | (p[52]   & G51_0);
	assign G54_0  = g[54]   | (p[54]   & G53_0);
	assign G56_0  = g[56]   | (p[56]   & G55_0);
	assign G58_0  = g[58]   | (p[58]   & G57_0);
	assign G60_0  = g[60]   | (p[60]   & G59_0);
	assign G62_0  = g[62]   | (p[62]   & G61_0);
	//Propagates
	assign P2_0  = p[2]   & P1_0;
	assign P4_0  = p[4]   & P3_0;
	assign P6_0  = p[6]   & P5_0;
	assign P8_0  = p[8]   & P7_0;
	assign P10_0  = p[10]   & P9_0;
	assign P12_0  = p[12]   & P11_0;
	assign P14_0  = p[14]   & P13_0;
	assign P16_0  = p[16]   & P15_0;
	assign P18_0  = p[18]   & P17_0;
	assign P20_0  = p[20]   & P19_0;
	assign P22_0  = p[22]   & P21_0;
	assign P24_0  = p[24]   & P23_0;
	assign P26_0  = p[26]   & P25_0;
	assign P28_0  = p[28]   & P27_0;
	assign P30_0  = p[30]   & P29_0;
	assign P32_0  = p[32]   & P31_0;
	assign P34_0  = p[34]   & P33_0;
	assign P36_0  = p[36]   & P35_0;
	assign P38_0  = p[38]   & P37_0;
	assign P40_0  = p[40]   & P39_0;
	assign P42_0  = p[42]   & P41_0;
	assign P44_0  = p[44]   & P43_0;
	assign P46_0  = p[46]   & P45_0;
	assign P48_0  = p[48]   & P47_0;
	assign P50_0  = p[50]   & P49_0;
	assign P52_0  = p[52]   & P51_0;
	assign P54_0  = p[54]   & P53_0;
	assign P56_0  = p[56]   & P55_0;
	assign P58_0  = p[58]   & P57_0;
	assign P60_0  = p[60]   & P59_0;
	assign P62_0  = p[62]   & P61_0;
	//Carry level
	wire [64:0] C;
	assign C[0] = CIN;
	assign C[1] = g[0]   | (p[0]   & CIN);
	assign C[2] = G1_0 | (P1_0 & CIN);
	assign C[3] = G2_0 | (P2_0 & CIN);
	assign C[4] = G3_0 | (P3_0 & CIN);
	assign C[5] = G4_0 | (P4_0 & CIN);
	assign C[6] = G5_0 | (P5_0 & CIN);
	assign C[7] = G6_0 | (P6_0 & CIN);
	assign C[8] = G7_0 | (P7_0 & CIN);
	assign C[9] = G8_0 | (P8_0 & CIN);
	assign C[10] = G9_0 | (P9_0 & CIN);
	assign C[11] = G10_0 | (P10_0 & CIN);
	assign C[12] = G11_0 | (P11_0 & CIN);
	assign C[13] = G12_0 | (P12_0 & CIN);
	assign C[14] = G13_0 | (P13_0 & CIN);
	assign C[15] = G14_0 | (P14_0 & CIN);
	assign C[16] = G15_0 | (P15_0 & CIN);
	assign C[17] = G16_0 | (P16_0 & CIN);
	assign C[18] = G17_0 | (P17_0 & CIN);
	assign C[19] = G18_0 | (P18_0 & CIN);
	assign C[20] = G19_0 | (P19_0 & CIN);
	assign C[21] = G20_0 | (P20_0 & CIN);
	assign C[22] = G21_0 | (P21_0 & CIN);
	assign C[23] = G22_0 | (P22_0 & CIN);
	assign C[24] = G23_0 | (P23_0 & CIN);
	assign C[25] = G24_0 | (P24_0 & CIN);
	assign C[26] = G25_0 | (P25_0 & CIN);
	assign C[27] = G26_0 | (P26_0 & CIN);
	assign C[28] = G27_0 | (P27_0 & CIN);
	assign C[29] = G28_0 | (P28_0 & CIN);
	assign C[30] = G29_0 | (P29_0 & CIN);
	assign C[31] = G30_0 | (P30_0 & CIN);
	assign C[32] = G31_0 | (P31_0 & CIN);
	assign C[33] = G32_0 | (P32_0 & CIN);
	assign C[34] = G33_0 | (P33_0 & CIN);
	assign C[35] = G34_0 | (P34_0 & CIN);
	assign C[36] = G35_0 | (P35_0 & CIN);
	assign C[37] = G36_0 | (P36_0 & CIN);
	assign C[38] = G37_0 | (P37_0 & CIN);
	assign C[39] = G38_0 | (P38_0 & CIN);
	assign C[40] = G39_0 | (P39_0 & CIN);
	assign C[41] = G40_0 | (P40_0 & CIN);
	assign C[42] = G41_0 | (P41_0 & CIN);
	assign C[43] = G42_0 | (P42_0 & CIN);
	assign C[44] = G43_0 | (P43_0 & CIN);
	assign C[45] = G44_0 | (P44_0 & CIN);
	assign C[46] = G45_0 | (P45_0 & CIN);
	assign C[47] = G46_0 | (P46_0 & CIN);
	assign C[48] = G47_0 | (P47_0 & CIN);
	assign C[49] = G48_0 | (P48_0 & CIN);
	assign C[50] = G49_0 | (P49_0 & CIN);
	assign C[51] = G50_0 | (P50_0 & CIN);
	assign C[52] = G51_0 | (P51_0 & CIN);
	assign C[53] = G52_0 | (P52_0 & CIN);
	assign C[54] = G53_0 | (P53_0 & CIN);
	assign C[55] = G54_0 | (P54_0 & CIN);
	assign C[56] = G55_0 | (P55_0 & CIN);
	assign C[57] = G56_0 | (P56_0 & CIN);
	assign C[58] = G57_0 | (P57_0 & CIN);
	assign C[59] = G58_0 | (P58_0 & CIN);
	assign C[60] = G59_0 | (P59_0 & CIN);
	assign C[61] = G60_0 | (P60_0 & CIN);
	assign C[62] = G61_0 | (P61_0 & CIN);
	assign C[63] = G62_0 | (P62_0 & CIN);
	assign C[64] = G63_0 | (P63_0 & CIN);
	//Output Level
	assign SUM = (A ^ B) ^ C[63:0];
	assign COUT = C[64];
endmodule